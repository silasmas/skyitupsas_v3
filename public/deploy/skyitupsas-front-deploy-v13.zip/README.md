# SkyITup SAS — Frontend (Next.js)

Frontend headless du site corporate **skyitupsas.com**, construit avec Next.js
(App Router). Il consomme l'API REST Laravel (`/api/v1`) exposée par le dépôt
`skyitupsas_v3` (branche `main`).

## Stack

- **Next.js 16** (App Router, React 19, Turbopack)
- **TypeScript**
- **Tailwind CSS v4** (design system repris du template `skyitup-refont`)
- **next-intl** — internationalisation avec routage `/[locale]` (`fr`, `fr` par défaut, `en`)
- **lucide-react** — icônes

## Prérequis

- Node.js 20+ (testé avec Node 24)
- L'API Laravel démarrée (par défaut `http://127.0.0.1:8000`)

## Configuration

Copier `.env.example` vers `.env.local` puis ajuster si besoin :

```bash
cp .env.example .env.local
```

| Variable                   | Rôle                                                        |
| -------------------------- | ----------------------------------------------------------- |
| `API_BASE_URL`             | URL de l'API utilisée côté serveur (data fetching + ISR)    |
| `NEXT_PUBLIC_API_BASE_URL` | URL de l'API exposée au navigateur (formulaires client)     |

## Commandes

```bash
npm install     # installer les dépendances
npm run dev     # serveur de développement (http://localhost:3000)
npm run build   # build de production
npm run start   # servir le build de production
npm run lint    # analyse ESLint
```

## Structure

```
src/
  app/
    [locale]/            # segment de locale (fr|en)
      layout.tsx         # polices, provider i18n, shell (header/footer/chatbot)
      page.tsx           # page d'accueil
      services/page.tsx  # page Services (données via API)
      not-found.tsx      # page 404 localisée
    globals.css          # design system (tokens Tailwind, classes utilitaires)
  components/
    Header.tsx           # navigation + sélecteur de langue
    Footer.tsx           # liens + newsletter (POST API)
    LanguageSwitcher.tsx # changement de locale par URL
    Chatbot.tsx          # widget de chat (réponses simulées, prêt pour un LLM)
    SocialLinks.tsx      # icônes réseaux sociaux (SVG inline)
    sections/            # Hero, CTA, PageHero, ServicesGrid
  i18n/
    routing.ts           # locales, locale par défaut, préfixe d'URL
    navigation.ts        # Link / useRouter conscients de la locale
    request.ts           # chargement des messages
  lib/
    api.ts               # client API typé (fetch + revalidation ISR)
    types.ts             # types des ressources API
    paths.ts             # slugs des pages (alignés sur Laravel)
  proxy.ts               # routage i18n (ex-middleware, convention Next 16)
messages/
  fr.json / en.json      # libellés d'interface
```

## Internationalisation

Toutes les URLs sont préfixées par la locale (`/fr/...`, `/en/...`). Le contenu
métier (services, réalisations, etc.) est récupéré depuis l'API en envoyant
l'en-tête `X-Locale`, qui renvoie les champs traduisibles sous forme de chaînes
dans la langue demandée. Les libellés d'interface vivent dans `messages/*.json`.

## Intégration API

Le data fetching se fait côté serveur avec revalidation ISR (5 min). Les appels
sont tolérants aux pannes : si l'API est indisponible, les collections
retournent un tableau vide plutôt que de casser le rendu.

## Chatbot

Le composant `Chatbot` reproduit le comportement du template (réponses simulées
par mots-clés). Il est structuré pour évoluer (Phase C) vers un vrai modèle de
langage via une Route Handler Next.js, avec possibilité de journaliser les
conversations côté Laravel.
