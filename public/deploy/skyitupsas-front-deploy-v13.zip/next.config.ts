import type { NextConfig } from "next";
import createNextIntlPlugin from "next-intl/plugin";

const withNextIntl = createNextIntlPlugin();

const nextConfig: NextConfig = {
  // Les images (logos, réalisations) sont servies en URL absolue par l'API Laravel.
  // On utilise des balises <img> classiques, aucune configuration next/image requise.
};

export default withNextIntl(nextConfig);
