/**
 * Point d'entrée du serveur Next.js pour l'hébergement Node.js de Hostinger
 * (Phusion Passenger).
 *
 * Passenger exige un fichier de démarrage qui crée un serveur HTTP et appelle
 * `listen()`. Passenger intercepte cet appel pour brancher l'application sur
 * son propre socket ; la valeur du port n'a donc qu'un rôle de repli local.
 */
const { createServer } = require("http");
const next = require("next");

/** Port utilisé en repli hors Passenger (dev local ou test manuel). */
const PORT = Number(process.env.PORT) || 3000;

const app = next({ dev: false });
const handleRequest = app.getRequestHandler();

app
  .prepare()
  .then(() => {
    createServer((request, response) => {
      const host = (request.headers.host || "").split(":")[0].toLowerCase();

      if (host.startsWith("admin.")) {
        response.writeHead(302, {
          Location: "https://admin.skyitupsas.org/admin",
        });
        response.end();
        return;
      }

      handleRequest(request, response);
    }).listen(PORT, () => {
      console.log(`Frontend Next.js prêt (port ${PORT}).`);
    });
  })
  .catch((error) => {
    console.error("Échec du démarrage du serveur Next.js :", error);
    process.exit(1);
  });
