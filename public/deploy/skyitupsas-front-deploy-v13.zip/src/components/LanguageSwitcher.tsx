"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import { Check, ChevronDown, Globe } from "lucide-react";
import { useLocale } from "next-intl";
import { usePathname, useRouter } from "@/i18n/navigation";
import { routing, type Locale } from "@/i18n/routing";

const LANGS: { code: Locale; label: string; flag: string }[] = [
  { code: "fr", label: "Français", flag: "🇫🇷" },
  { code: "en", label: "English", flag: "🇬🇧" },
];

type Variant = "light" | "dark";

/**
 * Sélecteur de langue : change la locale en conservant le chemin courant
 * (navigation URL, pas de localStorage).
 *
 * @param variant Style visuel du déclencheur (clair ou sombre)
 */
export default function LanguageSwitcher({
  variant = "light",
}: {
  variant?: Variant;
}) {
  const locale = useLocale() as Locale;
  const pathname = usePathname();
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const current = LANGS.find((l) => l.code === locale) ?? LANGS[0];

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (!ref.current?.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const trigger =
    variant === "dark"
      ? "border-white/15 bg-white/5 text-white hover:border-white/30 hover:bg-white/10"
      : "border-ink-200 bg-white text-ink-900 hover:border-ink-900";

  const handleSelect = (code: Locale) => {
    setOpen(false);
    if (code === locale) {
      return;
    }
    startTransition(() => {
      router.replace(pathname, { locale: code });
    });
  };

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-haspopup="listbox"
        aria-expanded={open}
        disabled={isPending}
        className={`inline-flex items-center gap-2 rounded-full border px-3 py-2 text-xs font-semibold uppercase tracking-wider transition ${trigger}`}
      >
        <Globe size={14} />
        <span>{current.code}</span>
        <ChevronDown
          size={14}
          className={`transition ${open ? "rotate-180" : ""}`}
        />
      </button>

      {open && (
        <ul
          role="listbox"
          className="absolute right-0 top-full z-50 mt-2 w-44 overflow-hidden rounded-2xl border border-ink-100 bg-white p-1 shadow-xl"
        >
          {routing.locales.map((code) => {
            const lang = LANGS.find((l) => l.code === code) ?? LANGS[0];
            const active = code === locale;
            return (
              <li key={code}>
                <button
                  type="button"
                  role="option"
                  aria-selected={active}
                  onClick={() => handleSelect(code)}
                  className={`flex w-full items-center justify-between gap-3 rounded-xl px-3 py-2 text-sm transition ${
                    active
                      ? "bg-brand-50 text-ink-950"
                      : "text-ink-700 hover:bg-ink-50"
                  }`}
                >
                  <span className="flex items-center gap-2.5">
                    <span aria-hidden className="text-base leading-none">
                      {lang.flag}
                    </span>
                    <span className="font-medium">{lang.label}</span>
                  </span>
                  {active && <Check size={14} className="text-brand-600" />}
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
