import { looksLikeHtml } from "@/lib/html";

type Props = {
  content: string | null | undefined;
  className?: string;
};

/**
 * Affiche du contenu éditorial provenant du CMS. Si le contenu contient du
 * HTML (éditeur riche), il est rendu en tant que HTML ; sinon il est affiché
 * comme texte simple en préservant les sauts de ligne.
 *
 * Le contenu provient de l'administration Filament (source de confiance).
 *
 * @param content Texte ou HTML à afficher
 * @param className Classes CSS additionnelles
 */
export default function RichText({ content, className }: Props) {
  if (!content) {
    return null;
  }

  const classes = `rich-text ${className ?? ""}`.trim();

  if (looksLikeHtml(content)) {
    return (
      <div className={classes} dangerouslySetInnerHTML={{ __html: content }} />
    );
  }

  return <div className={`${classes} whitespace-pre-line`}>{content}</div>;
}
