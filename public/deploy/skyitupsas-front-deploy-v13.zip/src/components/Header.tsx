"use client";

import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import { useTranslations } from "next-intl";
import { Link, usePathname } from "@/i18n/navigation";
import { PATHS } from "@/lib/paths";
import LanguageSwitcher from "./LanguageSwitcher";

/**
 * En-tête principal : logo, navigation desktop/mobile, sélecteur de langue
 * et bouton d'appel à l'action. Devient opaque au défilement.
 */
export default function Header() {
  const t = useTranslations("nav");
  const tCta = useTranslations("cta");
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  const navItems = [
    { label: t("news"), href: PATHS.news },
    { label: t("about"), href: PATHS.about },
    { label: t("services"), href: PATHS.services },
    { label: t("projects"), href: PATHS.projects },
    { label: t("blog"), href: PATHS.blog },
    { label: t("team"), href: PATHS.team },
    { label: t("careers"), href: PATHS.careers },
  ];

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const isActive = (href: string) =>
    href === PATHS.home ? pathname === href : pathname.startsWith(href);

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${
        scrolled
          ? "border-b border-ink-100 bg-white/85 backdrop-blur-md"
          : "border-b border-transparent bg-white/70 backdrop-blur-sm"
      }`}
    >
      <div className="container-page flex h-20 items-center justify-between gap-6">
        <Link href={PATHS.home} className="flex items-center gap-2.5">
          <img src="/images/logo-icon.png" alt="SkyITup" className="h-9 w-9" />
          <span className="font-display text-lg font-bold tracking-tight text-ink-950">
            Sky<span className="text-brand-500">IT</span>up
          </span>
        </Link>

        <nav className="hidden items-center gap-5 xl:gap-7 lg:flex">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`relative text-sm font-medium transition ${
                isActive(item.href)
                  ? "text-ink-950"
                  : "text-ink-700 hover:text-ink-950"
              }`}
            >
              {item.label}
              {isActive(item.href) && (
                <span className="absolute -bottom-2 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-brand-500" />
              )}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <LanguageSwitcher />
          <Link href={PATHS.contact} className="btn-primary">
            {tCta("start")}
          </Link>
        </div>

        <div className="flex items-center gap-2 lg:hidden">
          <LanguageSwitcher />
          <button
            type="button"
            aria-label="Menu"
            onClick={() => setOpen((v) => !v)}
            className="inline-flex items-center justify-center rounded-lg border border-ink-200 p-2"
          >
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {open && (
        <div className="border-t border-ink-100 bg-white lg:hidden">
          <nav className="container-page flex flex-col gap-1 py-4">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className={`rounded-lg px-3 py-3 text-sm font-medium transition ${
                  isActive(item.href)
                    ? "bg-brand-50 text-brand-700"
                    : "text-ink-700 hover:bg-ink-50"
                }`}
              >
                {item.label}
              </Link>
            ))}
            <Link
              href={PATHS.contact}
              onClick={() => setOpen(false)}
              className="btn-primary mt-3"
            >
              {tCta("start")}
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
