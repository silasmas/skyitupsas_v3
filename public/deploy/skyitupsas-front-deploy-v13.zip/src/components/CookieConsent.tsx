"use client";

import { useEffect, useState } from "react";
import { Cookie } from "lucide-react";
import { useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import { PATHS } from "@/lib/paths";

/** Clé de stockage du choix de consentement (conservé jusqu'à effacement). */
const STORAGE_KEY = "skyitup:cookie-consent";

/** Valeurs possibles du consentement enregistré. */
type ConsentChoice = "accepted" | "declined";

/**
 * Bannière de consentement aux cookies (RGPD).
 *
 * Affichée tant qu'aucun choix n'a été enregistré. Le choix est persisté dans
 * `localStorage` et conservé pendant toute la visite et les suivantes, jusqu'à
 * ce que l'utilisateur efface les données de son navigateur.
 */
export default function CookieConsent() {
  const t = useTranslations("cookieConsent");
  const [visible, setVisible] = useState(false);

  // Affiche la bannière uniquement si aucun choix n'a encore été fait.
  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      if (stored !== "accepted" && stored !== "declined") {
        setVisible(true);
      }
    } catch {
      // Stockage indisponible : on affiche la bannière par prudence.
      setVisible(true);
    }
  }, []);

  /**
   * Enregistre le choix de l'utilisateur et masque la bannière.
   *
   * @param choice Choix effectué (acceptation ou refus)
   */
  const handleChoice = (choice: ConsentChoice) => {
    try {
      window.localStorage.setItem(STORAGE_KEY, choice);
    } catch {
      // Stockage indisponible : le choix ne sera pas mémorisé.
    }
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div
      role="dialog"
      aria-label={t("title")}
      aria-live="polite"
      className="fixed inset-x-4 bottom-24 z-50 sm:left-6 sm:right-auto sm:max-w-md sm:bottom-6"
    >
      <div className="overflow-hidden rounded-2xl border border-ink-100 bg-white shadow-2xl">
        <div className="flex items-start gap-3 p-5">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-brand-50 text-brand-600">
            <Cookie size={20} />
          </div>
          <div>
            <h2 className="font-display text-base font-semibold text-ink-950">
              {t("title")}
            </h2>
            <p className="mt-1 text-sm leading-relaxed text-ink-500">
              {t("message")}{" "}
              <Link
                href={PATHS.cookies}
                className="font-medium text-brand-600 underline"
              >
                {t("learnMore")}
              </Link>
            </p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2 border-t border-ink-100 bg-ink-50 px-5 py-3">
          <button
            type="button"
            onClick={() => handleChoice("accepted")}
            className="flex-1 rounded-full bg-brand-500 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-brand-600"
          >
            {t("accept")}
          </button>
          <button
            type="button"
            onClick={() => handleChoice("declined")}
            className="flex-1 rounded-full border border-ink-200 px-4 py-2.5 text-sm font-semibold text-ink-700 transition hover:border-ink-950 hover:text-ink-950"
          >
            {t("decline")}
          </button>
        </div>
      </div>
    </div>
  );
}
