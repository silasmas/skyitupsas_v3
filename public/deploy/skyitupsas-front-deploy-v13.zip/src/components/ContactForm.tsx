"use client";

import { useState, type FormEvent } from "react";
import { Send } from "lucide-react";
import { useLocale, useTranslations } from "next-intl";

const API_BASE_URL =
  process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://127.0.0.1:8000/api/v1";

type FieldErrors = Record<string, string[]>;

/**
 * Formulaire de contact : envoie un message à l'API Laravel (POST /contact)
 * et affiche les erreurs de validation renvoyées (422) champ par champ.
 */
export default function ContactForm() {
  const t = useTranslations("contactPage");
  const locale = useLocale();
  const [status, setStatus] = useState<"idle" | "loading" | "ok" | "error">(
    "idle"
  );
  const [errors, setErrors] = useState<FieldErrors>({});

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setStatus("loading");
    setErrors({});

    const formData = new FormData(event.currentTarget);
    const payload = {
      name: formData.get("name"),
      email: formData.get("email"),
      phone: formData.get("phone"),
      message: formData.get("message"),
      source: "contact_page",
      consent_privacy: formData.get("consent_privacy") === "on",
    };

    try {
      const response = await fetch(`${API_BASE_URL}/contact`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          "X-Locale": locale,
        },
        body: JSON.stringify(payload),
      });

      if (response.status === 422) {
        const data = (await response.json()) as { errors?: FieldErrors };
        setErrors(data.errors ?? {});
        setStatus("error");
        return;
      }
      if (!response.ok) {
        throw new Error("contact_failed");
      }
      setStatus("ok");
      event.currentTarget.reset();
    } catch {
      setStatus("error");
    }
  };

  if (status === "ok") {
    return (
      <div className="flex flex-col items-center justify-center gap-4 rounded-3xl border border-ink-100 bg-ink-50 py-16 text-center">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-brand-500 text-white">
          <Send size={22} />
        </div>
        <p className="max-w-md text-base text-ink-700">{t("success")}</p>
      </div>
    );
  }

  return (
    <form
      onSubmit={handleSubmit}
      noValidate
      className="rounded-3xl border border-ink-100 bg-ink-50 p-6 sm:p-10"
    >
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
        <FormField
          label={t("formName")}
          name="name"
          required
          errors={errors.name}
        />
        <FormField
          label={t("formEmail")}
          name="email"
          type="email"
          required
          errors={errors.email}
        />
        <FormField
          label={t("formPhone")}
          name="phone"
          type="tel"
          errors={errors.phone}
        />
      </div>

      <div className="mt-5">
        <label
          htmlFor="message"
          className="block text-xs font-medium uppercase tracking-wider text-ink-500"
        >
          {t("formMessage")}
          <span className="ml-1 text-brand-500">*</span>
        </label>
        <textarea
          id="message"
          name="message"
          rows={5}
          required
          className="mt-2 w-full rounded-2xl border border-ink-200 bg-white px-4 py-3 text-sm text-ink-900 focus:border-brand-500 focus:outline-none"
        />
        {errors.message && (
          <p className="mt-1 text-xs text-red-500">{errors.message[0]}</p>
        )}
      </div>

      <label className="mt-5 flex items-start gap-3 text-sm text-ink-600">
        <input
          type="checkbox"
          name="consent_privacy"
          required
          className="mt-0.5 h-4 w-4 rounded border-ink-300 text-brand-500 focus:ring-brand-500"
        />
        <span>{t("formConsent")}</span>
      </label>
      {errors.consent_privacy && (
        <p className="mt-1 text-xs text-red-500">{errors.consent_privacy[0]}</p>
      )}

      <button
        type="submit"
        disabled={status === "loading"}
        className="btn-primary mt-7 w-full disabled:opacity-60 sm:w-auto"
      >
        {t("formSubmit")}
        <Send size={14} />
      </button>

      {status === "error" && (
        <p className="mt-4 text-sm text-red-500">{t("error")}</p>
      )}
    </form>
  );
}

type FormFieldProps = {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
  errors?: string[];
};

/**
 * Champ de saisie réutilisable avec libellé et message d'erreur.
 *
 * @param label Libellé du champ
 * @param name Nom du champ (clé envoyée à l'API)
 * @param type Type d'input HTML (défaut: text)
 * @param required Indique si le champ est obligatoire
 * @param errors Messages d'erreur de validation pour ce champ
 */
function FormField({
  label,
  name,
  type = "text",
  required,
  errors,
}: FormFieldProps) {
  return (
    <div>
      <label
        htmlFor={name}
        className="block text-xs font-medium uppercase tracking-wider text-ink-500"
      >
        {label}
        {required && <span className="ml-1 text-brand-500">*</span>}
      </label>
      <input
        id={name}
        type={type}
        name={name}
        required={required}
        className="mt-2 w-full rounded-full border border-ink-200 bg-white px-4 py-3 text-sm text-ink-900 focus:border-brand-500 focus:outline-none"
      />
      {errors && <p className="mt-1 text-xs text-red-500">{errors[0]}</p>}
    </div>
  );
}
