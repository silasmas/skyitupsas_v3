"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { FormEvent } from "react";
import { Bot, MessageCircle, Send, User, X } from "lucide-react";
import { useLocale, useTranslations } from "next-intl";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { usePathname } from "@/i18n/navigation";
import type { Locale } from "@/i18n/routing";
import { normalizeChatReplyLinks, normalizeHref } from "@/lib/chat-links";

/** Message affiché dans le fil de conversation. */
type Message = {
  id: number;
  role: "assistant" | "user";
  text: string;
};

/** Délai d'inactivité (ms) avant la relance proactive du chatbot. */
const IDLE_DELAY_MS = 120_000;

/** Préfixe de la clé de persistance de la conversation (par locale). */
const STORAGE_PREFIX = "skyitup:chat:";

/** Forme de l'état de conversation sauvegardé dans le navigateur. */
type StoredChat = {
  messages?: Message[];
  open?: boolean;
  prompted?: boolean;
};

/**
 * Joue une brève notification sonore via l'API Web Audio (deux notes douces).
 * Aucune ressource externe n'est nécessaire. Échoue silencieusement si le
 * navigateur bloque l'audio (absence d'interaction préalable).
 */
function playNotificationChime(): void {
  try {
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext })
        .webkitAudioContext;
    const context = new AudioCtx();
    const now = context.currentTime;
    const notes = [880, 1174.66];

    notes.forEach((frequency, index) => {
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      const start = now + index * 0.18;
      const end = start + 0.16;

      oscillator.type = "sine";
      oscillator.frequency.value = frequency;
      gain.gain.setValueAtTime(0.0001, start);
      gain.gain.exponentialRampToValueAtTime(0.15, start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, end);

      oscillator.connect(gain);
      gain.connect(context.destination);
      oscillator.start(start);
      oscillator.stop(end);
    });

    window.setTimeout(() => context.close(), 800);
  } catch {
    // Audio indisponible : on ignore silencieusement.
  }
}

/**
 * Rend le contenu Markdown d'un message assistant (gras, italique, listes,
 * liens, retours à la ligne) avec une mise en forme adaptée à la bulle.
 *
 * @param text Contenu Markdown à afficher
 * @param locale Locale active pour corriger les liens internes
 */
function AssistantMarkdown({ text, locale }: { text: string; locale: Locale }) {
  const safeText = normalizeChatReplyLinks(text, locale);

  return (
    <div className="space-y-2 [&_a]:font-medium [&_a]:text-brand-600 [&_a]:underline [&_h1]:text-sm [&_h1]:font-semibold [&_h2]:mt-2 [&_h2]:text-sm [&_h2]:font-semibold [&_h3]:mt-2 [&_h3]:text-xs [&_h3]:font-semibold [&_h3]:uppercase [&_h3]:tracking-wide [&_h3]:text-ink-400 [&_li]:my-0.5 [&_ol]:my-1 [&_ol]:list-decimal [&_ol]:pl-5 [&_p]:m-0 [&_strong]:font-semibold [&_ul]:my-1 [&_ul]:list-disc [&_ul]:pl-5">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          a: ({ href, children }) => {
            const safeHref = href ? normalizeHref(href, locale) : "#";
            const isInternal = safeHref.includes("skyitupsas.org");

            if (isInternal) {
              return <a href={safeHref}>{children}</a>;
            }

            return (
              <a
                href={safeHref}
                target="_blank"
                rel="noopener noreferrer"
              >
                {children}
              </a>
            );
          },
        }}
      >
        {safeText}
      </ReactMarkdown>
    </div>
  );
}

/**
 * Widget de chatbot flottant.
 *
 * Envoie l'historique de conversation au Route Handler `/api/assistant`, qui répond
 * via un LLM si configuré, sinon via un repli par mots-clés. L'état est remonté
 * par locale (clé dans le layout) pour rester dans la bonne langue.
 */
export default function Chatbot() {
  const t = useTranslations("chatbot");
  const locale = useLocale();
  const pathname = usePathname();
  const welcome = t("welcome");
  const suggestions = t.raw("suggestions") as string[];

  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { id: 1, role: "assistant", text: welcome },
  ]);
  const scrollRef = useRef<HTMLDivElement>(null);
  const idleTimerRef = useRef<number | null>(null);
  const promptedRef = useRef(false);
  const [hydrated, setHydrated] = useState(false);
  const storageKey = `${STORAGE_PREFIX}${locale}`;

  useEffect(() => {
    scrollRef.current?.scrollTo({
      top: scrollRef.current.scrollHeight,
      behavior: "smooth",
    });
  }, [messages, loading]);

  // Restaure la conversation persistée au montage (conservée jusqu'à
  // suppression des données du navigateur). L'état par défaut sert de repli.
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(storageKey);
      if (raw) {
        const saved = JSON.parse(raw) as StoredChat;
        if (Array.isArray(saved.messages) && saved.messages.length > 0) {
          setMessages(saved.messages);
        }
        if (typeof saved.open === "boolean") {
          setOpen(saved.open);
        }
        if (saved.prompted) {
          promptedRef.current = true;
        }
      }
    } catch {
      // Stockage indisponible (navigation privée…) : on garde l'état par défaut.
    }
    setHydrated(true);
  }, [storageKey]);

  // Sauvegarde la conversation à chaque évolution, une fois l'hydratation faite
  // (évite d'écraser l'historique restauré par l'état initial).
  useEffect(() => {
    if (!hydrated) {
      return;
    }
    try {
      const payload: StoredChat = {
        messages,
        open,
        prompted: promptedRef.current,
      };
      window.localStorage.setItem(storageKey, JSON.stringify(payload));
    } catch {
      // Stockage indisponible : la persistance est simplement ignorée.
    }
  }, [hydrated, messages, open, storageKey]);

  /**
   * Relance proactive : ouvre le chat, ajoute une note d'assistance et joue
   * un son. Ne se déclenche qu'une seule fois par session.
   */
  const triggerIdlePrompt = useCallback(() => {
    if (promptedRef.current) {
      return;
    }
    promptedRef.current = true;
    setOpen(true);
    setMessages((current) => [
      ...current,
      { id: Date.now(), role: "assistant", text: t("idlePrompt") },
    ]);
    playNotificationChime();
  }, [t]);

  /**
   * (Re)démarre le minuteur d'inactivité. Seuls le changement de page et le
   * défilement repoussent l'échéance (pas souris/clavier).
   */
  const resetIdleTimer = useCallback(() => {
    if (promptedRef.current) {
      return;
    }
    if (idleTimerRef.current) {
      window.clearTimeout(idleTimerRef.current);
    }
    idleTimerRef.current = window.setTimeout(triggerIdlePrompt, IDLE_DELAY_MS);
  }, [triggerIdlePrompt]);

  useEffect(() => {
    resetIdleTimer();
  }, [pathname, resetIdleTimer]);

  useEffect(() => {
    window.addEventListener("scroll", resetIdleTimer, { passive: true });
    resetIdleTimer();

    return () => {
      window.removeEventListener("scroll", resetIdleTimer);
      if (idleTimerRef.current) {
        window.clearTimeout(idleTimerRef.current);
      }
    };
  }, [resetIdleTimer]);

  /**
   * Envoie un message : ajoute le message utilisateur, interroge l'API et
   * ajoute la réponse de l'assistant (ou un message d'erreur en cas d'échec).
   *
   * @param value Texte à envoyer
   */
  const submitMessage = async (value: string) => {
    const trimmed = value.trim();
    if (!trimmed || loading) {
      return;
    }

    const userMessage: Message = { id: Date.now(), role: "user", text: trimmed };
    const history = [...messages, userMessage];

    setMessages(history);
    setInput("");
    setOpen(true);
    setLoading(true);

    try {
      const response = await fetch("/api/assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          locale,
          messages: history.map((message) => ({
            role: message.role,
            content: message.text,
          })),
        }),
      });

      if (!response.ok) {
        throw new Error("chat_failed");
      }

      const data = (await response.json()) as { reply?: string };
      const reply = data.reply?.trim() || t("error");
      setMessages((current) => [
        ...current,
        { id: Date.now() + 1, role: "assistant", text: reply },
      ]);
    } catch {
      setMessages((current) => [
        ...current,
        { id: Date.now() + 1, role: "assistant", text: t("error") },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const onSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    submitMessage(input);
  };

  return (
    <div className="fixed bottom-5 right-5 z-50 sm:bottom-6 sm:right-6">
      {open && (
        <section
          aria-label={t("title")}
          className="mb-4 w-[calc(100vw-2.5rem)] overflow-hidden rounded-3xl border border-ink-100 bg-white shadow-2xl sm:w-96"
        >
          <div className="flex items-center justify-between gap-4 bg-ink-950 px-5 py-4 text-white">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-brand-500">
                <Bot size={20} />
              </div>
              <div>
                <h2 className="font-display text-base font-semibold text-white">
                  {t("title")}
                </h2>
                <p className="flex items-center gap-1.5 text-xs text-ink-200/70">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                  {t("status")}
                </p>
              </div>
            </div>
            <button
              type="button"
              aria-label={t("close")}
              onClick={() => setOpen(false)}
              className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/10 text-ink-200 transition hover:bg-white/10 hover:text-white"
            >
              <X size={18} />
            </button>
          </div>

          <div
            ref={scrollRef}
            className="max-h-80 space-y-4 overflow-y-auto bg-ink-50 px-5 py-5"
          >
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex items-start gap-2 ${
                  message.role === "user" ? "justify-end" : "justify-start"
                }`}
              >
                {message.role === "assistant" && (
                  <div className="mt-1 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-brand-50 text-brand-600">
                    <Bot size={14} />
                  </div>
                )}
                <div
                  className={`max-w-[78%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                    message.role === "user"
                      ? "bg-brand-500 text-white"
                      : "border border-ink-100 bg-white text-ink-700"
                  }`}
                >
                  {message.role === "assistant" ? (
                    <AssistantMarkdown text={message.text} locale={locale as Locale} />
                  ) : (
                    message.text
                  )}
                </div>
                {message.role === "user" && (
                  <div className="mt-1 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-ink-950 text-white">
                    <User size={14} />
                  </div>
                )}
              </div>
            ))}

            {loading && (
              <div className="flex items-start gap-2 justify-start">
                <div className="mt-1 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-brand-50 text-brand-600">
                  <Bot size={14} />
                </div>
                <p className="rounded-2xl border border-ink-100 bg-white px-4 py-3 text-sm italic leading-relaxed text-ink-400">
                  {t("thinking")}
                </p>
              </div>
            )}
          </div>

          <div className="border-t border-ink-100 bg-white p-4">
            <div className="mb-3 flex flex-wrap gap-2">
              {suggestions.map((suggestion) => (
                <button
                  key={suggestion}
                  type="button"
                  disabled={loading}
                  onClick={() => submitMessage(suggestion)}
                  className="rounded-full bg-brand-50 px-3 py-1.5 text-xs font-medium text-brand-700 transition hover:bg-brand-100 disabled:opacity-50"
                >
                  {suggestion}
                </button>
              ))}
            </div>
            <form onSubmit={onSubmit} className="flex items-center gap-2">
              <input
                type="text"
                value={input}
                onChange={(event) => setInput(event.target.value)}
                placeholder={t("inputPlaceholder")}
                className="min-w-0 flex-1 rounded-full border border-ink-200 bg-white px-4 py-3 text-sm text-ink-900 focus:border-brand-500 focus:outline-none"
              />
              <button
                type="submit"
                aria-label={t("send")}
                disabled={loading}
                className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-brand-500 text-white transition hover:bg-brand-600 disabled:opacity-60"
              >
                <Send size={17} />
              </button>
            </form>
          </div>
        </section>
      )}

      <button
        type="button"
        aria-label={open ? t("close") : t("open")}
        onClick={() => setOpen((value) => !value)}
        className="ml-auto flex h-14 w-14 items-center justify-center rounded-full bg-brand-500 text-white shadow-xl shadow-brand-500/25 transition hover:-translate-y-0.5 hover:bg-brand-600"
      >
        {open ? <X size={22} /> : <MessageCircle size={22} />}
      </button>
    </div>
  );
}
