import { ArrowRight, Sparkles } from "lucide-react";
import { useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import { PATHS } from "@/lib/paths";

/** Offre d'emploi mise en avant dans le teaser (titre + clés type/lieu). */
type TeaserJob = {
  title: string;
  typeKey: string;
  locationKey: string;
};

/** Section teaser « Carrières » avec un aperçu des postes ouverts. */
export default function CareersTeaser() {
  const t = useTranslations("careersTeaser");
  const jobs = (t.raw("items") as TeaserJob[]).slice(0, 4);
  const types = t.raw("type") as Record<string, string>;
  const locations = t.raw("location") as Record<string, string>;

  return (
    <section className="bg-white py-24 lg:py-28">
      <div className="container-page">
        <div className="relative overflow-hidden rounded-[2rem] border border-ink-100 bg-gradient-to-br from-ink-50 via-white to-brand-50 p-10 sm:p-14 lg:p-16">
          <div
            aria-hidden
            className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-brand-500/10 blur-3xl"
          />
          <div
            aria-hidden
            className="absolute -bottom-24 -left-10 h-72 w-72 rounded-full bg-ink-950/5 blur-3xl"
          />

          <div className="relative grid grid-cols-1 items-center gap-10 lg:grid-cols-12">
            <div className="lg:col-span-7">
              <span className="eyebrow">
                <Sparkles size={14} className="text-brand-500" />
                {t("eyebrow")}
              </span>
              <h2 className="mt-5 font-display text-3xl font-bold tracking-tight text-ink-950 sm:text-4xl lg:text-5xl">
                {t("teaserTitle")}
              </h2>
              <p className="mt-5 max-w-xl text-base leading-relaxed text-ink-500">
                {t("teaserSubtitle")}
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link href={PATHS.careers} className="btn-primary">
                  {t("teaserCta")}
                  <ArrowRight size={16} />
                </Link>
                <Link href={PATHS.contact} className="btn-ghost">
                  {t("spontaneousCta")}
                </Link>
              </div>
            </div>

            <div className="lg:col-span-5">
              <div className="grid grid-cols-2 gap-3">
                {jobs.map((job) => (
                  <div
                    key={job.title}
                    className="rounded-2xl border border-ink-100 bg-white/80 p-4 backdrop-blur transition hover:-translate-y-1 hover:border-brand-300 hover:shadow-md"
                  >
                    <div className="text-[10px] font-semibold uppercase tracking-widest text-brand-600">
                      {types[job.typeKey] ?? job.typeKey}
                    </div>
                    <div className="mt-2 font-display text-sm font-semibold leading-snug text-ink-950">
                      {job.title}
                    </div>
                    <div className="mt-2 text-xs text-ink-500">
                      {locations[job.locationKey] ?? job.locationKey}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
