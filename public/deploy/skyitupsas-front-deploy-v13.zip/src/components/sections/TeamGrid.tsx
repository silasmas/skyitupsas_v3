import { useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import type { ApiTeamMember } from "@/lib/types";
import { PATHS } from "@/lib/paths";

const LINKEDIN_PATH =
  "M20.45 20.45h-3.56v-5.57c0-1.33-.02-3.04-1.85-3.04-1.85 0-2.13 1.45-2.13 2.94v5.67H9.35V9h3.42v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28zM5.34 7.43a2.07 2.07 0 1 1 0-4.14 2.07 2.07 0 0 1 0 4.14zM7.12 20.45H3.56V9h3.56v11.45zM22.22 0H1.77C.79 0 0 .77 0 1.72v20.55C0 23.23.79 24 1.77 24h20.45c.98 0 1.78-.77 1.78-1.73V1.72C24 .77 23.2 0 22.22 0z";

type Props = {
  members: ApiTeamMember[];
};

/**
 * Grille des membres de l'équipe, alimentée par l'API.
 *
 * @param members Liste des membres à afficher
 */
export default function TeamGrid({ members }: Props) {
  const t = useTranslations("teamPage");

  return (
    <section id="team" className="bg-white py-24 lg:py-32">
      <div className="container-page">
        <div className="max-w-3xl">
          <span className="eyebrow">
            <span className="h-1.5 w-1.5 rounded-full bg-brand-500" />
            {t("eyebrow")}
          </span>
          <h2 className="mt-4 font-display text-4xl font-bold tracking-tight text-ink-950 sm:text-5xl">
            {t("title")}
          </h2>
        </div>

        {members.length === 0 ? (
          <p className="mt-16 text-ink-500">{t("empty")}</p>
        ) : (
          <div className="mt-16 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {members.map((member) => (
              <Link
                key={member.id}
                href={`${PATHS.team}/${member.slug}`}
                className="group block overflow-hidden rounded-3xl border border-ink-100 bg-white transition hover:-translate-y-1 hover:shadow-xl"
              >
                <div className="relative flex aspect-[4/5] items-center justify-center overflow-hidden bg-ink-100">
                  {member.picture ? (
                    <img
                      src={member.picture}
                      alt={member.name}
                      className="absolute inset-0 h-full w-full object-cover transition duration-500 group-hover:scale-105"
                    />
                  ) : (
                    <span className="font-display text-4xl font-bold text-ink-400">
                      {member.initials}
                    </span>
                  )}
                </div>
                <div className="p-6">
                  <h3 className="font-display text-base font-semibold leading-tight text-ink-950">
                    {member.name}
                  </h3>
                  <p className="mt-1 text-sm text-ink-500">{member.role}</p>
                  {member.linkedin && (
                    <div className="mt-4 flex items-center gap-2">
                      <span
                        aria-hidden
                        className="inline-flex h-8 w-8 items-center justify-center rounded-full border border-ink-200 text-ink-700 transition group-hover:border-ink-950 group-hover:bg-ink-950 group-hover:text-white"
                      >
                        <svg
                          aria-hidden
                          viewBox="0 0 24 24"
                          fill="currentColor"
                          className="h-3.5 w-3.5"
                        >
                          <path d={LINKEDIN_PATH} />
                        </svg>
                      </span>
                    </div>
                  )}
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
