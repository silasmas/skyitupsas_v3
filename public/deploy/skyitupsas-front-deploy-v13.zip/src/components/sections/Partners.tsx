import { useTranslations } from "next-intl";

/** Bandeau des partenaires (logos affichés en niveaux de gris). */
export default function Partners() {
  const t = useTranslations("partners");

  return (
    <section className="bg-white py-20">
      <div className="container-page">
        <div className="text-center">
          <span className="eyebrow">
            <span className="h-1.5 w-1.5 rounded-full bg-brand-500" />
            {t("eyebrow")}
          </span>
          <h2 className="mt-4 font-display text-2xl font-semibold text-ink-950 sm:text-3xl">
            {t("title")}
          </h2>
        </div>

        <div className="mt-12 grid grid-cols-2 items-center gap-6 sm:grid-cols-3 lg:grid-cols-6">
          {[1, 2, 3, 4, 5, 6].map((index) => (
            <div
              key={index}
              className="flex h-24 items-center justify-center rounded-2xl border border-ink-100 bg-white px-6 grayscale transition hover:border-brand-300 hover:grayscale-0"
            >
              <img
                src={`/images/partner-${index}.png`}
                alt={`Partenaire ${index}`}
                className="max-h-12 w-auto object-contain opacity-80"
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
