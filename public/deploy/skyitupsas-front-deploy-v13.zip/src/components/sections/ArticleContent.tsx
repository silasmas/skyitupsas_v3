import { ArrowLeft, Clock } from "lucide-react";
import { Link } from "@/i18n/navigation";
import RichText from "@/components/RichText";
import type { ApiBlog } from "@/lib/types";
import { formatDate, readingTime } from "@/lib/format";

type Props = {
  article: ApiBlog;
  locale: string;
  backHref: string;
  backLabel: string;
  readTimeLabel: string;
};

/**
 * Corps d'un article (blog ou actualité) : lien de retour, métadonnées,
 * image à la une et contenu riche.
 *
 * @param article Article à afficher
 * @param locale Code langue (fr|en) pour le formatage de la date
 * @param backHref Chemin de retour vers la liste
 * @param backLabel Libellé du lien de retour
 * @param readTimeLabel Suffixe du temps de lecture (ex. « min de lecture »)
 */
export default function ArticleContent({
  article,
  locale,
  backHref,
  backLabel,
  readTimeLabel,
}: Props) {
  const date = formatDate(article.published_at, locale);
  const minutes = readingTime(article.content);

  return (
    <article className="bg-white py-16 lg:py-24">
      <div className="container-page mx-auto max-w-3xl">
        <Link
          href={backHref}
          className="inline-flex items-center gap-2 text-sm font-semibold text-ink-500 transition hover:text-brand-600"
        >
          <ArrowLeft size={15} />
          {backLabel}
        </Link>

        <div className="mt-6 flex flex-wrap items-center gap-3 text-xs font-medium uppercase tracking-wider text-ink-400">
          {date && <span>{date}</span>}
          {date && <span aria-hidden>·</span>}
          <span className="inline-flex items-center gap-1">
            <Clock size={13} /> {minutes} {readTimeLabel}
          </span>
        </div>

        {article.excerpt && (
          <p className="mt-6 text-lg leading-relaxed text-ink-700">
            {article.excerpt}
          </p>
        )}

        {article.featured_image && (
          <div className="mt-8 overflow-hidden rounded-3xl border border-ink-100">
            <img
              src={article.featured_image}
              alt={article.title}
              className="w-full object-cover"
            />
          </div>
        )}

        <RichText content={article.content} className="mt-10" />
      </div>
    </article>
  );
}
