import {
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  Brain,
  GraduationCap,
  Server,
  ShieldCheck,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import type { ApiServicePillar } from "@/lib/types";
import { PATHS } from "@/lib/paths";

/** Icônes par défaut pour les 5 piliers. */
const PILLAR_ICONS: LucideIcon[] = [
  BarChart3,
  Brain,
  ShieldCheck,
  GraduationCap,
  Server,
];

type Props = {
  pillars: ApiServicePillar[];
};

/**
 * Teaser compact des 5 piliers pour l'accueil.
 *
 * Affiche un résumé (numéro, titre, enjeu) qui invite à ouvrir
 * la page Services pour le détail des modules.
 *
 * @param pillars Liste des piliers actifs
 */
export default function ServicesPillarsTeaser({ pillars }: Props) {
  const t = useTranslations("servicesSection");

  return (
    <section id="services" className="bg-white py-20 lg:py-28">
      <div className="container-page">
        <div className="grid grid-cols-1 items-end gap-6 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <span className="eyebrow">
              <span className="h-1.5 w-1.5 rounded-full bg-brand-500" />
              {t("eyebrow")}
            </span>
            <h2 className="mt-4 font-display text-3xl font-bold tracking-tight text-ink-950 sm:text-4xl">
              {t("teaserTitle1")}
              <br />
              {t("teaserTitle2")}
            </h2>
          </div>
          <p className="text-base leading-relaxed text-ink-500 lg:col-span-5">
            {t("teaserIntro")}
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-px overflow-hidden rounded-2xl border border-ink-100 bg-ink-100 sm:grid-cols-2 lg:grid-cols-5">
          {pillars.map((pillar, index) => {
            const Icon = PILLAR_ICONS[index % PILLAR_ICONS.length] ?? BarChart3;
            const summary =
              pillar.client_challenge || pillar.offer_summary || "";

            return (
              <Link
                key={pillar.id}
                href={`${PATHS.services}/${pillar.slug}`}
                className="group relative flex flex-col bg-white p-5 transition hover:bg-ink-50 sm:p-6"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand-50 ring-1 ring-brand-100 transition group-hover:bg-brand-500 group-hover:ring-brand-500">
                    <Icon
                      size={18}
                      className="text-brand-600 transition group-hover:text-white"
                    />
                  </div>
                  <span className="font-display text-xs font-semibold tabular-nums text-ink-300">
                    {String(index + 1).padStart(2, "0")}
                  </span>
                </div>

                <h3 className="mt-5 line-clamp-3 font-display text-base font-semibold leading-snug text-ink-950 group-hover:text-brand-700">
                  {pillar.title}
                </h3>

                {summary ? (
                  <p className="mt-2 line-clamp-2 flex-1 text-sm leading-relaxed text-ink-500">
                    {summary}
                  </p>
                ) : null}

                <span className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-brand-600 opacity-0 transition group-hover:opacity-100">
                  {t("teaserDiscover")}
                  <ArrowUpRight
                    size={14}
                    className="transition group-hover:-translate-y-0.5 group-hover:translate-x-0.5"
                  />
                </span>
              </Link>
            );
          })}
        </div>

        <div className="mt-10 flex justify-center">
          <Link href={PATHS.services} className="btn-secondary">
            {t("teaserCta")}
            <ArrowRight size={16} />
          </Link>
        </div>
      </div>
    </section>
  );
}
