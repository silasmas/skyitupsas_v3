import {
  Briefcase,
  FileText,
  Globe,
  LayoutDashboard,
  Package,
  Users,
  Wallet,
  Workflow,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { useTranslations } from "next-intl";

/** Icônes attribuées aux solutions par ordre d'affichage. */
const ICONS: LucideIcon[] = [
  Briefcase,
  Globe,
  LayoutDashboard,
  FileText,
  Users,
  Wallet,
  Package,
  Workflow,
];

/** Solution packagée (titre + description). */
type SolutionItem = {
  title: string;
  description: string;
};

/** Section présentant le catalogue de solutions packagées. */
export default function Solutions() {
  const t = useTranslations("solutions");
  const items = t.raw("items") as SolutionItem[];

  return (
    <section id="solutions" className="bg-white py-24 lg:py-32">
      <div className="container-page">
        <div className="max-w-3xl">
          <span className="eyebrow">
            <span className="h-1.5 w-1.5 rounded-full bg-brand-500" />
            {t("eyebrow")}
          </span>
          <h2 className="mt-4 font-display text-4xl font-bold tracking-tight text-ink-950 sm:text-5xl">
            {t("title1")}
            <br />
            {t("title2")}
          </h2>
          <p className="mt-6 text-base leading-relaxed text-ink-500">
            {t("intro")}
          </p>
        </div>

        <div className="mt-16 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {items.map((item, index) => {
            const Icon = ICONS[index] ?? Briefcase;
            return (
              <div
                key={item.title}
                className="group rounded-2xl border border-ink-100 bg-white p-6 transition hover:border-ink-950 hover:shadow-lg"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-ink-50 transition group-hover:bg-brand-500">
                  <Icon
                    size={18}
                    className="text-ink-700 transition group-hover:text-white"
                  />
                </div>
                <h3 className="mt-5 font-display text-base font-semibold text-ink-950">
                  {item.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-ink-500">
                  {item.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
