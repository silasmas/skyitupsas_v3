import { Eye, Heart, Target } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { useTranslations } from "next-intl";

/** Icônes des piliers (mission, vision, valeurs). */
const ICONS: LucideIcon[] = [Target, Eye, Heart];

/** Pilier de l'entreprise (titre + description). */
type Pillar = {
  title: string;
  description: string;
};

/** Section « À propos » de la page d'accueil (intro + piliers). */
export default function AboutSection() {
  const t = useTranslations("aboutSection");
  const pillars = t.raw("pillars") as Pillar[];

  return (
    <section id="about" className="bg-ink-50 py-24 lg:py-32">
      <div className="container-page">
        <div className="grid grid-cols-1 gap-16 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <span className="eyebrow">
              <span className="h-1.5 w-1.5 rounded-full bg-brand-500" />
              {t("eyebrow")}
            </span>
            <h2 className="mt-4 font-display text-4xl font-bold tracking-tight text-ink-950 sm:text-5xl">
              {t("title1")}
              <br />
              <span className="text-brand-500">{t("title2")}</span>
            </h2>
            <p className="mt-6 text-base leading-relaxed text-ink-500">
              {t("intro1")}
            </p>
            <p className="mt-4 text-base leading-relaxed text-ink-500">
              {t("intro2")}
            </p>
          </div>

          <div className="lg:col-span-7">
            <div className="grid grid-cols-1 gap-4">
              {pillars.map((pillar, index) => {
                const Icon = ICONS[index] ?? Target;
                return (
                  <div
                    key={pillar.title}
                    className="flex gap-6 rounded-3xl border border-ink-100 bg-white p-8 transition hover:border-brand-200"
                  >
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-brand-50 ring-1 ring-brand-100">
                      <Icon size={20} className="text-brand-600" />
                    </div>
                    <div>
                      <h3 className="font-display text-xl font-semibold text-ink-950">
                        {pillar.title}
                      </h3>
                      <p className="mt-2 text-sm leading-relaxed text-ink-500">
                        {pillar.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
