import { useTranslations } from "next-intl";

/** Élément de statistique (valeur mise en avant + libellé). */
type StatItem = {
  value: string;
  label: string;
};

/** Bandeau de chiffres clés affiché sous le Hero, en chevauchement. */
export default function Stats() {
  const t = useTranslations("stats");
  const items = t.raw("items") as StatItem[];

  return (
    <section className="relative -mt-12 pb-24">
      <div className="container-page">
        <div className="grid grid-cols-2 gap-px overflow-hidden rounded-3xl border border-ink-100 bg-ink-100 shadow-xl shadow-ink-900/5 lg:grid-cols-4">
          {items.map((item) => (
            <div
              key={item.label}
              className="bg-white p-8 transition hover:bg-ink-50"
            >
              <div className="font-display text-4xl font-bold tracking-tight text-ink-950 lg:text-5xl">
                {item.value}
              </div>
              <div className="mt-2 text-sm leading-snug text-ink-500">
                {item.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
