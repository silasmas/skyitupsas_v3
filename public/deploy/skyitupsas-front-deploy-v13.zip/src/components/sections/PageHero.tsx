import { useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import { PATHS } from "@/lib/paths";

type Crumb = { label: string; href?: string };

type Props = {
  eyebrow: string;
  title: string;
  crumbs?: Crumb[];
  background?: string;
};

/**
 * Bannière d'en-tête des pages internes, avec fil d'Ariane.
 *
 * @param eyebrow Sur-titre affiché au-dessus du titre
 * @param title Titre principal de la page
 * @param crumbs Éléments du fil d'Ariane après « Accueil »
 * @param background Image de fond (chemin public)
 */
export default function PageHero({
  eyebrow,
  title,
  crumbs = [],
  background = "/images/slider-3.png",
}: Props) {
  const t = useTranslations("common");
  const items: Crumb[] = [
    { label: t("breadcrumbHome"), href: PATHS.home },
    ...crumbs,
  ];

  return (
    <section className="relative overflow-hidden bg-ink-950 pb-20 pt-32 lg:pt-40 text-white">
      <div
        aria-hidden
        className="absolute inset-0 -z-0 bg-cover bg-center opacity-25"
        style={{ backgroundImage: `url(${background})` }}
      />
      <div
        aria-hidden
        className="absolute inset-0 -z-0 bg-gradient-to-r from-ink-950 via-ink-950/90 to-ink-950/40"
      />
      <div
        aria-hidden
        className="absolute right-0 top-0 -z-0 h-full w-1/2"
        style={{
          background:
            "radial-gradient(circle at 80% 30%, rgba(248,154,33,0.25), transparent 60%)",
        }}
      />

      <div className="container-page relative">
        <nav
          aria-label="Breadcrumb"
          className="flex flex-wrap items-center gap-2 text-xs font-medium uppercase tracking-widest text-ink-200/70"
        >
          {items.map((c, i) => (
            <span key={i} className="flex items-center gap-2">
              {i > 0 && <span aria-hidden>/</span>}
              {c.href ? (
                <Link href={c.href} className="hover:text-brand-500">
                  {c.label}
                </Link>
              ) : (
                <span className="text-brand-500">{c.label}</span>
              )}
            </span>
          ))}
        </nav>

        <div className="mt-6 flex items-start gap-3">
          <div className="mt-3 h-px w-10 bg-brand-500" aria-hidden />
          <span className="text-xs font-semibold uppercase tracking-[0.25em] text-brand-500">
            {eyebrow}
          </span>
        </div>

        <h1 className="mt-4 max-w-3xl font-display text-4xl font-bold leading-tight tracking-tight text-white sm:text-5xl lg:text-6xl">
          {title}
        </h1>
      </div>
    </section>
  );
}
