import {
  ArrowUpRight,
  Boxes,
  Code2,
  GraduationCap,
  LifeBuoy,
  Plug,
  ShieldCheck,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import type { ApiService } from "@/lib/types";
import { stripHtml } from "@/lib/html";
import { PATHS } from "@/lib/paths";

/** Icônes attribuées aux services par ordre d'affichage. */
const ICONS: LucideIcon[] = [
  Code2,
  Boxes,
  ShieldCheck,
  GraduationCap,
  Plug,
  LifeBuoy,
];

type Props = {
  services: ApiService[];
  showHeading?: boolean;
};

/**
 * Grille des services, alimentée par l'API Laravel.
 *
 * @param services Liste des services à afficher
 * @param showHeading Affiche l'en-tête de section (titre + intro)
 */
export default function ServicesGrid({ services, showHeading = true }: Props) {
  const t = useTranslations("servicesSection");

  return (
    <section id="services" className="bg-white py-24 lg:py-32">
      <div className="container-page">
        {showHeading && (
          <div className="grid grid-cols-1 items-end gap-8 lg:grid-cols-12">
            <div className="lg:col-span-7">
              <span className="eyebrow">
                <span className="h-1.5 w-1.5 rounded-full bg-brand-500" />
                {t("eyebrow")}
              </span>
              <h2 className="mt-4 font-display text-4xl font-bold tracking-tight text-ink-950 sm:text-5xl">
                {t("title1")}
                <br />
                {t("title2")}
              </h2>
            </div>
            <p className="text-base leading-relaxed text-ink-500 lg:col-span-5">
              {t("intro")}
            </p>
          </div>
        )}

        <div className="mt-16 grid grid-cols-1 gap-px overflow-hidden rounded-3xl border border-ink-100 bg-ink-100 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service, i) => {
            const Icon = ICONS[i % ICONS.length] ?? Code2;
            return (
              <Link
                key={service.id}
                href={`${PATHS.services}/${service.slug}`}
                className="group relative block bg-white p-8 transition hover:bg-ink-50"
              >
                <div className="flex items-start justify-between">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-50 ring-1 ring-brand-100 transition group-hover:bg-brand-500 group-hover:ring-brand-500">
                    <Icon
                      size={22}
                      className="text-brand-600 transition group-hover:text-white"
                    />
                  </div>
                  <ArrowUpRight
                    size={18}
                    className="text-ink-300 transition group-hover:-translate-y-1 group-hover:translate-x-1 group-hover:text-ink-950"
                  />
                </div>
                <h3 className="mt-6 font-display text-xl font-semibold text-ink-950">
                  {service.title}
                </h3>
                <p className="mt-3 text-sm leading-relaxed text-ink-500">
                  {stripHtml(service.description)}
                </p>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}
