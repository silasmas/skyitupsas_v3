import { ArrowRight, BarChart3, Code2, Database, Sparkles } from "lucide-react";
import { useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import { PATHS } from "@/lib/paths";

/** Section d'accroche de la page d'accueil (titre, sous-titre, visuel animé). */
export default function Hero() {
  const t = useTranslations("hero");
  const tCta = useTranslations("cta");

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-ink-50 to-white pt-12 pb-24 lg:pt-20 lg:pb-32">
      <div
        aria-hidden
        className="absolute inset-x-0 top-0 -z-10 h-[520px] bg-[radial-gradient(circle_at_50%_0%,rgba(248,154,33,0.18),transparent_60%)]"
      />

      <div className="container-page grid grid-cols-1 items-center gap-16 lg:grid-cols-12">
        <div className="lg:col-span-7">
          <span className="eyebrow">
            <Sparkles size={14} className="text-brand-500" />
            {t("eyebrow")}
          </span>

          <h1 className="mt-6 font-display text-4xl leading-[1.05] font-bold tracking-tight text-ink-950 sm:text-5xl lg:text-6xl xl:text-7xl">
            {t("title1")}
            <br />
            {t("title2")}
            <br />
            <span className="relative inline-block">
              {t("title3")}
              <svg
                aria-hidden
                viewBox="0 0 300 12"
                className="absolute -bottom-2 left-0 w-full text-brand-500"
                fill="none"
              >
                <path
                  d="M2 8 Q 75 2 150 6 T 298 4"
                  stroke="currentColor"
                  strokeWidth="3"
                  strokeLinecap="round"
                />
              </svg>
            </span>
            .
          </h1>

          <p className="mt-8 max-w-xl text-lg leading-relaxed text-ink-500">
            {t("subtitle")}
          </p>

          <div className="mt-10 flex flex-wrap items-center gap-4">
            <Link href={PATHS.contact} className="btn-primary">
              {tCta("start")}
              <ArrowRight size={16} />
            </Link>
            <Link href={PATHS.services} className="btn-ghost">
              {tCta("discover")}
            </Link>
          </div>

          <div className="mt-12 flex flex-wrap items-center gap-x-8 gap-y-3 text-sm text-ink-500">
            <span className="font-medium text-ink-700">{t("trust")}</span>
            <div className="flex flex-wrap items-center gap-5 opacity-80">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <img
                  key={i}
                  src={`/images/partner-${i}.png`}
                  alt={`Partner ${i}`}
                  className="h-7 w-auto object-contain grayscale opacity-70 transition hover:grayscale-0 hover:opacity-100"
                />
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-5">
          <div className="relative pb-10">
            <div className="relative aspect-[4/5] min-h-[480px] overflow-hidden rounded-3xl bg-ink-950 shadow-2xl lg:min-h-[560px]">
              <img
                src="/images/welcomer.jpg"
                alt="Équipe SkyITup"
                className="absolute inset-0 h-full w-full object-cover"
              />
              <div
                aria-hidden
                className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/40 to-transparent"
              />
              <div className="absolute inset-x-0 bottom-36 p-8">
                <div className="w-full">
                  <div className="text-xs font-medium uppercase tracking-widest text-brand-300">
                    SkyITup
                  </div>
                  <div className="mt-2 font-display text-2xl font-bold text-white">
                    {t("overlayTitle1")}
                    <br />
                    {t("overlayTitle2")}
                  </div>
                </div>
              </div>
            </div>

            <div className="absolute -left-6 top-12 hidden w-56 rounded-2xl border border-ink-100 bg-white p-4 shadow-xl animate-float sm:block">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand-50">
                  <Code2 size={18} className="text-brand-600" />
                </div>
                <div>
                  <div className="text-xs font-medium uppercase tracking-wider text-ink-400">
                    {t("cardBuildLabel")}
                  </div>
                  <div className="font-display text-sm font-semibold">
                    {t("cardBuild")}
                  </div>
                </div>
              </div>
              <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-ink-100">
                <div className="h-full w-3/4 rounded-full bg-brand-500" />
              </div>
            </div>

            <div className="absolute -right-4 top-1/3 hidden w-52 rounded-2xl border border-ink-100 bg-white p-4 shadow-xl animate-float-delay sm:block">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium uppercase tracking-wider text-ink-400">
                  {t("cardErp")}
                </span>
                <Database size={16} className="text-ink-400" />
              </div>
              <div className="mt-2 font-display text-2xl font-bold text-ink-950">
                98.4%
              </div>
              <div className="text-xs text-ink-500">{t("cardErpLabel")}</div>
            </div>

            <div className="absolute -bottom-10 left-8 hidden w-60 rounded-2xl border border-ink-100 bg-white p-4 shadow-xl animate-float sm:block">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-ink-950">
                  <BarChart3 size={18} className="text-brand-500" />
                </div>
                <div className="flex-1">
                  <div className="font-display text-sm font-semibold">
                    {t("cardDash")}
                  </div>
                  <div className="text-xs text-ink-500">{t("cardDashSub")}</div>
                </div>
              </div>
              <div className="mt-3 flex items-end gap-1">
                {[40, 70, 55, 85, 60, 92, 75].map((h, i) => (
                  <div
                    key={i}
                    className="flex-1 rounded-t bg-gradient-to-t from-brand-200 to-brand-500"
                    style={{ height: `${h * 0.3}px` }}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
