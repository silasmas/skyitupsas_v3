import {
  ArrowUpRight,
  BarChart3,
  Brain,
  GraduationCap,
  Server,
  ShieldCheck,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import type { ApiServicePillar } from "@/lib/types";
import { stripHtml } from "@/lib/html";
import { PATHS } from "@/lib/paths";

/** Icônes par défaut pour les 5 piliers. */
const PILLAR_ICONS: LucideIcon[] = [
  BarChart3,
  Brain,
  ShieldCheck,
  GraduationCap,
  Server,
];

type Props = {
  pillars: ApiServicePillar[];
  showHeading?: boolean;
  showModules?: boolean;
};

/**
 * Grille / sections des piliers stratégiques de services (API Laravel).
 *
 * @param pillars Liste des piliers avec modules optionnels
 * @param showHeading Affiche l'en-tête de section
 * @param showModules Affiche les modules sous chaque pilier
 */
export default function ServicesPillars({
  pillars,
  showHeading = true,
  showModules = true,
}: Props) {
  const t = useTranslations("servicesSection");

  return (
    <section id="services" className="bg-white py-24 lg:py-32">
      <div className="container-page">
        {showHeading && (
          <div className="grid grid-cols-1 items-end gap-8 lg:grid-cols-12">
            <div className="lg:col-span-7">
              <span className="eyebrow">
                <span className="h-1.5 w-1.5 rounded-full bg-brand-500" />
                {t("eyebrow")}
              </span>
              <h2 className="mt-4 font-display text-4xl font-bold tracking-tight text-ink-950 sm:text-5xl">
                {t("title1")}
                <br />
                {t("title2")}
              </h2>
            </div>
            <p className="text-base leading-relaxed text-ink-500 lg:col-span-5">
              {t("intro")}
            </p>
          </div>
        )}

        <div className="mt-16 space-y-16">
          {pillars.map((pillar, index) => {
            const Icon = PILLAR_ICONS[index % PILLAR_ICONS.length] ?? BarChart3;
            const modules = pillar.modules ?? [];

            return (
              <article
                key={pillar.id}
                id={pillar.slug}
                className="overflow-hidden rounded-3xl border border-ink-100 bg-ink-50/40"
              >
                <div className="grid grid-cols-1 gap-0 lg:grid-cols-12">
                  <div className="border-b border-ink-100 bg-white p-8 lg:col-span-5 lg:border-b-0 lg:border-r lg:p-10">
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-50 ring-1 ring-brand-100">
                      <Icon size={22} className="text-brand-600" />
                    </div>
                    <p className="mt-6 text-xs font-semibold uppercase tracking-wider text-brand-600">
                      {t("pillarLabel")} {index + 1}
                    </p>
                    <h3 className="mt-2 font-display text-2xl font-bold text-ink-950">
                      {pillar.title}
                    </h3>
                    {pillar.tagline && (
                      <p className="mt-4 text-sm italic leading-relaxed text-ink-600">
                        « {pillar.tagline} »
                      </p>
                    )}
                    {pillar.client_challenge && (
                      <p className="mt-4 text-sm text-ink-500">
                        <span className="font-semibold text-ink-700">
                          {t("clientChallenge")} :
                        </span>{" "}
                        {pillar.client_challenge}
                      </p>
                    )}
                    {pillar.offer_summary && (
                      <p className="mt-2 text-sm text-ink-500">
                        <span className="font-semibold text-ink-700">
                          {t("ourOffer")} :
                        </span>{" "}
                        {pillar.offer_summary}
                      </p>
                    )}
                    <Link
                      href={`${PATHS.services}/${pillar.slug}`}
                      className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-brand-600 transition hover:text-brand-700"
                    >
                      {t("explorePillar")}
                      <ArrowUpRight size={16} />
                    </Link>
                  </div>

                  <div className="p-8 lg:col-span-7 lg:p-10">
                    {showModules && modules.length > 0 ? (
                      <ul className="space-y-4">
                        {modules.map((module) => (
                          <li key={module.id}>
                            <Link
                              href={`${PATHS.services}/${pillar.slug}/${module.slug}`}
                              className="group flex items-start justify-between gap-4 rounded-2xl border border-ink-100 bg-white p-5 transition hover:border-brand-200 hover:shadow-sm"
                            >
                              <div>
                                <h4 className="font-display text-lg font-semibold text-ink-950 group-hover:text-brand-700">
                                  {module.title}
                                </h4>
                                <p className="mt-2 text-sm leading-relaxed text-ink-500">
                                  {stripHtml(
                                    module.summary_text || module.benefit_text || ""
                                  ).slice(0, 180)}
                                  {(module.summary_text || module.benefit_text || "")
                                    .length > 180
                                    ? "…"
                                    : ""}
                                </p>
                              </div>
                              <ArrowUpRight
                                size={18}
                                className="mt-1 shrink-0 text-ink-300 transition group-hover:text-brand-600"
                              />
                            </Link>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-sm text-ink-500">{pillar.offer_summary}</p>
                    )}

                    {pillar.differentiator && (
                      <p className="mt-6 rounded-2xl border border-brand-100 bg-brand-50/50 p-4 text-sm leading-relaxed text-ink-700">
                        {stripHtml(pillar.differentiator)}
                      </p>
                    )}
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
