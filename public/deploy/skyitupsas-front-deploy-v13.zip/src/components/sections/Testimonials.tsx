import { Quote } from "lucide-react";
import { useTranslations } from "next-intl";

/** Témoignage client (citation + auteur). */
type Testimonial = {
  quote: string;
  name: string;
  role: string;
  company: string;
};

/**
 * Construit les initiales à partir d'un nom complet.
 *
 * @param name Nom complet de l'auteur du témoignage
 * @returns Les deux premières initiales en majuscules, ou « · » si vide
 */
function buildInitials(name: string): string {
  const initials = name
    .split(" ")
    .map((part) => part[0])
    .filter(Boolean)
    .slice(0, 2)
    .join("")
    .toUpperCase();
  return initials || "·";
}

/** Section des témoignages clients. */
export default function Testimonials() {
  const t = useTranslations("testimonials");
  const items = t.raw("items") as Testimonial[];

  return (
    <section className="bg-ink-50 py-24 lg:py-32">
      <div className="container-page">
        <div className="max-w-3xl">
          <span className="eyebrow">
            <span className="h-1.5 w-1.5 rounded-full bg-brand-500" />
            {t("eyebrow")}
          </span>
          <h2 className="mt-4 font-display text-4xl font-bold tracking-tight text-ink-950 sm:text-5xl">
            {t("title1")}
            <br />
            {t("title2")}
          </h2>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-6 lg:grid-cols-3">
          {items.map((item, index) => (
            <article
              key={index}
              className="flex flex-col rounded-3xl border border-ink-100 bg-white p-8 transition hover:border-brand-200 hover:shadow-lg"
            >
              <Quote size={28} className="text-brand-500" />
              <p className="mt-6 flex-1 text-base leading-relaxed text-ink-700">
                « {item.quote} »
              </p>
              <div className="mt-8 flex items-center gap-4 border-t border-ink-100 pt-6">
                <div className="flex h-11 w-11 items-center justify-center rounded-full bg-ink-950 font-display text-sm font-semibold text-brand-500">
                  {buildInitials(item.name)}
                </div>
                <div>
                  <div className="font-display text-sm font-semibold text-ink-950">
                    {item.name}
                  </div>
                  <div className="text-xs text-ink-500">
                    {item.role} · {item.company}
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
