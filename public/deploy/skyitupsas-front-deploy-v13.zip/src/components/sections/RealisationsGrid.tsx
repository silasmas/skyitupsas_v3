import { ArrowUpRight } from "lucide-react";
import { useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import type { ApiRealisation } from "@/lib/types";
import { stripHtml } from "@/lib/html";
import { PATHS } from "@/lib/paths";

type Props = {
  realisations: ApiRealisation[];
};

/**
 * Grille des réalisations, alimentée par l'API.
 *
 * @param realisations Liste des projets à afficher
 */
export default function RealisationsGrid({ realisations }: Props) {
  const t = useTranslations("projectsPage");

  return (
    <section className="bg-white py-24 lg:py-32">
      <div className="container-page">
        {realisations.length === 0 ? (
          <p className="text-ink-500">{t("empty")}</p>
        ) : (
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            {realisations.map((item) => (
              <Link
                key={item.id}
                href={`${PATHS.projects}/${item.slug}`}
                className="group block overflow-hidden rounded-3xl border border-ink-100 bg-white transition hover:-translate-y-1 hover:shadow-xl"
              >
                <div className="relative aspect-[16/10] overflow-hidden bg-ink-100">
                  {item.featured_image && (
                    <img
                      src={item.featured_image}
                      alt={item.title}
                      className="absolute inset-0 h-full w-full object-cover transition duration-500 group-hover:scale-105"
                    />
                  )}
                </div>
                <div className="p-6">
                  {item.client && (
                    <div className="text-xs font-medium uppercase tracking-wider text-brand-600">
                      {item.client}
                    </div>
                  )}
                  <h3 className="mt-2 font-display text-lg font-semibold leading-tight text-ink-950">
                    {item.title}
                  </h3>
                  <p className="mt-3 line-clamp-3 text-sm leading-relaxed text-ink-500">
                    {stripHtml(item.description)}
                  </p>
                  <span className="mt-5 inline-flex items-center gap-1 text-sm font-semibold text-ink-950 transition group-hover:text-brand-600">
                    {t("viewProject")}
                    <ArrowUpRight size={15} />
                  </span>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
