import { useTranslations } from "next-intl";

/** Étape de la méthodologie (titre + description). */
type ProcessStep = {
  title: string;
  description: string;
};

/** Section méthodologie : présentation des étapes de collaboration. */
export default function Process() {
  const t = useTranslations("process");
  const steps = t.raw("steps") as ProcessStep[];

  return (
    <section id="process" className="bg-ink-950 py-24 text-white lg:py-32">
      <div className="container-page">
        <div className="grid grid-cols-1 items-end gap-8 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <span className="eyebrow-dark">
              <span className="h-1.5 w-1.5 rounded-full bg-brand-500" />
              {t("eyebrow")}
            </span>
            <h2 className="mt-4 font-display text-4xl font-bold tracking-tight text-white sm:text-5xl">
              {t("title1")}
              <br />
              {t("title2")}
            </h2>
          </div>
          <p className="text-base leading-relaxed text-ink-200/80 lg:col-span-4">
            {t("intro")}
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((step, index) => (
            <div
              key={step.title}
              className="relative rounded-3xl border border-white/10 bg-white/[0.03] p-8 transition hover:border-brand-500/40 hover:bg-white/[0.06]"
            >
              <div className="flex items-baseline justify-between">
                <span className="font-display text-5xl font-bold text-brand-500">
                  {String(index + 1).padStart(2, "0")}
                </span>
              </div>
              <h3 className="mt-6 font-display text-xl font-semibold text-white">
                {step.title}
              </h3>
              <p className="mt-3 text-sm leading-relaxed text-ink-200/80">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
