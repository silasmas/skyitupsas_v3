import { ArrowUpRight } from "lucide-react";
import { useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import { PATHS } from "@/lib/paths";

/** Tonalités visuelles alternées des cartes de réalisations. */
const TONES = ["dark", "light", "brand", "light"] as const;
type Tone = (typeof TONES)[number];

/** Classes Tailwind associées à chaque tonalité de carte. */
const STYLES: Record<
  Tone,
  {
    card: string;
    sector: string;
    title: string;
    text: string;
    label: string;
    result: string;
    tag: string;
  }
> = {
  light: {
    card: "bg-white border-ink-100",
    sector: "text-brand-600",
    title: "text-ink-950",
    text: "text-ink-500",
    label: "text-ink-400",
    result: "bg-ink-50 text-ink-900",
    tag: "border-ink-200 text-ink-700",
  },
  dark: {
    card: "bg-ink-950 border-ink-800",
    sector: "text-brand-400",
    title: "text-white",
    text: "text-ink-200/80",
    label: "text-ink-400",
    result: "bg-white/5 text-white",
    tag: "border-white/10 text-ink-100",
  },
  brand: {
    card: "bg-brand-500 border-brand-500",
    sector: "text-ink-950",
    title: "text-ink-950",
    text: "text-ink-950/80",
    label: "text-ink-950/60",
    result: "bg-white/30 text-ink-950",
    tag: "border-ink-950/20 text-ink-950",
  },
};

/** Stacks techniques illustratives affichées par carte. */
const STACKS = [
  ["React", "Node.js", "PostgreSQL"],
  ["Odoo", "Python", "PostgreSQL"],
  ["React Native", "Laravel", "MySQL"],
  ["Next.js", "Metabase", "BigQuery"],
];

/** Réalisation mise en avant sur la page d'accueil. */
type ShowcaseItem = {
  sectorKey: string;
  title: string;
  problem: string;
  result: string;
};

/** Section vitrine des réalisations (études de cas) de la page d'accueil. */
export default function ProjectsShowcase() {
  const t = useTranslations("projectsShowcase");
  const tCta = useTranslations("cta");
  const items = t.raw("items") as ShowcaseItem[];
  const sectors = t.raw("sectors") as Record<string, string>;

  return (
    <section id="projects" className="bg-ink-50 py-24 lg:py-32">
      <div className="container-page">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <span className="eyebrow">
              <span className="h-1.5 w-1.5 rounded-full bg-brand-500" />
              {t("eyebrow")}
            </span>
            <h2 className="mt-4 font-display text-4xl font-bold tracking-tight text-ink-950 sm:text-5xl">
              {t("title1")}
              <br />
              {t("title2")}
            </h2>
          </div>
          <Link href={PATHS.contact} className="btn-ghost">
            {tCta("discuss")}
            <ArrowUpRight size={16} />
          </Link>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-6 lg:grid-cols-2">
          {items.map((item, index) => {
            const tone: Tone = TONES[index % TONES.length];
            const styles = STYLES[tone];
            const stack = STACKS[index % STACKS.length];
            const sector = sectors[item.sectorKey] ?? item.sectorKey;
            return (
              <article
                key={item.title}
                className={`group relative overflow-hidden rounded-3xl border p-8 transition hover:-translate-y-1 ${styles.card}`}
              >
                <div className="flex items-start justify-between gap-4">
                  <span
                    className={`text-xs font-medium uppercase tracking-widest ${styles.sector}`}
                  >
                    {sector}
                  </span>
                  <ArrowUpRight
                    size={18}
                    className={`${styles.label} transition group-hover:-translate-y-1 group-hover:translate-x-1`}
                  />
                </div>
                <h3
                  className={`mt-4 font-display text-2xl font-bold leading-tight ${styles.title}`}
                >
                  {item.title}
                </h3>

                <div className="mt-6 space-y-4 text-sm">
                  <div>
                    <div
                      className={`text-xs font-medium uppercase tracking-wider ${styles.label}`}
                    >
                      {t("labelProblem")}
                    </div>
                    <div className={`mt-1 leading-relaxed ${styles.text}`}>
                      {item.problem}
                    </div>
                  </div>
                  <div className={`rounded-2xl px-4 py-3 ${styles.result}`}>
                    <div
                      className={`text-xs font-medium uppercase tracking-wider ${styles.label}`}
                    >
                      {t("labelResult")}
                    </div>
                    <div className="mt-1 font-medium leading-snug">
                      {item.result}
                    </div>
                  </div>
                </div>

                <div className="mt-6 flex flex-wrap gap-2">
                  {stack.map((techno) => (
                    <span
                      key={techno}
                      className={`rounded-full border px-3 py-1 text-xs font-medium ${styles.tag}`}
                    >
                      {techno}
                    </span>
                  ))}
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
