"use client";

import { useState, type FormEvent } from "react";
import { Send } from "lucide-react";
import { useLocale, useTranslations } from "next-intl";

const API_BASE_URL =
  process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://127.0.0.1:8000/api/v1";

type FieldErrors = Record<string, string[]>;

type Props = {
  slug: string;
};

/**
 * Formulaire de candidature à une offre d'emploi.
 *
 * Envoie les champs et les pièces jointes PDF (CV, lettre) en multipart à
 * l'API Laravel, et affiche les erreurs de validation renvoyées (422).
 *
 * @param slug Identifiant de l'offre visée
 */
export default function JobApplicationForm({ slug }: Props) {
  const t = useTranslations("applyForm");
  const locale = useLocale();
  const [status, setStatus] = useState<"idle" | "loading" | "ok" | "error">(
    "idle"
  );
  const [errors, setErrors] = useState<FieldErrors>({});

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setStatus("loading");
    setErrors({});

    const formData = new FormData(event.currentTarget);

    try {
      const response = await fetch(
        `${API_BASE_URL}/job-offers/${slug}/applications`,
        {
          method: "POST",
          headers: {
            Accept: "application/json",
            "X-Locale": locale,
          },
          body: formData,
        }
      );

      if (response.status === 422) {
        const data = (await response.json()) as { errors?: FieldErrors };
        setErrors(data.errors ?? {});
        setStatus("error");
        return;
      }
      if (!response.ok) {
        throw new Error("application_failed");
      }
      setStatus("ok");
      event.currentTarget.reset();
    } catch {
      setStatus("error");
    }
  };

  if (status === "ok") {
    return (
      <div className="flex flex-col items-center justify-center gap-4 rounded-3xl border border-ink-100 bg-ink-50 py-14 text-center">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-brand-500 text-white">
          <Send size={22} />
        </div>
        <p className="max-w-md text-base text-ink-700">{t("success")}</p>
      </div>
    );
  }

  return (
    <form
      onSubmit={handleSubmit}
      noValidate
      className="rounded-3xl border border-ink-100 bg-ink-50 p-6 sm:p-8"
    >
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
        <TextField
          label={t("firstName")}
          name="first_name"
          required
          errors={errors.first_name}
        />
        <TextField
          label={t("lastName")}
          name="last_name"
          required
          errors={errors.last_name}
        />
        <TextField
          label={t("email")}
          name="email"
          type="email"
          required
          errors={errors.email}
        />
        <TextField
          label={t("phone")}
          name="phone"
          type="tel"
          errors={errors.phone}
        />
      </div>

      <div className="mt-5">
        <TextField
          label={t("linkedin")}
          name="linkedin_url"
          type="url"
          errors={errors.linkedin_url}
        />
      </div>

      <div className="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-2">
        <FileField label={t("cv")} name="cv" required errors={errors.cv} />
        <FileField
          label={t("coverLetter")}
          name="cover_letter"
          required
          errors={errors.cover_letter}
        />
      </div>
      <p className="mt-2 text-xs text-ink-400">{t("pdfHint")}</p>

      <label className="mt-5 flex items-start gap-3 text-sm text-ink-600">
        <input
          type="checkbox"
          name="consent_privacy"
          value="1"
          required
          className="mt-0.5 h-4 w-4 rounded border-ink-300 text-brand-500 focus:ring-brand-500"
        />
        <span>{t("consent")}</span>
      </label>
      {errors.consent_privacy && (
        <p className="mt-1 text-xs text-red-500">{errors.consent_privacy[0]}</p>
      )}

      <button
        type="submit"
        disabled={status === "loading"}
        className="btn-primary mt-7 w-full disabled:opacity-60 sm:w-auto"
      >
        {t("submit")}
        <Send size={14} />
      </button>

      {status === "error" && (
        <p className="mt-4 text-sm text-red-500">{t("error")}</p>
      )}
    </form>
  );
}

type TextFieldProps = {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
  errors?: string[];
};

/**
 * Champ texte réutilisable avec libellé et message d'erreur.
 */
function TextField({
  label,
  name,
  type = "text",
  required,
  errors,
}: TextFieldProps) {
  return (
    <div>
      <label
        htmlFor={name}
        className="block text-xs font-medium uppercase tracking-wider text-ink-500"
      >
        {label}
        {required && <span className="ml-1 text-brand-500">*</span>}
      </label>
      <input
        id={name}
        type={type}
        name={name}
        required={required}
        className="mt-2 w-full rounded-full border border-ink-200 bg-white px-4 py-3 text-sm text-ink-900 focus:border-brand-500 focus:outline-none"
      />
      {errors && <p className="mt-1 text-xs text-red-500">{errors[0]}</p>}
    </div>
  );
}

type FileFieldProps = {
  label: string;
  name: string;
  required?: boolean;
  errors?: string[];
};

/**
 * Champ de téléversement de fichier PDF avec libellé et message d'erreur.
 */
function FileField({ label, name, required, errors }: FileFieldProps) {
  return (
    <div>
      <label
        htmlFor={name}
        className="block text-xs font-medium uppercase tracking-wider text-ink-500"
      >
        {label}
        {required && <span className="ml-1 text-brand-500">*</span>}
      </label>
      <input
        id={name}
        type="file"
        name={name}
        accept="application/pdf"
        required={required}
        className="mt-2 w-full rounded-2xl border border-ink-200 bg-white px-4 py-3 text-sm text-ink-700 file:mr-4 file:rounded-full file:border-0 file:bg-brand-50 file:px-4 file:py-2 file:text-sm file:font-semibold file:text-brand-700 hover:file:bg-brand-100 focus:border-brand-500 focus:outline-none"
      />
      {errors && <p className="mt-1 text-xs text-red-500">{errors[0]}</p>}
    </div>
  );
}
