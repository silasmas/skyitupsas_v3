import createMiddleware from "next-intl/middleware";
import { routing } from "./i18n/routing";

// Next 16 : le fichier « proxy » remplace « middleware ». next-intl expose
// toujours son handler via next-intl/middleware (même signature).
export default createMiddleware(routing);

export const config = {
  // Applique le routage i18n à toutes les routes sauf les assets et l'API interne.
  matcher: "/((?!api|_next|_vercel|.*\\..*).*)",
};
