import { defineRouting } from "next-intl/routing";

/**
 * Configuration du routage internationalisé.
 *
 * Les URLs sont toujours préfixées par la locale (`/fr/...`, `/en/...`) pour
 * rester cohérent avec le backend Laravel et le SEO multilingue.
 */
export const routing = defineRouting({
  locales: ["fr", "en"],
  defaultLocale: "fr",
  localePrefix: "always",
});

export type Locale = (typeof routing.locales)[number];
