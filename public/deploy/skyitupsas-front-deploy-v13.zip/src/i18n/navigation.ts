import { createNavigation } from "next-intl/navigation";
import { routing } from "./routing";

/**
 * Helpers de navigation conscients de la locale (Link, useRouter, etc.).
 * À utiliser à la place des équivalents `next/navigation`.
 */
export const { Link, redirect, usePathname, useRouter, getPathname } =
  createNavigation(routing);
