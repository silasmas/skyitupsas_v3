import type {
  ApiAbout,
  ApiBlog,
  ApiCollection,
  ApiContact,
  ApiJobOffer,
  ApiPartner,
  ApiRealisation,
  ApiService,
  ApiServiceModule,
  ApiServicePillar,
  ApiTeamMember,
  BlogType,
} from "./types";
import { resolveTranslatable } from "./translatable";

const API_BASE_URL = process.env.API_BASE_URL ?? "http://127.0.0.1:8000/api/v1";

/** Durée de revalidation ISR par défaut (secondes) — filet de sécurité. */
const REVALIDATE_SECONDS = 60;

/** Tag de cache partagé : invalidé par /api/revalidate après une édition CMS. */
const CMS_CACHE_TAG = "cms";

/**
 * Ajoute `locale` en query string pour isoler le Data Cache Next par langue.
 *
 * @param path Chemin API (peut déjà contenir une query)
 * @param locale Code langue (fr|en)
 * @returns Chemin avec `locale=`
 */
function withLocaleQuery(path: string, locale: string): string {
  const separator = path.includes("?") ? "&" : "?";
  return `${path}${separator}locale=${encodeURIComponent(locale)}`;
}

/**
 * Effectue un GET sur l'API Laravel en demandant le contenu dans la locale
 * fournie (`?locale=` + en-tête `X-Locale`), avec revalidation ISR.
 *
 * @param path Chemin relatif de l'endpoint (ex. "/services")
 * @param locale Code langue (fr|en)
 * @returns La charge utile JSON typée
 */
async function apiGet<T>(path: string, locale: string): Promise<T> {
  const pathWithLocale = withLocaleQuery(path, locale);
  const cachePath = path.split("?")[0];

  const response = await fetch(`${API_BASE_URL}${pathWithLocale}`, {
    headers: {
      Accept: "application/json",
      "X-Locale": locale,
    },
    next: {
      revalidate: REVALIDATE_SECONDS,
      tags: [
        CMS_CACHE_TAG,
        `cms:${cachePath}`,
        `cms-locale:${locale}`,
      ],
    },
  });

  if (!response.ok) {
    throw new Error(`API ${path} a répondu ${response.status}`);
  }

  return response.json() as Promise<T>;
}

/**
 * Récupère une collection en absorbant les erreurs réseau (retourne []).
 *
 * @param path Chemin de la collection
 * @param locale Code langue (fr|en)
 * @returns Le tableau de données, ou [] en cas d'échec
 */
async function safeCollection<T>(path: string, locale: string): Promise<T[]> {
  try {
    const json = await apiGet<ApiCollection<T>>(path, locale);
    return json.data ?? [];
  } catch {
    return [];
  }
}

/**
 * Récupère une ressource unique en absorbant les erreurs réseau.
 *
 * @param path Chemin de la ressource (ex. "/job-offers/xxx")
 * @param locale Code langue (fr|en)
 * @returns La ressource, ou null en cas d'échec
 */
async function safeSingle<T>(path: string, locale: string): Promise<T | null> {
  try {
    const json = await apiGet<{ data: T }>(path, locale);
    return json.data ?? null;
  } catch {
    return null;
  }
}

/**
 * Normalise un champ traduisible nullable.
 *
 * @param value Valeur brute API
 * @returns Chaîne ou null
 */
function normalizeNullable(value: unknown): string | null {
  const resolved = resolveTranslatable(value);
  return resolved || null;
}

/**
 * Normalise les champs traduisibles d'un module API.
 *
 * @param module Module brut
 * @returns Module avec chaînes normalisées
 */
function normalizeServiceModule(module: ApiServiceModule): ApiServiceModule {
  return {
    ...module,
    title: resolveTranslatable(module.title),
    benefit_text: normalizeNullable(module.benefit_text),
    summary_text: normalizeNullable(module.summary_text),
    cta_label: normalizeNullable(module.cta_label),
    meta_description: normalizeNullable(module.meta_description),
  };
}

/**
 * Normalise les champs traduisibles d'un pilier API.
 *
 * @param pillar Pilier brut
 * @returns Pilier avec chaînes normalisées
 */
function normalizeServicePillar(pillar: ApiServicePillar): ApiServicePillar {
  return {
    ...pillar,
    title: resolveTranslatable(pillar.title),
    tagline: normalizeNullable(pillar.tagline),
    client_challenge: normalizeNullable(pillar.client_challenge),
    offer_summary: normalizeNullable(pillar.offer_summary),
    differentiator: normalizeNullable(pillar.differentiator),
    meta_description: normalizeNullable(pillar.meta_description),
    modules: pillar.modules?.map(normalizeServiceModule),
  };
}

/**
 * Normalise une fiche Contact.
 *
 * @param contact Contact brut
 * @returns Contact avec chaînes normalisées
 */
function normalizeContact(contact: ApiContact): ApiContact {
  return {
    ...contact,
    title: resolveTranslatable(contact.title),
    description: normalizeNullable(contact.description),
    address: normalizeNullable(contact.address),
    meta_description: normalizeNullable(contact.meta_description),
    email: contact.email?.trim() || null,
    phone: contact.phone?.trim() || null,
  };
}

/**
 * Normalise un contenu À propos.
 *
 * @param about Contenu brut
 * @returns Contenu normalisé
 */
function normalizeAbout(about: ApiAbout): ApiAbout {
  return {
    ...about,
    title: resolveTranslatable(about.title),
    subtitle: normalizeNullable(about.subtitle),
    big_title: normalizeNullable(about.big_title),
    content: normalizeNullable(about.content),
    content1: normalizeNullable(about.content1),
    content2: normalizeNullable(about.content2),
    experience_label: normalizeNullable(about.experience_label),
    diploma_label: normalizeNullable(about.diploma_label),
    expertise_label: normalizeNullable(about.expertise_label),
    work_countries_label: normalizeNullable(about.work_countries_label),
    meta_description: normalizeNullable(about.meta_description),
  };
}

/**
 * Normalise un membre d'équipe.
 *
 * @param member Membre brut
 * @returns Membre normalisé
 */
function normalizeTeamMember(member: ApiTeamMember): ApiTeamMember {
  return {
    ...member,
    name: resolveTranslatable(member.name),
    role: resolveTranslatable(member.role),
    bio: normalizeNullable(member.bio),
  };
}

/**
 * Normalise une offre d'emploi.
 *
 * @param offer Offre brute
 * @returns Offre normalisée
 */
function normalizeJobOffer(offer: ApiJobOffer): ApiJobOffer {
  return {
    ...offer,
    title: resolveTranslatable(offer.title),
    description: resolveTranslatable(offer.description),
    requirements: resolveTranslatable(offer.requirements),
    location: resolveTranslatable(offer.location),
  };
}

/**
 * Normalise un partenaire.
 *
 * @param partner Partenaire brut
 * @returns Partenaire normalisé
 */
function normalizePartner(partner: ApiPartner): ApiPartner {
  return {
    ...partner,
    name: resolveTranslatable(partner.name),
  };
}

/**
 * Normalise une réalisation.
 *
 * @param realisation Réalisation brute
 * @returns Réalisation normalisée
 */
function normalizeRealisation(realisation: ApiRealisation): ApiRealisation {
  return {
    ...realisation,
    title: resolveTranslatable(realisation.title),
    description: resolveTranslatable(realisation.description),
  };
}

/**
 * Normalise un article de blog / actualité.
 *
 * @param blog Article brut
 * @returns Article normalisé
 */
function normalizeBlog(blog: ApiBlog): ApiBlog {
  return {
    ...blog,
    title: resolveTranslatable(blog.title),
    excerpt: normalizeNullable(blog.excerpt),
    content: normalizeNullable(blog.content),
    meta_description: normalizeNullable(blog.meta_description),
  };
}

/**
 * Normalise un service legacy.
 *
 * @param service Service brut
 * @returns Service normalisé
 */
function normalizeService(service: ApiService): ApiService {
  return {
    ...service,
    title: resolveTranslatable(service.title),
    subtitle: normalizeNullable(service.subtitle),
    description: resolveTranslatable(service.description),
    meta_description: normalizeNullable(service.meta_description),
  };
}

/**
 * Liste les services actifs.
 *
 * @param locale Code langue (fr|en)
 */
export async function getServices(locale: string): Promise<ApiService[]> {
  const items = await safeCollection<ApiService>("/services", locale);
  return items.map(normalizeService);
}

/**
 * Récupère un service par son slug.
 *
 * @param slug Identifiant du service
 * @param locale Code langue (fr|en)
 * @returns Le service, ou null si introuvable
 */
export async function getService(
  slug: string,
  locale: string
): Promise<ApiService | null> {
  const service = await safeSingle<ApiService>(`/services/${slug}`, locale);
  return service ? normalizeService(service) : null;
}

/**
 * Liste les piliers stratégiques avec leurs modules actifs.
 *
 * @param locale Code langue (fr|en)
 */
export async function getServicePillars(
  locale: string
): Promise<ApiServicePillar[]> {
  const items = await safeCollection<ApiServicePillar>(
    "/service-pillars",
    locale
  );
  return items.map(normalizeServicePillar);
}

/**
 * Récupère un pilier par slug (avec modules).
 *
 * @param slug Identifiant du pilier
 * @param locale Code langue (fr|en)
 */
export async function getServicePillar(
  slug: string,
  locale: string
): Promise<ApiServicePillar | null> {
  const pillar = await safeSingle<ApiServicePillar>(
    `/service-pillars/${slug}`,
    locale
  );
  return pillar ? normalizeServicePillar(pillar) : null;
}

/**
 * Récupère un module par slug global.
 *
 * @param slug Identifiant du module
 * @param locale Code langue (fr|en)
 */
export async function getServiceModule(
  slug: string,
  locale: string
): Promise<ApiServiceModule | null> {
  const moduleItem = await safeSingle<ApiServiceModule>(
    `/service-modules/${slug}`,
    locale
  );
  return moduleItem ? normalizeServiceModule(moduleItem) : null;
}

/**
 * Récupère le premier contenu « À propos » actif.
 *
 * @param locale Code langue (fr|en)
 * @returns Le contenu À propos, ou null
 */
export async function getAbout(locale: string): Promise<ApiAbout | null> {
  const items = await safeCollection<ApiAbout>("/abouts", locale);
  const about = items[0];
  return about ? normalizeAbout(about) : null;
}

/**
 * Récupère la première fiche de contact active.
 *
 * @param locale Code langue (fr|en)
 * @returns Les coordonnées de contact, ou null
 */
export async function getContact(locale: string): Promise<ApiContact | null> {
  const items = await safeCollection<ApiContact>("/contacts", locale);
  const contact = items[0];
  return contact ? normalizeContact(contact) : null;
}

/**
 * Liste les offres d'emploi publiées.
 *
 * @param locale Code langue (fr|en)
 */
export async function getJobOffers(locale: string): Promise<ApiJobOffer[]> {
  const items = await safeCollection<ApiJobOffer>("/job-offers", locale);
  return items.map(normalizeJobOffer);
}

/**
 * Récupère une offre d'emploi par son slug.
 *
 * @param slug Identifiant de l'offre
 * @param locale Code langue (fr|en)
 * @returns L'offre, ou null si introuvable
 */
export async function getJobOffer(
  slug: string,
  locale: string
): Promise<ApiJobOffer | null> {
  const offer = await safeSingle<ApiJobOffer>(`/job-offers/${slug}`, locale);
  return offer ? normalizeJobOffer(offer) : null;
}

/**
 * Liste les partenaires actifs.
 *
 * @param locale Code langue (fr|en)
 */
export async function getPartners(locale: string): Promise<ApiPartner[]> {
  const items = await safeCollection<ApiPartner>("/partners", locale);
  return items.map(normalizePartner);
}

/**
 * Liste les membres de l'équipe actifs.
 *
 * @param locale Code langue (fr|en)
 */
export async function getTeamMembers(locale: string): Promise<ApiTeamMember[]> {
  const items = await safeCollection<ApiTeamMember>("/team-members", locale);
  return items.map(normalizeTeamMember);
}

/**
 * Récupère un membre de l'équipe par son slug.
 *
 * @param slug Identifiant du membre
 * @param locale Code langue (fr|en)
 * @returns Le membre, ou null si introuvable
 */
export async function getTeamMember(
  slug: string,
  locale: string
): Promise<ApiTeamMember | null> {
  const member = await safeSingle<ApiTeamMember>(
    `/team-members/${slug}`,
    locale
  );
  return member ? normalizeTeamMember(member) : null;
}

/**
 * Liste les réalisations actives.
 *
 * @param locale Code langue (fr|en)
 */
export async function getRealisations(
  locale: string
): Promise<ApiRealisation[]> {
  const items = await safeCollection<ApiRealisation>("/realisations", locale);
  return items.map(normalizeRealisation);
}

/**
 * Récupère une réalisation par son slug.
 *
 * @param slug Identifiant de la réalisation
 * @param locale Code langue (fr|en)
 * @returns La réalisation, ou null si introuvable
 */
export async function getRealisation(
  slug: string,
  locale: string
): Promise<ApiRealisation | null> {
  const realisation = await safeSingle<ApiRealisation>(
    `/realisations/${slug}`,
    locale
  );
  return realisation ? normalizeRealisation(realisation) : null;
}

/**
 * Liste les articles publiés (les plus récents d'abord), filtrables par type.
 *
 * @param locale Code langue (fr|en)
 * @param type Type de contenu à filtrer ("blog" ou "news"), optionnel
 */
export async function getBlogs(
  locale: string,
  type?: BlogType
): Promise<ApiBlog[]> {
  const path = type ? `/blogs?type=${type}` : "/blogs";
  const items = await safeCollection<ApiBlog>(path, locale);
  return items.map(normalizeBlog);
}

/**
 * Récupère un article de blog par son slug.
 *
 * @param slug Identifiant de l'article
 * @param locale Code langue (fr|en)
 * @returns L'article, ou null si introuvable
 */
export async function getBlog(
  slug: string,
  locale: string
): Promise<ApiBlog | null> {
  const blog = await safeSingle<ApiBlog>(`/blogs/${slug}`, locale);
  return blog ? normalizeBlog(blog) : null;
}
