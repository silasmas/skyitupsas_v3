/**
 * Utilitaires de traitement du HTML renvoyé par le CMS (éditeur riche).
 */

/** Entités HTML courantes à décoder lors du nettoyage du texte. */
const HTML_ENTITIES: Record<string, string> = {
  "&nbsp;": " ",
  "&amp;": "&",
  "&lt;": "<",
  "&gt;": ">",
  "&quot;": '"',
  "&#39;": "'",
  "&apos;": "'",
  "&hellip;": "…",
  "&laquo;": "«",
  "&raquo;": "»",
};

/**
 * Retire les balises HTML et décode les entités courantes pour produire
 * un texte simple, utilisable dans les aperçus (cartes, extraits).
 *
 * @param input Chaîne potentiellement au format HTML
 * @returns Le texte nettoyé, sans balises ni entités, espaces normalisés
 */
export function stripHtml(input: string | null | undefined): string {
  if (!input) {
    return "";
  }

  const withoutTags = input.replace(/<[^>]*>/g, " ");
  const decoded = Object.entries(HTML_ENTITIES).reduce(
    (text, [entity, value]) => text.split(entity).join(value),
    withoutTags
  );

  return decoded.replace(/\s+/g, " ").trim();
}

/**
 * Indique si une chaîne contient au moins une balise HTML.
 *
 * @param input Chaîne à tester
 * @returns Vrai si une balise `<...>` est détectée
 */
export function looksLikeHtml(input: string | null | undefined): boolean {
  return Boolean(input && /<[^>]+>/.test(input));
}
