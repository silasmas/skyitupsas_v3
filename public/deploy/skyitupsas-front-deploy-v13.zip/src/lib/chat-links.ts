import { PATHS } from "@/lib/paths";
import type { Locale } from "@/i18n/routing";

/** Domaines publics acceptés pour les liens internes du site. */
const SITE_HOSTS = ["skyitupsas.org", "www.skyitupsas.org"];

/**
 * Retourne l'origine publique du frontend (sans slash final).
 *
 * @returns URL de base du site (ex. https://skyitupsas.org)
 */
export function getSiteOrigin(): string {
  const configured = process.env.NEXT_PUBLIC_SITE_URL?.trim();
  if (configured) {
    return configured.replace(/\/$/, "");
  }
  return "https://skyitupsas.org";
}

/**
 * Construit un chemin interne préfixé par la locale.
 *
 * @param locale Code langue (fr|en)
 * @param path Chemin sans locale (ex. /realisations)
 * @returns Chemin complet (ex. /en/realisations)
 */
export function buildSitePath(locale: Locale, path: string): string {
  const normalized = path.startsWith("/") ? path : `/${path}`;
  if (normalized === "/") {
    return `/${locale}`;
  }
  return `/${locale}${normalized}`;
}

/**
 * Construit une URL absolue vers une page publique du site.
 *
 * @param locale Code langue (fr|en)
 * @param path Chemin sans locale
 * @returns URL absolue cliquable
 */
export function buildSiteUrl(locale: Locale, path: string): string {
  return `${getSiteOrigin()}${buildSitePath(locale, path)}`;
}

/**
 * Libellés des pages index pour la base de connaissances du chatbot.
 *
 * @param locale Code langue (fr|en)
 * @returns Libellés des sections principales
 */
export function getPageLabels(locale: Locale): Record<string, string> {
  if (locale === "en") {
    return {
      about: "About",
      team: "Team",
      services: "Services",
      projects: "Case studies",
      careers: "Careers",
      news: "News",
      contact: "Contact",
    };
  }

  return {
    about: "À propos",
    team: "Notre équipe",
    services: "Services",
    projects: "Réalisations",
    careers: "Recrutement",
    news: "Actualités",
    contact: "Contact",
  };
}

/**
 * Chemins index utiles pour les réponses de repli du chatbot.
 *
 * @param locale Code langue (fr|en)
 * @returns URLs absolues des pages principales
 */
export function getMainPageUrls(locale: Locale) {
  return {
    about: buildSiteUrl(locale, PATHS.about),
    team: buildSiteUrl(locale, PATHS.team),
    services: buildSiteUrl(locale, PATHS.services),
    projects: buildSiteUrl(locale, PATHS.projects),
    careers: buildSiteUrl(locale, PATHS.careers),
    news: buildSiteUrl(locale, PATHS.news),
    contact: buildSiteUrl(locale, PATHS.contact),
  };
}

/**
 * Normalise une URL ou un chemin interne pour respecter la locale courante
 * et le domaine de production skyitupsas.org.
 *
 * @param href Lien brut (absolu, relatif ou domaine obsolète .com)
 * @param locale Locale active de la conversation
 * @param origin Origine du site (optionnel)
 * @returns URL absolue valide ou chemin relatif corrigé
 */
export function normalizeHref(
  href: string,
  locale: Locale,
  origin: string = getSiteOrigin()
): string {
  const trimmed = href.trim();
  if (!trimmed || trimmed.startsWith("mailto:") || trimmed.startsWith("tel:")) {
    return trimmed;
  }

  const safeOrigin = origin.replace(/\/$/, "");

  if (trimmed.startsWith("/")) {
    const localeMatch = trimmed.match(/^\/(fr|en)(\/.*)?$/);
    if (localeMatch) {
      const suffix = localeMatch[2] ?? "";
      return `${safeOrigin}/${locale}${suffix}`;
    }
    return `${safeOrigin}${buildSitePath(locale, trimmed)}`;
  }

  try {
    const parsed = new URL(trimmed);
    const host = parsed.hostname.replace(/^www\./, "");

    if (host === "skyitupsas.com") {
      parsed.hostname = "skyitupsas.org";
      parsed.protocol = "https:";
    }

    if (SITE_HOSTS.includes(parsed.hostname.replace(/^www\./, ""))) {
      const pathMatch = parsed.pathname.match(/^\/(fr|en)(\/.*)?$/);
      if (pathMatch) {
        const suffix = pathMatch[2] ?? "";
        parsed.pathname = `/${locale}${suffix}`;
      } else if (parsed.pathname === "/" || parsed.pathname === "") {
        parsed.pathname = `/${locale}`;
      } else {
        parsed.pathname = buildSitePath(locale, parsed.pathname);
      }
      parsed.search = "";
      parsed.hash = "";
      return parsed.toString().replace(/\/$/, "");
    }

    return parsed.toString();
  } catch {
    return trimmed;
  }
}

/**
 * Corrige tous les liens Markdown d'une réponse assistant (domaine, locale).
 *
 * @param text Réponse brute du LLM ou du repli
 * @param locale Locale active de la conversation
 * @returns Texte Markdown avec liens normalisés
 */
export function normalizeChatReplyLinks(text: string, locale: Locale): string {
  const origin = getSiteOrigin();

  const withMarkdownLinks = text.replace(
    /\[([^\]]+)\]\(([^)]+)\)/g,
    (_match, label: string, href: string) =>
      `[${label}](${normalizeHref(href, locale, origin)})`
  );

  return withMarkdownLinks.replace(
    /https?:\/\/(?:www\.)?skyitupsas\.com(\/[^\s)\]"']*)?/gi,
    (match) => normalizeHref(match, locale, origin)
  );
}
