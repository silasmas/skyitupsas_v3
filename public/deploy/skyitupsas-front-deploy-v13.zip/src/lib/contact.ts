import type { ApiContact } from "./types";

/** Coordonnées de repli si l'API Contact est indisponible. */
export const CONTACT_FALLBACK = {
  phone: "+243 821 790 718",
  email: "contact@skyitupsas.com",
  address:
    "25, Av. de l'Équateur, Gombe — Immeuble MK Tower, Kinshasa",
} as const;

/**
 * Résout téléphone / e-mail / adresse depuis la fiche CMS, avec fallbacks.
 *
 * @param contact Fiche Contact API (ou null)
 * @returns Coordonnées affichables
 */
export function resolveContactDetails(contact: ApiContact | null | undefined): {
  phone: string;
  email: string;
  address: string;
  title: string;
  description: string;
  metaDescription: string;
} {
  return {
    phone: contact?.phone?.trim() || CONTACT_FALLBACK.phone,
    email: contact?.email?.trim() || CONTACT_FALLBACK.email,
    address: contact?.address?.trim() || CONTACT_FALLBACK.address,
    title: contact?.title?.trim() || "",
    description: contact?.description?.trim() || "",
    metaDescription: contact?.meta_description?.trim() || "",
  };
}
