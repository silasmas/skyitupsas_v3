import { stripHtml } from "./html";

/** Nombre de mots lus par minute (estimation du temps de lecture). */
const WORDS_PER_MINUTE = 200;

/**
 * Formate une date ISO en date lisible dans la locale fournie.
 *
 * @param iso Date au format ISO 8601 (ou null)
 * @param locale Code langue (fr|en)
 * @returns La date formatée, ou une chaîne vide si l'entrée est invalide
 */
export function formatDate(iso: string | null | undefined, locale: string): string {
  if (!iso) {
    return "";
  }

  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) {
    return "";
  }

  return new Intl.DateTimeFormat(locale, {
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(date);
}

/**
 * Estime le temps de lecture d'un contenu (HTML ou texte), en minutes.
 *
 * @param content Contenu de l'article (peut contenir du HTML)
 * @returns Le nombre de minutes (au minimum 1)
 */
export function readingTime(content: string | null | undefined): number {
  const text = stripHtml(content);
  if (!text) {
    return 1;
  }

  const words = text.split(/\s+/).filter(Boolean).length;
  return Math.max(1, Math.round(words / WORDS_PER_MINUTE));
}
