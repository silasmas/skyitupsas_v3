/**
 * Types des ressources renvoyées par l'API Laravel `/api/v1`.
 *
 * Lorsque la requête envoie l'en-tête `X-Locale`, les champs traduisibles
 * sont renvoyés sous forme de chaînes simples dans la locale demandée.
 */

export type ApiService = {
  id: number;
  slug: string;
  title: string;
  subtitle: string | null;
  description: string;
  meta_description: string | null;
  icon: string | null;
  featured_image: string | null;
  sort_order: number;
  is_active: boolean;
};

/** Module rattaché à un pilier stratégique. */
export type ApiServiceModule = {
  id: number;
  slug: string;
  pillar_slug?: string;
  pillar_id: number;
  title: string;
  benefit_text: string | null;
  summary_text: string | null;
  cta_label: string | null;
  cta_delay: string | null;
  meta_description: string | null;
  icon: string | null;
  featured_image: string | null;
  sort_order: number;
  is_active: boolean;
};

/** Pilier stratégique regroupant des modules de services. */
export type ApiServicePillar = {
  id: number;
  slug: string;
  title: string;
  tagline: string | null;
  client_challenge: string | null;
  offer_summary: string | null;
  differentiator: string | null;
  meta_description: string | null;
  icon: string | null;
  featured_image: string | null;
  sort_order: number;
  is_active: boolean;
  modules?: ApiServiceModule[];
};

export type ApiPartner = {
  id: number;
  slug: string;
  name: string;
  logo: string | null;
  website_url: string | null;
  open_in_new_tab: boolean;
  sort_order: number;
  is_active: boolean;
};

export type ApiTeamMember = {
  id: number;
  slug: string;
  picture: string | null;
  initials: string;
  name: string;
  role: string;
  bio: string | null;
  linkedin: string | null;
  facebook: string | null;
  twitter: string | null;
  instagram: string | null;
};

export type ApiAbout = {
  id: number;
  slug: string;
  title: string;
  subtitle: string | null;
  big_title: string | null;
  content: string | null;
  content1: string | null;
  content2: string | null;
  experience_label: string | null;
  diploma_label: string | null;
  expertise_label: string | null;
  work_countries_label: string | null;
  meta_description: string | null;
};

export type ApiContact = {
  id: number;
  slug: string;
  title: string;
  description: string | null;
  address: string | null;
  email: string | null;
  phone: string | null;
  map_embed: string | null;
  meta_description: string | null;
};

export type ApiJobOffer = {
  id: number;
  slug: string;
  title: string;
  description: string;
  requirements: string;
  location: string;
  contract_type: string | null;
  published_at: string | null;
  closes_at: string | null;
  is_open: boolean;
};

/** Type de contenu d'un article : billet de blog ou actualité. */
export type BlogType = "blog" | "news";

export type ApiBlog = {
  id: number;
  slug: string;
  type: BlogType;
  title: string;
  excerpt: string | null;
  content: string | null;
  meta_description: string | null;
  featured_image: string | null;
  published_at: string | null;
  sort_order: number;
  is_active: boolean;
};

export type ApiRealisation = {
  id: number;
  slug: string;
  title: string;
  description: string;
  featured_image: string | null;
  client: string | null;
  project_date: string | null;
  project_url: string | null;
};

/** Enveloppe standard des collections API (`{ data: [...] }`). */
export type ApiCollection<T> = { data: T[] };
