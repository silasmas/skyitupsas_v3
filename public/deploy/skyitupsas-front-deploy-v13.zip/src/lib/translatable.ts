/**
 * Normalise une valeur traduisible renvoyée par l'API Laravel.
 *
 * L'API peut renvoyer soit une chaîne (mode normal), soit un objet
 * `{ value, translations }` lorsque `?translations=1` est demandé.
 *
 * @param value Chaîne ou objet de traduction
 * @returns La chaîne utilisable côté UI
 */
export function resolveTranslatable(
  value: unknown
): string {
  if (value == null) {
    return "";
  }

  if (typeof value === "string") {
    return value;
  }

  if (
    typeof value === "object" &&
    value !== null &&
    "value" in value &&
    typeof (value as { value: unknown }).value === "string"
  ) {
    return (value as { value: string }).value;
  }

  return String(value);
}
