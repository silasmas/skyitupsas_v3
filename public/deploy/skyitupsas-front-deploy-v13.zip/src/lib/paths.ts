/**
 * Chemins des pages publiques (sans préfixe de locale).
 *
 * Les slugs sont alignés sur le backend Laravel. Le préfixe de locale
 * (`/fr`, `/en`) est ajouté automatiquement par les helpers de `navigation.ts`.
 */
export const PATHS = {
  home: "/",
  about: "/a-propos",
  services: "/services",
  projects: "/realisations",
  blog: "/blog",
  news: "/actualites",
  team: "/notre-equipe",
  careers: "/recrutement",
  contact: "/contact",
  cookies: "/politique-cookies",
} as const;
