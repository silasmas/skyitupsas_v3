import { NextResponse } from "next/server";
import {
  getAbout,
  getBlogs,
  getContact,
  getJobOffers,
  getPartners,
  getRealisations,
  getServicePillars,
  getTeamMembers,
} from "@/lib/api";
import {
  buildSiteUrl,
  getPageLabels,
  getMainPageUrls,
  normalizeChatReplyLinks,
} from "@/lib/chat-links";
import { PATHS } from "@/lib/paths";
import { resolveContactDetails } from "@/lib/contact";
import { stripHtml } from "@/lib/html";
import type { Locale } from "@/i18n/routing";
import type { ApiContact } from "@/lib/types";

/** Rôle d'un message de conversation accepté par l'API. */
type ChatRole = "user" | "assistant";

/** Message de conversation échangé avec le chatbot. */
type ChatMessage = {
  role: ChatRole;
  content: string;
};

/** Corps attendu de la requête POST. */
type ChatRequestBody = {
  messages?: unknown;
  locale?: unknown;
};

/** Nombre maximum de messages d'historique transmis au modèle. */
const MAX_HISTORY = 10;

/** Longueur maximale d'un message (caractères) pour limiter les abus. */
const MAX_CONTENT_LENGTH = 2000;

/** Longueur maximale d'un extrait de description injecté dans le contexte. */
const SNIPPET_LENGTH = 160;

/**
 * Tronque proprement un texte à une longueur maximale.
 *
 * @param value Texte source (potentiellement nul)
 * @param max Longueur maximale en caractères
 * @returns Le texte tronqué, ou une chaîne vide
 */
function truncate(value: string | null | undefined, max: number): string {
  const text = stripHtml(value).replace(/\s+/g, " ").trim();
  if (text.length <= max) {
    return text;
  }
  return `${text.slice(0, max).trimEnd()}…`;
}

/**
 * Construit une base de connaissances compacte à partir des données réelles
 * de l'API Laravel (services, réalisations, coordonnées, offres, partenaires).
 *
 * Les erreurs réseau sont absorbées par le client API (sections vides).
 *
 * @param locale Code langue (fr|en) transmis à l'API
 * @returns Un contexte textuel prêt à être injecté dans le prompt système
 */
async function buildKnowledgeBase(locale: Locale): Promise<string> {
  const [about, team, pillars, realisations, contact, jobOffers, partners, news] =
    await Promise.all([
      getAbout(locale),
      getTeamMembers(locale),
      getServicePillars(locale),
      getRealisations(locale),
      getContact(locale),
      getJobOffers(locale),
      getPartners(locale),
      getBlogs(locale, "news"),
    ]);

  const labels = getPageLabels(locale);
  const sections: string[] = [];

  if (about) {
    const presentation = truncate(
      about.content ?? about.content1 ?? about.subtitle,
      400
    );
    if (presentation) {
      sections.push(
        `${labels.about.toUpperCase()} (page: [${labels.about}](${buildSiteUrl(locale, PATHS.about)})):\n${presentation}`
      );
    }
  }

  if (team.length > 0) {
    const lines = team
      .map((m) => {
        const bio = m.bio ? ` — ${truncate(m.bio, SNIPPET_LENGTH)}` : "";
        return `- [${m.name}](${buildSiteUrl(locale, `${PATHS.team}/${m.slug}`)}), ${m.role}${bio}`;
      })
      .join("\n");
    sections.push(`${labels.team.toUpperCase()}:\n${lines}`);
  }

  if (pillars.length > 0) {
    const lines = pillars
      .flatMap((pillar) => {
        const pillarLine = `- [${pillar.title}](${buildSiteUrl(locale, `${PATHS.services}/${pillar.slug}`)}): ${truncate(pillar.offer_summary, SNIPPET_LENGTH)}`;
        const moduleLines = (pillar.modules ?? []).map(
          (module) =>
            `  - [${module.title}](${buildSiteUrl(locale, `${PATHS.services}/${pillar.slug}/${module.slug}`)}): ${truncate(module.summary_text || module.benefit_text, SNIPPET_LENGTH)}`
        );
        return [pillarLine, ...moduleLines];
      })
      .join("\n");
    sections.push(`${labels.services.toUpperCase()}:\n${lines}`);
  }

  if (realisations.length > 0) {
    const lines = realisations
      .slice(0, 8)
      .map((r) => {
        const client = r.client ? ` (${r.client})` : "";
        return `- [${r.title}](${buildSiteUrl(locale, `${PATHS.projects}/${r.slug}`)})${client}: ${truncate(r.description, SNIPPET_LENGTH)}`;
      })
      .join("\n");
    sections.push(`${labels.projects.toUpperCase()}:\n${lines}`);
  }

  const openOffers = jobOffers.filter((o) => o.is_open);
  if (openOffers.length > 0) {
    const lines = openOffers
      .map((o) => {
        const type = o.contract_type ? `, ${o.contract_type}` : "";
        return `- [${o.title}](${buildSiteUrl(locale, `${PATHS.careers}/${o.slug}`)}) (${o.location}${type})`;
      })
      .join("\n");
    sections.push(`${labels.careers.toUpperCase()}:\n${lines}`);
  }

  if (news.length > 0) {
    const lines = news
      .slice(0, 6)
      .map(
        (n) =>
          `- [${n.title}](${buildSiteUrl(locale, `${PATHS.news}/${n.slug}`)}): ${truncate(n.excerpt, SNIPPET_LENGTH)}`
      )
      .join("\n");
    sections.push(`${labels.news.toUpperCase()}:\n${lines}`);
  }

  if (partners.length > 0) {
    const names = partners.map((p) => p.name).join(", ");
    sections.push(`PARTNERS: ${names}`);
  }

  const details = resolveContactDetails(contact);
  const contactLines = [
    details.address ? `Address: ${details.address}` : null,
    `Email: ${details.email}`,
    `Phone: ${details.phone}`,
    `Page: [${labels.contact}](${buildSiteUrl(locale, PATHS.contact)})`,
  ].filter(Boolean);
  sections.push(`CONTACT:\n${contactLines.join("\n")}`);

  return sections.join("\n\n");
}

/**
 * Construit le prompt système décrivant l'assistant SkyITup et injecte le
 * contexte réel du site pour des réponses précises et sourcées.
 *
 * @param locale Code langue de la conversation (fr|en)
 * @param knowledgeBase Contexte factuel issu de l'API Laravel
 * @returns Le prompt système à envoyer au modèle
 */
function buildSystemPrompt(locale: Locale, knowledgeBase: string): string {
  const language = locale === "en" ? "English" : "French";
  const siteOrigin = process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, "") ?? "https://skyitupsas.org";

  return [
    `You are the virtual assistant of SkyITup SAS, a digital services company based in Kinshasa (DR Congo), also present in Lubumbashi, Goma, Bukavu.`,
    `Answer concisely, warmly and professionally, always in ${language}.`,
    `Use the CONTEXT below as your source of truth to answer questions about the company, team, services, projects/case studies, careers, news and contact details.`,
    `When the visitor asks about references or projects, cite concrete items from the ${locale === "en" ? "CASE STUDIES" : "RÉALISATIONS"} section with their markdown links.`,
    `CRITICAL LINK RULES:`,
    `- Every internal link MUST be copied EXACTLY from CONTEXT (full URL starting with ${siteOrigin}/${locale}/).`,
    `- NEVER use skyitupsas.com, never invent URLs, never change the locale segment (always /${locale}/).`,
    `- When mentioning a page, service, project, job offer, news item or team member listed in CONTEXT, include its markdown link from CONTEXT.`,
    `If information is missing from CONTEXT, say so briefly and invite the visitor to contact the team.`,
    `\n----- CONTEXT -----\n${knowledgeBase}\n----- END CONTEXT -----`,
  ].join(" ");
}

/** Réponses de repli localisées, par intention détectée. */
function fallbackReply(
  message: string,
  locale: Locale,
  contact: ApiContact | null
): string {
  const pages = getMainPageUrls(locale);
  const labels = getPageLabels(locale);
  const details = resolveContactDetails(contact);

  const replies = {
    services: {
      fr: `Nous couvrons le développement logiciel, l'ERP (Odoo), l'audit IT, la formation et la maintenance. Consultez nos [${labels.services}](${pages.services}).`,
      en: `We cover software development, ERP (Odoo), IT audit, training and maintenance. Browse our [${labels.services}](${pages.services}).`,
    },
    references: {
      fr: `Plusieurs références sont disponibles sur notre page [${labels.projects}](${pages.projects}).`,
      en: `Several case studies are available on our [${labels.projects}](${pages.projects}) page.`,
    },
    contact: {
      fr: `Contactez-nous via la page [${labels.contact}](${pages.contact}), par e-mail à ${details.email} ou au ${details.phone}.`,
      en: `Reach us via the [${labels.contact}](${pages.contact}) page, by email at ${details.email} or at ${details.phone}.`,
    },
    careers: {
      fr: `Nos offres sont sur la page [${labels.careers}](${pages.careers}).`,
      en: `Our openings are listed on the [${labels.careers}](${pages.careers}) page.`,
    },
    default: {
      fr: `Je peux vous orienter vers nos [${labels.services}](${pages.services}), [${labels.projects}](${pages.projects}) ou [${labels.contact}](${pages.contact}).`,
      en: `I can guide you to our [${labels.services}](${pages.services}), [${labels.projects}](${pages.projects}) or [${labels.contact}](${pages.contact}).`,
    },
  };

  const lang = locale === "en" ? "en" : "fr";
  const text = message.toLowerCase();

  if (/(service|offre|offer|propose|solution|erp|odoo|audit|formation)/.test(text)) {
    return replies.services[lang];
  }
  if (/(référence|reference|réalisation|realisation|case|projet|project|portfolio)/.test(text)) {
    return replies.references[lang];
  }
  if (/(contact|devis|quote|rendez|appel|call|email|mail|téléphone|phone)/.test(text)) {
    return replies.contact[lang];
  }
  if (/(emploi|job|carrière|career|recrut|stage|intern|candidat)/.test(text)) {
    return replies.careers[lang];
  }
  return replies.default[lang];
}

/**
 * Nettoie et borne l'historique de conversation reçu du client.
 *
 * @param raw Valeur brute du champ `messages`
 * @returns La liste de messages valides, tronquée aux plus récents
 */
function sanitizeMessages(raw: unknown): ChatMessage[] {
  if (!Array.isArray(raw)) {
    return [];
  }

  const cleaned: ChatMessage[] = [];
  for (const entry of raw) {
    if (!entry || typeof entry !== "object") {
      continue;
    }
    const role = (entry as { role?: unknown }).role;
    const content = (entry as { content?: unknown }).content;
    if (
      (role === "user" || role === "assistant") &&
      typeof content === "string" &&
      content.trim().length > 0
    ) {
      cleaned.push({ role, content: content.trim().slice(0, MAX_CONTENT_LENGTH) });
    }
  }

  return cleaned.slice(-MAX_HISTORY);
}

/**
 * Appelle un endpoint compatible OpenAI pour générer une réponse.
 *
 * @param messages Historique nettoyé de la conversation
 * @param locale Code langue (fr|en)
 * @param knowledgeBase Contexte factuel injecté dans le prompt système
 * @returns La réponse générée, ou null en cas d'échec/absence de clé
 */
async function generateWithLlm(
  messages: ChatMessage[],
  locale: Locale,
  knowledgeBase: string
): Promise<string | null> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return null;
  }

  const baseUrl = process.env.OPENAI_BASE_URL ?? "https://api.openai.com/v1";
  const model = process.env.OPENAI_MODEL ?? "gpt-4o-mini";

  try {
    const response = await fetch(`${baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        temperature: 0.4,
        max_tokens: 400,
        messages: [
          { role: "system", content: buildSystemPrompt(locale, knowledgeBase) },
          ...messages,
        ],
      }),
    });

    if (!response.ok) {
      return null;
    }

    const data = (await response.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const reply = data.choices?.[0]?.message?.content?.trim();
    return reply || null;
  } catch {
    return null;
  }
}

/**
 * Route Handler du chatbot : reçoit l'historique de conversation et renvoie
 * une réponse. Utilise un LLM si `OPENAI_API_KEY` est configurée, sinon un
 * repli par mots-clés. Aucune clé n'est jamais exposée au client.
 *
 * @param request Requête POST contenant `{ messages, locale }`
 * @returns Réponse JSON `{ reply, source }`
 */
export async function POST(request: Request): Promise<Response> {
  let body: ChatRequestBody;
  try {
    body = (await request.json()) as ChatRequestBody;
  } catch {
    return NextResponse.json({ error: "invalid_json" }, { status: 400 });
  }

  const messages = sanitizeMessages(body.messages);
  const locale: Locale = body.locale === "en" ? "en" : "fr";

  if (messages.length === 0 || messages[messages.length - 1].role !== "user") {
    return NextResponse.json({ error: "no_user_message" }, { status: 400 });
  }

  const lastUserMessage = messages[messages.length - 1].content;

  const knowledgeBase = await buildKnowledgeBase(locale);
  const llmReply = await generateWithLlm(messages, locale, knowledgeBase);
  if (llmReply) {
    return NextResponse.json({
      reply: normalizeChatReplyLinks(llmReply, locale),
      source: "llm",
    });
  }

  const contact = await getContact(locale);

  return NextResponse.json({
    reply: normalizeChatReplyLinks(
      fallbackReply(lastUserMessage, locale, contact),
      locale
    ),
    source: "fallback",
  });
}
