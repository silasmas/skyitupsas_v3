import { revalidatePath, revalidateTag } from "next/cache";
import { NextResponse } from "next/server";

/**
 * Invalide le cache ISR du site quand le CMS Laravel publie une modification.
 *
 * Sécurisé par `REVALIDATE_SECRET` (Bearer). Corps JSON optionnel :
 * `{ "tags": ["cms"], "paths": ["/fr", "/en/services"] }`.
 *
 * @param request Requête POST provenant de Laravel
 */
export async function POST(request: Request): Promise<NextResponse> {
  const secret = process.env.REVALIDATE_SECRET;
  const authHeader = request.headers.get("authorization") ?? "";
  const token = authHeader.startsWith("Bearer ")
    ? authHeader.slice("Bearer ".length).trim()
    : "";

  if (!secret || token !== secret) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  let tags: string[] = ["cms"];
  let paths: string[] = [];

  try {
    const body = (await request.json()) as {
      tags?: string[];
      paths?: string[];
    };
    if (Array.isArray(body.tags) && body.tags.length > 0) {
      tags = body.tags.filter((tag) => typeof tag === "string" && tag.length > 0);
    }
    if (Array.isArray(body.paths)) {
      paths = body.paths.filter(
        (path) => typeof path === "string" && path.startsWith("/")
      );
    }
  } catch {
    // Corps vide : invalider le tag cms par défaut.
  }

  for (const tag of tags) {
    revalidateTag(tag, "max");
  }

  for (const path of paths) {
    revalidatePath(path);
  }

  // Pages locales + layouts (Footer / CTA partagés).
  if (paths.length === 0) {
    for (const locale of ["fr", "en"]) {
      revalidatePath(`/${locale}`, "layout");
      revalidatePath(`/${locale}`);
      revalidatePath(`/${locale}/services`);
      revalidatePath(`/${locale}/a-propos`);
      revalidatePath(`/${locale}/notre-equipe`);
      revalidatePath(`/${locale}/realisations`);
      revalidatePath(`/${locale}/contact`);
      revalidatePath(`/${locale}/blog`);
      revalidatePath(`/${locale}/actualites`);
      revalidatePath(`/${locale}/recrutement`);
    }
  }

  return NextResponse.json({
    revalidated: true,
    tags,
    paths,
    now: Date.now(),
  });
}
