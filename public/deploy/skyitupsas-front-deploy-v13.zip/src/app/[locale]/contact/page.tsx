import type { Metadata } from "next";
import { Clock, Mail, MapPin, Phone } from "lucide-react";
import { getTranslations, setRequestLocale } from "next-intl/server";
import PageHero from "@/components/sections/PageHero";
import ContactForm from "@/components/ContactForm";
import { getContact } from "@/lib/api";
import { resolveContactDetails } from "@/lib/contact";
import { PATHS } from "@/lib/paths";

type Props = { params: Promise<{ locale: string }> };

/**
 * Métadonnées SEO de la page Contact (CMS + fallbacks i18n).
 *
 * @param params Paramètres de route contenant la locale
 */
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale } = await params;
  const [contact, t] = await Promise.all([
    getContact(locale),
    getTranslations({ locale, namespace: "meta" }),
  ]);
  const details = resolveContactDetails(contact);

  return {
    title: details.title || t("contactTitle"),
    description: details.metaDescription || t("contactDescription"),
  };
}

/**
 * Page Contact : bannière, coordonnées CMS et formulaire.
 *
 * @param params Paramètres de route contenant la locale
 */
export default async function ContactPage({ params }: Props) {
  const { locale } = await params;
  setRequestLocale(locale);
  const [contact, tHero, tNav, tCommon, tPage] = await Promise.all([
    getContact(locale),
    getTranslations({ locale, namespace: "pageHero" }),
    getTranslations({ locale, namespace: "nav" }),
    getTranslations({ locale, namespace: "common" }),
    getTranslations({ locale, namespace: "contactPage" }),
  ]);

  const details = resolveContactDetails(contact);
  const heading =
    details.title || `${tPage("title1")} ${tPage("title2")}`.trim();
  const intro = details.description || tPage("intro");
  const telHref = `tel:${details.phone.replace(/\s+/g, "")}`;

  return (
    <>
      <PageHero
        eyebrow={tHero("contactEyebrow")}
        title={tHero("contactTitle")}
        crumbs={[{ label: tNav("contact"), href: PATHS.contact }]}
        background="/images/slider-2.png"
      />

      <section className="bg-white py-20 lg:py-28">
        <div className="container-page grid grid-cols-1 gap-14 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <h2 className="font-display text-3xl font-bold tracking-tight text-ink-950 sm:text-4xl">
              {details.title ? (
                heading
              ) : (
                <>
                  {tPage("title1")}
                  <br />
                  <span className="text-brand-500">{tPage("title2")}</span>
                </>
              )}
            </h2>
            <p className="mt-5 text-base leading-relaxed text-ink-500">
              {intro}
            </p>

            <div className="mt-10 space-y-4">
              <div className="flex items-start gap-4 rounded-2xl border border-ink-100 bg-white p-5">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-50">
                  <MapPin size={18} className="text-brand-600" />
                </div>
                <div>
                  <div className="text-xs font-medium uppercase tracking-wider text-ink-400">
                    {tPage("addressTitle")}
                  </div>
                  <div className="mt-1 whitespace-pre-line text-sm text-ink-700">
                    {details.address}
                  </div>
                </div>
              </div>

              <a
                href={telHref}
                className="flex items-start gap-4 rounded-2xl border border-ink-100 bg-white p-5 transition hover:border-brand-300"
              >
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-50">
                  <Phone size={18} className="text-brand-600" />
                </div>
                <div>
                  <div className="text-xs font-medium uppercase tracking-wider text-ink-400">
                    {tCommon("phone")}
                  </div>
                  <div className="mt-1 font-display text-base font-semibold text-ink-950">
                    {details.phone}
                  </div>
                </div>
              </a>

              <a
                href={`mailto:${details.email}`}
                className="flex items-start gap-4 rounded-2xl border border-ink-100 bg-white p-5 transition hover:border-brand-300"
              >
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-50">
                  <Mail size={18} className="text-brand-600" />
                </div>
                <div>
                  <div className="text-xs font-medium uppercase tracking-wider text-ink-400">
                    {tCommon("email")}
                  </div>
                  <div className="mt-1 font-display text-base font-semibold text-ink-950">
                    {details.email}
                  </div>
                </div>
              </a>

              <div className="flex items-start gap-4 rounded-2xl border border-ink-100 bg-white p-5">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-50">
                  <Clock size={18} className="text-brand-600" />
                </div>
                <div>
                  <div className="text-xs font-medium uppercase tracking-wider text-ink-400">
                    {tPage("hoursTitle")}
                  </div>
                  <div className="mt-1 text-sm text-ink-700">{tPage("hours")}</div>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7">
            <ContactForm />
            {contact?.map_embed ? (
              <div
                className="mt-8 overflow-hidden rounded-2xl border border-ink-100 [&_iframe]:h-64 [&_iframe]:w-full"
                dangerouslySetInnerHTML={{ __html: contact.map_embed }}
              />
            ) : null}
          </div>
        </div>
      </section>
    </>
  );
}
