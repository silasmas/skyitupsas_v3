import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { getTranslations, setRequestLocale } from "next-intl/server";
import PageHero from "@/components/sections/PageHero";
import CTA from "@/components/sections/CTA";
import RichText from "@/components/RichText";
import { Link } from "@/i18n/navigation";
import { getTeamMember } from "@/lib/api";
import { stripHtml } from "@/lib/html";
import { PATHS } from "@/lib/paths";

type Props = { params: Promise<{ locale: string; slug: string }> };

/** Réseaux sociaux affichés si renseignés, dans l'ordre. */
const SOCIAL_LABELS: { key: "linkedin" | "facebook" | "twitter" | "instagram"; label: string }[] =
  [
    { key: "linkedin", label: "LinkedIn" },
    { key: "facebook", label: "Facebook" },
    { key: "twitter", label: "X / Twitter" },
    { key: "instagram", label: "Instagram" },
  ];

/**
 * Métadonnées SEO du membre (nom + rôle).
 *
 * @param params Paramètres de route (locale + slug)
 */
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale, slug } = await params;
  const member = await getTeamMember(slug, locale);
  if (!member) {
    return {};
  }
  return {
    title: `${member.name} — SkyITup SAS`,
    description: member.bio
      ? stripHtml(member.bio).slice(0, 160)
      : `${member.name}, ${member.role} — SkyITup SAS`,
  };
}

/**
 * Page de détail d'un membre de l'équipe : photo, rôle, biographie et réseaux.
 *
 * @param params Paramètres de route (locale + slug)
 */
export default async function TeamMemberDetailPage({ params }: Props) {
  const { locale, slug } = await params;
  setRequestLocale(locale);
  const member = await getTeamMember(slug, locale);
  if (!member) {
    notFound();
  }

  const [tHero, tNav, tPage] = await Promise.all([
    getTranslations({ locale, namespace: "pageHero" }),
    getTranslations({ locale, namespace: "nav" }),
    getTranslations({ locale, namespace: "teamPage" }),
  ]);

  const socials = SOCIAL_LABELS.map((item) => ({
    label: item.label,
    url: member[item.key],
  })).filter((item): item is { label: string; url: string } => Boolean(item.url));

  return (
    <>
      <PageHero
        eyebrow={tHero("teamEyebrow")}
        title={member.name}
        crumbs={[
          { label: tNav("team"), href: PATHS.team },
          { label: member.name },
        ]}
        background={member.picture || "/images/slider-1.png"}
      />

      <section className="bg-white py-16 lg:py-24">
        <div className="container-page grid grid-cols-1 gap-12 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <div className="overflow-hidden rounded-3xl border border-ink-100 bg-ink-100">
              {member.picture ? (
                <img
                  src={member.picture}
                  alt={member.name}
                  className="aspect-[4/5] w-full object-cover"
                />
              ) : (
                <div className="flex aspect-[4/5] items-center justify-center">
                  <span className="font-display text-5xl font-bold text-ink-400">
                    {member.initials}
                  </span>
                </div>
              )}
            </div>
          </div>

          <div className="lg:col-span-8">
            <Link
              href={PATHS.team}
              className="inline-flex items-center gap-2 text-sm font-semibold text-ink-500 transition hover:text-brand-600"
            >
              <ArrowLeft size={15} />
              {tPage("back")}
            </Link>

            <h2 className="mt-6 font-display text-3xl font-bold tracking-tight text-ink-950">
              {member.name}
            </h2>
            <p className="mt-1 text-base font-medium text-brand-600">
              {member.role}
            </p>

            {member.bio && (
              <div className="mt-8">
                <h3 className="font-display text-lg font-semibold text-ink-950">
                  {tPage("bioTitle")}
                </h3>
                <RichText content={member.bio} className="mt-3" />
              </div>
            )}

            {socials.length > 0 && (
              <div className="mt-8 flex flex-wrap gap-3">
                {socials.map((social) => (
                  <a
                    key={social.label}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="rounded-full border border-ink-200 px-4 py-2 text-sm font-medium text-ink-700 transition hover:border-ink-950 hover:bg-ink-950 hover:text-white"
                  >
                    {social.label}
                  </a>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>

      <CTA />
    </>
  );
}
