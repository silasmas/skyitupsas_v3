import type { Metadata } from "next";
import { getTranslations, setRequestLocale } from "next-intl/server";
import PageHero from "@/components/sections/PageHero";
import TeamGrid from "@/components/sections/TeamGrid";
import CareersTeaser from "@/components/sections/CareersTeaser";
import CTA from "@/components/sections/CTA";
import { getTeamMembers } from "@/lib/api";
import { PATHS } from "@/lib/paths";

type Props = { params: Promise<{ locale: string }> };

/**
 * Métadonnées SEO de la page Équipe.
 *
 * @param params Paramètres de route contenant la locale
 */
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: "meta" });
  return {
    title: t("teamTitle"),
    description: t("teamDescription"),
  };
}

/**
 * Page Équipe : bannière, grille des membres (via API) et appel à l'action.
 *
 * @param params Paramètres de route contenant la locale
 */
export default async function TeamPage({ params }: Props) {
  const { locale } = await params;
  setRequestLocale(locale);
  const [members, tHero, tNav] = await Promise.all([
    getTeamMembers(locale),
    getTranslations({ locale, namespace: "pageHero" }),
    getTranslations({ locale, namespace: "nav" }),
  ]);

  return (
    <>
      <PageHero
        eyebrow={tHero("teamEyebrow")}
        title={tHero("teamTitle")}
        crumbs={[{ label: tNav("team"), href: PATHS.team }]}
        background="/images/slider-5.png"
      />
      <TeamGrid members={members} />
      <CareersTeaser />
      <CTA />
    </>
  );
}
