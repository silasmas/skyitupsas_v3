import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ArrowLeft, MapPin } from "lucide-react";
import { getTranslations, setRequestLocale } from "next-intl/server";
import PageHero from "@/components/sections/PageHero";
import JobApplicationForm from "@/components/JobApplicationForm";
import RichText from "@/components/RichText";
import { Link } from "@/i18n/navigation";
import { getJobOffer } from "@/lib/api";
import { stripHtml } from "@/lib/html";
import { PATHS } from "@/lib/paths";

type Props = { params: Promise<{ locale: string; slug: string }> };

/**
 * Métadonnées SEO de l'offre (titre dynamique).
 *
 * @param params Paramètres de route (locale + slug)
 */
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale, slug } = await params;
  const offer = await getJobOffer(slug, locale);
  if (!offer) {
    return {};
  }
  return {
    title: `${offer.title} — SkyITup SAS`,
    description: stripHtml(offer.description).slice(0, 160),
  };
}

/**
 * Page détail d'une offre d'emploi : description, profil recherché et
 * formulaire de candidature (si l'offre est ouverte).
 *
 * @param params Paramètres de route (locale + slug)
 */
export default async function JobOfferPage({ params }: Props) {
  const { locale, slug } = await params;
  setRequestLocale(locale);
  const offer = await getJobOffer(slug, locale);
  if (!offer) {
    notFound();
  }

  const [tHero, tNav, tPage] = await Promise.all([
    getTranslations({ locale, namespace: "pageHero" }),
    getTranslations({ locale, namespace: "nav" }),
    getTranslations({ locale, namespace: "careersPage" }),
  ]);

  return (
    <>
      <PageHero
        eyebrow={tHero("careersEyebrow")}
        title={offer.title}
        crumbs={[
          { label: tNav("careers"), href: PATHS.careers },
          { label: offer.title },
        ]}
        background="/images/slider-3.png"
      />

      <section className="bg-white py-20 lg:py-28">
        <div className="container-page grid grid-cols-1 gap-12 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <Link
              href={PATHS.careers}
              className="inline-flex items-center gap-2 text-sm font-semibold text-ink-500 transition hover:text-brand-600"
            >
              <ArrowLeft size={15} />
              {tPage("back")}
            </Link>

            <div className="mt-6 flex flex-wrap items-center gap-2">
              {offer.contract_type && (
                <span className="rounded-full bg-brand-50 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-widest text-brand-700">
                  {offer.contract_type}
                </span>
              )}
              {offer.location && (
                <span className="inline-flex items-center gap-1 text-xs text-ink-500">
                  <MapPin size={12} /> {offer.location}
                </span>
              )}
            </div>

            <div className="mt-8 space-y-8">
              <div>
                <h2 className="font-display text-xl font-semibold text-ink-950">
                  {tPage("missions")}
                </h2>
                <RichText content={offer.description} className="mt-3" />
              </div>
              {offer.requirements && (
                <div>
                  <h2 className="font-display text-xl font-semibold text-ink-950">
                    {tPage("requirements")}
                  </h2>
                  <RichText content={offer.requirements} className="mt-3" />
                </div>
              )}
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="sticky top-28">
              <h2 className="font-display text-2xl font-bold tracking-tight text-ink-950">
                {tPage("detailApply")}
              </h2>
              {offer.is_open ? (
                <div className="mt-6">
                  <JobApplicationForm slug={offer.slug} />
                </div>
              ) : (
                <p className="mt-6 rounded-2xl border border-ink-100 bg-ink-50 p-6 text-sm text-ink-500">
                  {tPage("closed")}
                </p>
              )}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
