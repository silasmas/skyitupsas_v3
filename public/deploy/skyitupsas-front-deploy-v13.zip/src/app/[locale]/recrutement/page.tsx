import type { Metadata } from "next";
import {
  ArrowUpRight,
  GraduationCap,
  Heart,
  MapPin,
  Rocket,
  Send,
  Users,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { getTranslations, setRequestLocale } from "next-intl/server";
import PageHero from "@/components/sections/PageHero";
import { Link } from "@/i18n/navigation";
import { getJobOffers } from "@/lib/api";
import { stripHtml } from "@/lib/html";
import { PATHS } from "@/lib/paths";

type Props = { params: Promise<{ locale: string }> };

/** Avantage à rejoindre l'entreprise (titre + description). */
type Benefit = {
  title: string;
  description: string;
};

/** Icônes des avantages, dans l'ordre d'affichage. */
const BENEFIT_ICONS: LucideIcon[] = [Rocket, GraduationCap, Users, Heart];

/**
 * Métadonnées SEO de la page Recrutement.
 *
 * @param params Paramètres de route contenant la locale
 */
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: "meta" });
  return {
    title: t("careersTitle"),
    description: t("careersDescription"),
  };
}

/**
 * Page Recrutement : bannière, présentation, avantages, liste des offres
 * (via API) et candidature spontanée. Chaque offre renvoie vers son détail.
 *
 * @param params Paramètres de route contenant la locale
 */
export default async function CareersPage({ params }: Props) {
  const { locale } = await params;
  setRequestLocale(locale);
  const [offers, tHero, tNav, tPage] = await Promise.all([
    getJobOffers(locale),
    getTranslations({ locale, namespace: "pageHero" }),
    getTranslations({ locale, namespace: "nav" }),
    getTranslations({ locale, namespace: "careersPage" }),
  ]);

  const benefits = tPage.raw("benefits") as Benefit[];

  return (
    <>
      <PageHero
        eyebrow={tHero("careersEyebrow")}
        title={tHero("careersTitle")}
        crumbs={[{ label: tNav("careers"), href: PATHS.careers }]}
        background="/images/slider-3.png"
      />

      <section className="bg-white py-20 lg:py-28">
        <div className="container-page">
          <div className="grid grid-cols-1 items-end gap-8 lg:grid-cols-12">
            <div className="lg:col-span-7">
              <span className="eyebrow">
                <span className="h-1.5 w-1.5 rounded-full bg-brand-500" />
                {tHero("careersEyebrow")}
              </span>
              <h2 className="mt-4 font-display text-4xl font-bold tracking-tight text-ink-950 sm:text-5xl">
                {tPage("title1")}
                <br />
                <span className="text-brand-500">{tPage("title2")}</span>
              </h2>
            </div>
            <p className="text-base leading-relaxed text-ink-500 lg:col-span-5">
              {tPage("intro")}
            </p>
          </div>
        </div>
      </section>

      <section className="bg-ink-50 py-20 lg:py-28">
        <div className="container-page">
          <h2 className="font-display text-3xl font-bold tracking-tight text-ink-950 sm:text-4xl">
            {tPage("benefitsTitle")}
          </h2>
          <div className="mt-12 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {benefits.map((benefit, index) => {
              const Icon = BENEFIT_ICONS[index] ?? Rocket;
              return (
                <div
                  key={benefit.title}
                  className="rounded-3xl border border-ink-100 bg-white p-7 transition hover:border-brand-200 hover:shadow-md"
                >
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-50 ring-1 ring-brand-100">
                    <Icon size={20} className="text-brand-600" />
                  </div>
                  <h3 className="mt-5 font-display text-lg font-semibold text-ink-950">
                    {benefit.title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-ink-500">
                    {benefit.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="bg-white py-20 lg:py-28">
        <div className="container-page">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <h2 className="font-display text-3xl font-bold tracking-tight text-ink-950 sm:text-4xl">
              {tPage("openingsTitle")}
            </h2>
            {offers.length > 0 && (
              <span className="rounded-full bg-brand-50 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-brand-700">
                {offers.length}
              </span>
            )}
          </div>

          {offers.length === 0 ? (
            <p className="mt-10 text-ink-500">{tPage("empty")}</p>
          ) : (
            <div className="mt-10 divide-y divide-ink-100 overflow-hidden rounded-3xl border border-ink-100 bg-white">
              {offers.map((job) => (
                <Link
                  key={job.id}
                  href={`${PATHS.careers}/${job.slug}`}
                  className="group grid grid-cols-1 gap-4 p-6 transition hover:bg-ink-50 sm:grid-cols-12 sm:items-center sm:p-8"
                >
                  <div className="sm:col-span-9">
                    <div className="flex flex-wrap items-center gap-2">
                      {job.contract_type && (
                        <span className="rounded-full bg-brand-50 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-widest text-brand-700">
                          {job.contract_type}
                        </span>
                      )}
                      {job.location && (
                        <span className="inline-flex items-center gap-1 text-xs text-ink-500">
                          <MapPin size={12} /> {job.location}
                        </span>
                      )}
                      {!job.is_open && (
                        <span className="rounded-full bg-ink-100 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-widest text-ink-500">
                          {tPage("closed")}
                        </span>
                      )}
                    </div>
                    <h3 className="mt-3 font-display text-xl font-semibold text-ink-950">
                      {job.title}
                    </h3>
                    <p className="mt-2 line-clamp-2 max-w-2xl text-sm leading-relaxed text-ink-500">
                      {stripHtml(job.description)}
                    </p>
                  </div>
                  <div className="sm:col-span-3 sm:text-right">
                    <span className="inline-flex items-center gap-2 rounded-full bg-ink-950 px-5 py-2.5 text-sm font-semibold text-white transition group-hover:bg-brand-500">
                      {tPage("detailApply")}
                      <ArrowUpRight size={14} />
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="bg-ink-950 py-20 text-white lg:py-24">
        <div className="container-page grid grid-cols-1 items-center gap-8 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <span className="eyebrow-dark">
              <span className="h-1.5 w-1.5 rounded-full bg-brand-500" />
              {tPage("spontaneousTitle")}
            </span>
            <h2 className="mt-4 font-display text-3xl font-bold tracking-tight text-white sm:text-4xl">
              {tPage("spontaneousTitle")}
            </h2>
            <p className="mt-4 max-w-2xl text-base leading-relaxed text-ink-200/80">
              {tPage("spontaneousText")}
            </p>
          </div>
          <div className="lg:col-span-4 lg:text-right">
            <Link
              href={PATHS.contact}
              className="inline-flex items-center gap-2 rounded-full bg-brand-500 px-6 py-3 text-sm font-semibold text-white transition hover:bg-brand-600"
            >
              <Send size={16} />
              {tPage("spontaneousCta")}
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
