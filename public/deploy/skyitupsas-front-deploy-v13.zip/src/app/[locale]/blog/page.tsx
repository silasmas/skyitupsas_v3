import type { Metadata } from "next";
import { ArrowUpRight, Clock, Tags } from "lucide-react";
import { getTranslations, setRequestLocale } from "next-intl/server";
import PageHero from "@/components/sections/PageHero";
import CTA from "@/components/sections/CTA";
import { Link } from "@/i18n/navigation";
import { getBlogs } from "@/lib/api";
import { formatDate, readingTime } from "@/lib/format";
import { stripHtml } from "@/lib/html";
import { PATHS } from "@/lib/paths";

type Props = { params: Promise<{ locale: string }> };

/** Article de blog statique (repli issu des traductions). */
type StaticPost = {
  category: string;
  date: string;
  readTime: string;
  title: string;
  excerpt: string;
  image: string;
};

/** Forme normalisée d'un article, quelle que soit sa source (API ou statique). */
type DisplayPost = {
  key: string;
  slug?: string;
  title: string;
  excerpt: string;
  image: string;
  date: string;
  readTime: string;
  category?: string;
};

/** Image utilisée quand un article n'a pas d'image à la une. */
const FALLBACK_IMAGE = "/images/slider-1.png";

/**
 * Métadonnées SEO de la page Blog.
 *
 * @param params Paramètres de route contenant la locale
 */
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: "meta" });
  return {
    title: t("blogTitle"),
    description: t("blogDescription"),
  };
}

/**
 * Page Blog : bannière, article à la une, grille d'articles, thématiques
 * suivies et appel à l'action. Alimentée par l'API `/blogs`, avec repli sur
 * un contenu d'exemple traduit si aucun article n'est publié.
 *
 * @param params Paramètres de route contenant la locale
 */
export default async function BlogPage({ params }: Props) {
  const { locale } = await params;
  setRequestLocale(locale);
  const [apiPosts, t, tCta, tHero, tNav] = await Promise.all([
    getBlogs(locale, "blog"),
    getTranslations({ locale, namespace: "blog" }),
    getTranslations({ locale, namespace: "cta" }),
    getTranslations({ locale, namespace: "pageHero" }),
    getTranslations({ locale, namespace: "nav" }),
  ]);

  const topics = t.raw("topics") as string[];

  const posts: DisplayPost[] =
    apiPosts.length > 0
      ? apiPosts.map((post) => ({
          key: post.slug,
          slug: post.slug,
          title: post.title,
          excerpt: post.excerpt || stripHtml(post.content).slice(0, 160),
          image: post.featured_image || FALLBACK_IMAGE,
          date: formatDate(post.published_at, locale),
          readTime: String(readingTime(post.content)),
        }))
      : (t.raw("posts") as StaticPost[]).map((post) => ({
          key: post.title,
          title: post.title,
          excerpt: post.excerpt,
          image: post.image,
          date: post.date,
          readTime: post.readTime,
          category: post.category,
        }));

  const [featured, ...rest] = posts;

  return (
    <>
      <PageHero
        eyebrow={tHero("blogEyebrow")}
        title={tHero("blogTitle")}
        crumbs={[{ label: tNav("blog"), href: PATHS.blog }]}
        background="/images/slider-1.png"
      />

      <section className="bg-white py-20 lg:py-28">
        <div className="container-page">
          <div className="grid grid-cols-1 items-end gap-8 lg:grid-cols-12">
            <div className="lg:col-span-7">
              <span className="eyebrow">
                <span className="h-1.5 w-1.5 rounded-full bg-brand-500" />
                {t("eyebrow")}
              </span>
              <h2 className="mt-4 font-display text-4xl font-bold tracking-tight text-ink-950 sm:text-5xl">
                {t("title1")}
                <br />
                <span className="text-brand-500">{t("title2")}</span>
              </h2>
            </div>
            <p className="text-base leading-relaxed text-ink-500 lg:col-span-5">
              {t("intro")}
            </p>
          </div>

          {featured &&
            (() => {
              const featuredBody = (
                <>
                  <div className="relative min-h-72 lg:col-span-6">
                    <img
                      src={featured.image}
                      alt=""
                      className="absolute inset-0 h-full w-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-ink-950/70 to-transparent" />
                  </div>
                  <div className="p-7 sm:p-10 lg:col-span-6 lg:p-12">
                    <span className="rounded-full bg-brand-500 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-white">
                      {t("featuredLabel")}
                    </span>
                    <div className="mt-6 flex flex-wrap items-center gap-3 text-xs text-ink-200/70">
                      {featured.category && (
                        <>
                          <span>{featured.category}</span>
                          <span aria-hidden>·</span>
                        </>
                      )}
                      {featured.date && (
                        <>
                          <span>{featured.date}</span>
                          <span aria-hidden>·</span>
                        </>
                      )}
                      <span className="inline-flex items-center gap-1">
                        <Clock size={13} /> {featured.readTime}{" "}
                        {t("readTimeLabel")}
                      </span>
                    </div>
                    <h3 className="mt-4 font-display text-3xl font-bold leading-tight text-white sm:text-4xl">
                      {featured.title}
                    </h3>
                    <p className="mt-4 text-base leading-relaxed text-ink-200/80">
                      {featured.excerpt}
                    </p>
                  </div>
                </>
              );
              const className =
                "mt-14 grid overflow-hidden rounded-3xl border border-ink-100 bg-ink-950 text-white transition lg:grid-cols-12";
              return featured.slug ? (
                <Link
                  href={`${PATHS.blog}/${featured.slug}`}
                  className={`${className} hover:border-brand-500/40`}
                >
                  {featuredBody}
                </Link>
              ) : (
                <article className={className}>{featuredBody}</article>
              );
            })()}
        </div>
      </section>

      {rest.length > 0 && (
        <section className="bg-ink-50 py-20 lg:py-28">
          <div className="container-page">
            <div className="grid grid-cols-1 gap-12 lg:grid-cols-12">
              <div className="lg:col-span-8">
                <div className="grid grid-cols-1 gap-5 md:grid-cols-3">
                  {rest.map((post) => {
                    const href = post.slug
                      ? `${PATHS.blog}/${post.slug}`
                      : null;
                    const className =
                      "group block overflow-hidden rounded-3xl border border-ink-100 bg-white transition hover:-translate-y-1 hover:border-brand-200 hover:shadow-md";
                    const body = (
                      <>
                        <div className="relative aspect-[4/3] overflow-hidden">
                          <img
                            src={post.image}
                            alt=""
                            className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                          />
                        </div>
                        <div className="p-6">
                          <div className="flex flex-wrap items-center gap-2 text-[11px] font-medium uppercase tracking-wider text-ink-400">
                            {post.category && (
                              <>
                                <span>{post.category}</span>
                                <span aria-hidden>·</span>
                              </>
                            )}
                            <span>
                              {post.readTime} {t("readTimeLabel")}
                            </span>
                          </div>
                          <h3 className="mt-3 font-display text-lg font-semibold leading-snug text-ink-950">
                            {post.title}
                          </h3>
                          <p className="mt-3 text-sm leading-relaxed text-ink-500">
                            {post.excerpt}
                          </p>
                          <span className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-brand-600">
                            {tCta("learnMore")}
                            <ArrowUpRight size={14} />
                          </span>
                        </div>
                      </>
                    );
                    return href ? (
                      <Link key={post.key} href={href} className={className}>
                        {body}
                      </Link>
                    ) : (
                      <article key={post.key} className={className}>
                        {body}
                      </article>
                    );
                  })}
                </div>
              </div>

              <aside className="lg:col-span-4">
                <div className="rounded-3xl border border-ink-100 bg-white p-7">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-50">
                    <Tags size={19} className="text-brand-600" />
                  </div>
                  <h3 className="mt-5 font-display text-xl font-semibold text-ink-950">
                    {t("topicsTitle")}
                  </h3>
                  <div className="mt-5 flex flex-wrap gap-2">
                    {topics.map((topic) => (
                      <span
                        key={topic}
                        className="rounded-full border border-ink-100 bg-ink-50 px-3 py-1.5 text-xs font-medium text-ink-700"
                      >
                        {topic}
                      </span>
                    ))}
                  </div>
                </div>
              </aside>
            </div>
          </div>
        </section>
      )}

      <CTA />
    </>
  );
}
