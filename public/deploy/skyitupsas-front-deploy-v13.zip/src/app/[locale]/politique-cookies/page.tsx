import type { Metadata } from "next";
import { getTranslations, setRequestLocale } from "next-intl/server";
import PageHero from "@/components/sections/PageHero";
import CTA from "@/components/sections/CTA";
import { PATHS } from "@/lib/paths";

type Props = { params: Promise<{ locale: string }> };

/** Section de la politique de cookies (titre + corps). */
type PolicySection = { title: string; body: string };

/**
 * Métadonnées SEO de la page Politique de cookies.
 *
 * @param params Paramètres de route contenant la locale
 */
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: "meta" });
  return {
    title: t("cookiesTitle"),
    description: t("cookiesDescription"),
  };
}

/**
 * Page « Politique de cookies » : bannière, introduction et sections
 * explicatives (usage, types de cookies, gestion du consentement, contact).
 *
 * @param params Paramètres de route contenant la locale
 */
export default async function CookiesPolicyPage({ params }: Props) {
  const { locale } = await params;
  setRequestLocale(locale);

  const [tHero, tNav, tPage] = await Promise.all([
    getTranslations({ locale, namespace: "pageHero" }),
    getTranslations({ locale, namespace: "nav" }),
    getTranslations({ locale, namespace: "cookiesPage" }),
  ]);

  const sections = tPage.raw("sections") as PolicySection[];

  return (
    <>
      <PageHero
        eyebrow={tHero("cookiesEyebrow")}
        title={tHero("cookiesTitle")}
        crumbs={[{ label: tHero("cookiesTitle"), href: PATHS.cookies }]}
        background="/images/slider-2.png"
      />

      <section className="bg-white py-16 lg:py-24">
        <div className="container-page mx-auto max-w-3xl">
          <p className="text-lg leading-relaxed text-ink-700">
            {tPage("intro")}
          </p>

          <div className="mt-12 space-y-10">
            {sections.map((section) => (
              <div key={section.title}>
                <h2 className="font-display text-xl font-semibold text-ink-950">
                  {section.title}
                </h2>
                <p className="mt-3 text-base leading-relaxed text-ink-500">
                  {section.body}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CTA />
    </>
  );
}
