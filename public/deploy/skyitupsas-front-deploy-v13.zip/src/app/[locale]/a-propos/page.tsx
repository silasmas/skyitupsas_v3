import type { Metadata } from "next";
import { getTranslations, setRequestLocale } from "next-intl/server";
import PageHero from "@/components/sections/PageHero";
import AboutSection from "@/components/sections/AboutSection";
import TeamGrid from "@/components/sections/TeamGrid";
import RichText from "@/components/RichText";
import CTA from "@/components/sections/CTA";
import { getAbout, getTeamMembers } from "@/lib/api";
import { PATHS } from "@/lib/paths";

type Props = { params: Promise<{ locale: string }> };

/**
 * Métadonnées SEO de la page À propos.
 *
 * @param params Paramètres de route contenant la locale
 */
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: "meta" });
  return {
    title: t("aboutTitle"),
    description: t("aboutDescription"),
  };
}

/**
 * Page À propos : bannière, présentation de l'entreprise (contenu CMS si
 * disponible), piliers mission/vision/valeurs, équipe et appel à l'action.
 *
 * @param params Paramètres de route contenant la locale
 */
export default async function AboutPage({ params }: Props) {
  const { locale } = await params;
  setRequestLocale(locale);
  const [about, teamMembers, tHero, tNav] = await Promise.all([
    getAbout(locale),
    getTeamMembers(locale),
    getTranslations({ locale, namespace: "pageHero" }),
    getTranslations({ locale, namespace: "nav" }),
  ]);

  const paragraphs = [about?.content1, about?.content2, about?.content].filter(
    (paragraph): paragraph is string => Boolean(paragraph)
  );
  const hasCmsContent = Boolean(about) && paragraphs.length > 0;

  return (
    <>
      <PageHero
        eyebrow={tHero("aboutEyebrow")}
        title={tHero("aboutTitle")}
        crumbs={[{ label: tNav("about"), href: PATHS.about }]}
        background="/images/slider-2.png"
      />

      {hasCmsContent && (
        <section className="bg-white py-20 lg:py-28">
          <div className="container-page grid grid-cols-1 gap-12 lg:grid-cols-12">
            <div className="lg:col-span-5">
              <h2 className="font-display text-3xl font-bold tracking-tight text-ink-950 sm:text-4xl">
                {about?.big_title || about?.title}
              </h2>
              {about?.subtitle && (
                <p className="mt-4 text-base font-medium text-brand-600">
                  {about.subtitle}
                </p>
              )}
            </div>
            <div className="space-y-5 lg:col-span-7">
              {paragraphs.map((paragraph, index) => (
                <RichText key={index} content={paragraph} />
              ))}
            </div>
          </div>
        </section>
      )}

      <AboutSection />
      <TeamGrid members={teamMembers} />
      <CTA />
    </>
  );
}
