import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getTranslations, setRequestLocale } from "next-intl/server";
import PageHero from "@/components/sections/PageHero";
import ArticleContent from "@/components/sections/ArticleContent";
import CTA from "@/components/sections/CTA";
import { getBlog } from "@/lib/api";
import { stripHtml } from "@/lib/html";
import { PATHS } from "@/lib/paths";

type Props = { params: Promise<{ locale: string; slug: string }> };

/**
 * Métadonnées SEO de l'actualité (titre + description dynamiques).
 *
 * @param params Paramètres de route (locale + slug)
 */
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale, slug } = await params;
  const article = await getBlog(slug, locale);
  if (!article) {
    return {};
  }
  return {
    title: `${article.title} — SkyITup SAS`,
    description:
      article.meta_description ||
      article.excerpt ||
      stripHtml(article.content).slice(0, 160),
  };
}

/**
 * Page de détail d'une actualité : bannière, contenu complet et CTA.
 * Le contenu provient de la même source `/blogs` que la liste.
 *
 * @param params Paramètres de route (locale + slug)
 */
export default async function NewsDetailPage({ params }: Props) {
  const { locale, slug } = await params;
  setRequestLocale(locale);
  const article = await getBlog(slug, locale);
  if (!article) {
    notFound();
  }

  const [tHero, tNav, tNews] = await Promise.all([
    getTranslations({ locale, namespace: "pageHero" }),
    getTranslations({ locale, namespace: "nav" }),
    getTranslations({ locale, namespace: "news" }),
  ]);

  return (
    <>
      <PageHero
        eyebrow={tHero("newsEyebrow")}
        title={article.title}
        crumbs={[
          { label: tNav("news"), href: PATHS.news },
          { label: article.title },
        ]}
        background={article.featured_image || "/images/slider-4.png"}
      />

      <ArticleContent
        article={article}
        locale={locale}
        backHref={PATHS.news}
        backLabel={tNews("back")}
        readTimeLabel={tNews("readTimeLabel")}
      />

      <CTA />
    </>
  );
}
