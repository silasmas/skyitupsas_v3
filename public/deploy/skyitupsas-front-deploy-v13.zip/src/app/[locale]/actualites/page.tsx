import type { Metadata } from "next";
import { ArrowUpRight, CalendarDays, MapPin } from "lucide-react";
import { getTranslations, setRequestLocale } from "next-intl/server";
import PageHero from "@/components/sections/PageHero";
import CTA from "@/components/sections/CTA";
import { Link } from "@/i18n/navigation";
import { getBlogs } from "@/lib/api";
import { formatDate } from "@/lib/format";
import { stripHtml } from "@/lib/html";
import { PATHS } from "@/lib/paths";

type Props = { params: Promise<{ locale: string }> };

/** Actualité statique (repli issu des traductions). */
type StaticNews = {
  type: string;
  date: string;
  title: string;
  excerpt: string;
  image: string;
};

/** Forme normalisée d'une actualité (API ou statique). */
type DisplayNews = {
  key: string;
  slug?: string;
  title: string;
  excerpt: string;
  image: string;
  date: string;
  type?: string;
};

/** Élément d'agenda (date, libellé, lieu). */
type AgendaEvent = {
  date: string;
  label: string;
  location: string;
};

/** Image utilisée quand une actualité n'a pas d'image à la une. */
const FALLBACK_IMAGE = "/images/slider-4.png";

/**
 * Métadonnées SEO de la page Actualités.
 *
 * @param params Paramètres de route contenant la locale
 */
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: "meta" });
  return {
    title: t("newsTitle"),
    description: t("newsDescription"),
  };
}

/**
 * Page Actualités : bannière, dernière annonce, liste des actualités et agenda.
 * Le fil d'actualités est alimenté par l'API `/blogs` (repli sur un contenu
 * d'exemple traduit) ; l'agenda des événements reste statique.
 *
 * @param params Paramètres de route contenant la locale
 */
export default async function NewsPage({ params }: Props) {
  const { locale } = await params;
  setRequestLocale(locale);
  const [apiPosts, t, tCta, tHero, tNav] = await Promise.all([
    getBlogs(locale, "news"),
    getTranslations({ locale, namespace: "news" }),
    getTranslations({ locale, namespace: "cta" }),
    getTranslations({ locale, namespace: "pageHero" }),
    getTranslations({ locale, namespace: "nav" }),
  ]);

  const events = t.raw("events") as AgendaEvent[];

  const items: DisplayNews[] =
    apiPosts.length > 0
      ? apiPosts.map((post) => ({
          key: post.slug,
          slug: post.slug,
          title: post.title,
          excerpt: post.excerpt || stripHtml(post.content).slice(0, 180),
          image: post.featured_image || FALLBACK_IMAGE,
          date: formatDate(post.published_at, locale),
        }))
      : (t.raw("items") as StaticNews[]).map((item) => ({
          key: item.title,
          title: item.title,
          excerpt: item.excerpt,
          image: item.image,
          date: item.date,
          type: item.type,
        }));

  const [latest, ...rest] = items;

  return (
    <>
      <PageHero
        eyebrow={tHero("newsEyebrow")}
        title={tHero("newsTitle")}
        crumbs={[{ label: tNav("news"), href: PATHS.news }]}
        background="/images/slider-4.png"
      />

      <section className="bg-white py-20 lg:py-28">
        <div className="container-page">
          <div className="grid grid-cols-1 items-end gap-8 lg:grid-cols-12">
            <div className="lg:col-span-7">
              <span className="eyebrow">
                <span className="h-1.5 w-1.5 rounded-full bg-brand-500" />
                {t("eyebrow")}
              </span>
              <h2 className="mt-4 font-display text-4xl font-bold tracking-tight text-ink-950 sm:text-5xl">
                {t("title1")}
                <br />
                <span className="text-brand-500">{t("title2")}</span>
              </h2>
            </div>
            <p className="text-base leading-relaxed text-ink-500 lg:col-span-5">
              {t("intro")}
            </p>
          </div>

          {latest &&
            (() => {
              const latestBody = (
                <>
                  <div className="relative min-h-72 lg:col-span-7">
                    <img
                      src={latest.image}
                      alt=""
                      className="absolute inset-0 h-full w-full object-cover"
                    />
                  </div>
                  <div className="bg-ink-950 p-7 text-white sm:p-10 lg:col-span-5 lg:p-12">
                    <span className="rounded-full bg-brand-500 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-white">
                      {t("latestLabel")}
                    </span>
                    <div className="mt-6 flex flex-wrap items-center gap-3 text-xs text-ink-200/70">
                      {latest.type && (
                        <>
                          <span>{latest.type}</span>
                          <span aria-hidden>·</span>
                        </>
                      )}
                      {latest.date && <span>{latest.date}</span>}
                    </div>
                    <h3 className="mt-4 font-display text-3xl font-bold leading-tight text-white">
                      {latest.title}
                    </h3>
                    <p className="mt-4 text-base leading-relaxed text-ink-200/80">
                      {latest.excerpt}
                    </p>
                  </div>
                </>
              );
              const className =
                "mt-14 grid grid-cols-1 overflow-hidden rounded-3xl border border-ink-100 bg-white shadow-sm transition lg:grid-cols-12";
              return latest.slug ? (
                <Link
                  href={`${PATHS.news}/${latest.slug}`}
                  className={`${className} hover:border-brand-300`}
                >
                  {latestBody}
                </Link>
              ) : (
                <article className={className}>{latestBody}</article>
              );
            })()}
        </div>
      </section>

      <section className="bg-ink-50 py-20 lg:py-28">
        <div className="container-page grid grid-cols-1 gap-12 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <div className="space-y-5">
              {rest.map((item) => {
                const href = item.slug ? `${PATHS.news}/${item.slug}` : null;
                const className =
                  "group grid grid-cols-1 overflow-hidden rounded-3xl border border-ink-100 bg-white transition hover:border-brand-200 hover:shadow-md sm:grid-cols-12";
                const body = (
                  <>
                    <div className="relative min-h-56 sm:col-span-5">
                      <img
                        src={item.image}
                        alt=""
                        className="absolute inset-0 h-full w-full object-cover transition duration-500 group-hover:scale-105"
                      />
                    </div>
                    <div className="p-6 sm:col-span-7 sm:p-8">
                      <div className="flex flex-wrap items-center gap-2 text-[11px] font-medium uppercase tracking-wider text-ink-400">
                        {item.type && (
                          <>
                            <span>{item.type}</span>
                            <span aria-hidden>·</span>
                          </>
                        )}
                        {item.date && <span>{item.date}</span>}
                      </div>
                      <h3 className="mt-3 font-display text-2xl font-semibold leading-snug text-ink-950">
                        {item.title}
                      </h3>
                      <p className="mt-3 text-sm leading-relaxed text-ink-500">
                        {item.excerpt}
                      </p>
                      <span className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-brand-600">
                        {tCta("learnMore")}
                        <ArrowUpRight size={14} />
                      </span>
                    </div>
                  </>
                );
                return href ? (
                  <Link key={item.key} href={href} className={className}>
                    {body}
                  </Link>
                ) : (
                  <article key={item.key} className={className}>
                    {body}
                  </article>
                );
              })}
            </div>
          </div>

          <aside className="lg:col-span-4">
            <div className="rounded-3xl border border-ink-100 bg-white p-7">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-50">
                <CalendarDays size={19} className="text-brand-600" />
              </div>
              <h3 className="mt-5 font-display text-xl font-semibold text-ink-950">
                {t("eventsTitle")}
              </h3>
              <div className="mt-6 space-y-4">
                {events.map((event) => (
                  <div
                    key={event.label}
                    className="border-t border-ink-100 pt-4 first:border-t-0 first:pt-0"
                  >
                    <div className="text-xs font-semibold uppercase tracking-widest text-brand-600">
                      {event.date}
                    </div>
                    <div className="mt-1 font-display text-base font-semibold text-ink-950">
                      {event.label}
                    </div>
                    <div className="mt-2 inline-flex items-center gap-1 text-xs text-ink-500">
                      <MapPin size={12} />
                      {event.location}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </aside>
        </div>
      </section>

      <CTA />
    </>
  );
}
