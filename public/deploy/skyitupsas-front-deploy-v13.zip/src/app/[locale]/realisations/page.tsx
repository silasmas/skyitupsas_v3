import type { Metadata } from "next";
import { getTranslations, setRequestLocale } from "next-intl/server";
import PageHero from "@/components/sections/PageHero";
import RealisationsGrid from "@/components/sections/RealisationsGrid";
import Testimonials from "@/components/sections/Testimonials";
import Partners from "@/components/sections/Partners";
import CTA from "@/components/sections/CTA";
import { getRealisations } from "@/lib/api";
import { PATHS } from "@/lib/paths";

type Props = { params: Promise<{ locale: string }> };

/**
 * Métadonnées SEO de la page Réalisations.
 *
 * @param params Paramètres de route contenant la locale
 */
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: "meta" });
  return {
    title: t("projectsTitle"),
    description: t("projectsDescription"),
  };
}

/**
 * Page Réalisations : bannière, grille des projets (via API) et appel à l'action.
 *
 * @param params Paramètres de route contenant la locale
 */
export default async function RealisationsPage({ params }: Props) {
  const { locale } = await params;
  setRequestLocale(locale);
  const [realisations, tHero, tNav] = await Promise.all([
    getRealisations(locale),
    getTranslations({ locale, namespace: "pageHero" }),
    getTranslations({ locale, namespace: "nav" }),
  ]);

  return (
    <>
      <PageHero
        eyebrow={tHero("projectsEyebrow")}
        title={tHero("projectsTitle")}
        crumbs={[{ label: tNav("projects"), href: PATHS.projects }]}
        background="/images/slider-4.png"
      />
      <RealisationsGrid realisations={realisations} />
      <Testimonials />
      <Partners />
      <CTA />
    </>
  );
}
