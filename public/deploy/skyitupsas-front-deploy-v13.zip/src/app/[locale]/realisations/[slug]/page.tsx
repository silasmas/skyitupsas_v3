import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowUpRight } from "lucide-react";
import { getTranslations, setRequestLocale } from "next-intl/server";
import PageHero from "@/components/sections/PageHero";
import CTA from "@/components/sections/CTA";
import RichText from "@/components/RichText";
import { Link } from "@/i18n/navigation";
import { getRealisation } from "@/lib/api";
import { stripHtml } from "@/lib/html";
import { PATHS } from "@/lib/paths";

type Props = { params: Promise<{ locale: string; slug: string }> };

/**
 * Métadonnées SEO de la réalisation (titre + description dynamiques).
 *
 * @param params Paramètres de route (locale + slug)
 */
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale, slug } = await params;
  const project = await getRealisation(slug, locale);
  if (!project) {
    return {};
  }
  return {
    title: `${project.title} — SkyITup SAS`,
    description: stripHtml(project.description).slice(0, 160),
  };
}

/**
 * Page de détail d'une réalisation : bannière, métadonnées projet, contenu
 * complet et CTA.
 *
 * @param params Paramètres de route (locale + slug)
 */
export default async function RealisationDetailPage({ params }: Props) {
  const { locale, slug } = await params;
  setRequestLocale(locale);
  const project = await getRealisation(slug, locale);
  if (!project) {
    notFound();
  }

  const [tHero, tNav, tPage] = await Promise.all([
    getTranslations({ locale, namespace: "pageHero" }),
    getTranslations({ locale, namespace: "nav" }),
    getTranslations({ locale, namespace: "projectsPage" }),
  ]);

  return (
    <>
      <PageHero
        eyebrow={tHero("projectsEyebrow")}
        title={project.title}
        crumbs={[
          { label: tNav("projects"), href: PATHS.projects },
          { label: project.title },
        ]}
        background={project.featured_image || "/images/slider-2.png"}
      />

      <section className="bg-white py-16 lg:py-24">
        <div className="container-page mx-auto max-w-3xl">
          <Link
            href={PATHS.projects}
            className="inline-flex items-center gap-2 text-sm font-semibold text-ink-500 transition hover:text-brand-600"
          >
            <ArrowLeft size={15} />
            {tPage("back")}
          </Link>

          <div className="mt-6 flex flex-wrap gap-6 text-sm text-ink-500">
            {project.client && (
              <div>
                <span className="block text-xs font-medium uppercase tracking-wider text-ink-400">
                  {tPage("clientLabel")}
                </span>
                <span className="font-semibold text-ink-950">
                  {project.client}
                </span>
              </div>
            )}
            {project.project_date && (
              <div>
                <span className="block text-xs font-medium uppercase tracking-wider text-ink-400">
                  {tPage("dateLabel")}
                </span>
                <span className="font-semibold text-ink-950">
                  {project.project_date}
                </span>
              </div>
            )}
          </div>

          {project.featured_image && (
            <div className="mt-8 overflow-hidden rounded-3xl border border-ink-100">
              <img
                src={project.featured_image}
                alt={project.title}
                className="w-full object-cover"
              />
            </div>
          )}

          <RichText content={project.description} className="mt-10" />

          {project.project_url && (
            <a
              href={project.project_url}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-8 inline-flex items-center gap-2 rounded-full bg-brand-500 px-6 py-3 text-sm font-semibold text-white transition hover:bg-brand-600"
            >
              {tPage("viewProject")}
              <ArrowUpRight size={16} />
            </a>
          )}
        </div>
      </section>

      <CTA />
    </>
  );
}
