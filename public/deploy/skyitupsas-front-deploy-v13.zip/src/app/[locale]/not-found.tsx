import { useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import { PATHS } from "@/lib/paths";

/** Page 404 localisée, alignée sur le design du template. */
export default function NotFound() {
  const t = useTranslations("notFound");

  return (
    <section className="flex min-h-[70vh] items-center bg-ink-50 py-24">
      <div className="container-page text-center">
        <div className="font-display text-7xl font-bold text-brand-500 sm:text-8xl">
          404
        </div>
        <h1 className="mt-6 font-display text-3xl font-bold text-ink-950 sm:text-4xl">
          {t("title")}
        </h1>
        <p className="mx-auto mt-4 max-w-md text-base text-ink-500">
          {t("text")}
        </p>
        <Link href={PATHS.home} className="btn-primary mt-8 inline-flex">
          {t("cta")}
        </Link>
      </div>
    </section>
  );
}
