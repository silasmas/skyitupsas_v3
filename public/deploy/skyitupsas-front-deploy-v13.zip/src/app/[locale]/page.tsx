import type { Metadata } from "next";
import { getTranslations, setRequestLocale } from "next-intl/server";
import Hero from "@/components/sections/Hero";
import Stats from "@/components/sections/Stats";
import ServicesPillarsTeaser from "@/components/sections/ServicesPillarsTeaser";
import ProjectsShowcase from "@/components/sections/ProjectsShowcase";
import Process from "@/components/sections/Process";
import Solutions from "@/components/sections/Solutions";
import AboutSection from "@/components/sections/AboutSection";
import TeamGrid from "@/components/sections/TeamGrid";
import Testimonials from "@/components/sections/Testimonials";
import CareersTeaser from "@/components/sections/CareersTeaser";
import Partners from "@/components/sections/Partners";
import CTA from "@/components/sections/CTA";
import { getServicePillars, getTeamMembers } from "@/lib/api";

type Props = { params: Promise<{ locale: string }> };

/**
 * Métadonnées SEO de la page d'accueil (traduites par locale).
 *
 * @param params Paramètres de route contenant la locale
 */
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: "meta" });
  return {
    title: t("homeTitle"),
    description: t("homeDescription"),
  };
}

/**
 * Page d'accueil : reprend l'enchaînement de sections du template
 * (accroche, chiffres clés, services, réalisations, méthodologie, solutions,
 * à propos, équipe, témoignages, teaser carrières, partenaires, appel à l'action).
 *
 * @param params Paramètres de route contenant la locale
 */
export default async function HomePage({ params }: Props) {
  const { locale } = await params;
  setRequestLocale(locale);
  const [pillars, teamMembers] = await Promise.all([
    getServicePillars(locale),
    getTeamMembers(locale),
  ]);

  return (
    <>
      <Hero />
      <Stats />
      <ServicesPillarsTeaser pillars={pillars} />
      <ProjectsShowcase />
      <Process />
      <Solutions />
      <AboutSection />
      <TeamGrid members={teamMembers} />
      <Testimonials />
      <CareersTeaser />
      <Partners />
      <CTA />
    </>
  );
}
