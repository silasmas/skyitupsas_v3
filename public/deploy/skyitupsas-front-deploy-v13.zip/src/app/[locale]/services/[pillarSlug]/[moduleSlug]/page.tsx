import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { getTranslations, setRequestLocale } from "next-intl/server";
import PageHero from "@/components/sections/PageHero";
import CTA from "@/components/sections/CTA";
import RichText from "@/components/RichText";
import { Link } from "@/i18n/navigation";
import { getServiceModule, getServicePillar } from "@/lib/api";
import { stripHtml } from "@/lib/html";
import { PATHS } from "@/lib/paths";

type Props = {
  params: Promise<{ locale: string; pillarSlug: string; moduleSlug: string }>;
};

/**
 * Métadonnées SEO d'un module de service.
 *
 * @param params Paramètres de route
 */
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale, moduleSlug } = await params;
  const moduleItem = await getServiceModule(moduleSlug, locale);
  if (!moduleItem) {
    return {};
  }
  return {
    title: `${moduleItem.title} — SkyITup SAS`,
    description:
      moduleItem.meta_description ||
      stripHtml(moduleItem.summary_text || moduleItem.benefit_text || "").slice(
        0,
        160
      ),
  };
}

/**
 * Page détail d'un module rattaché à un pilier.
 *
 * @param params Paramètres de route
 */
export default async function ServiceModulePage({ params }: Props) {
  const { locale, pillarSlug, moduleSlug } = await params;
  setRequestLocale(locale);
  const [moduleItem, pillar] = await Promise.all([
    getServiceModule(moduleSlug, locale),
    getServicePillar(pillarSlug, locale),
  ]);

  if (!moduleItem || !pillar || moduleItem.pillar_slug !== pillar.slug) {
    notFound();
  }

  const [tHero, tNav, tSection] = await Promise.all([
    getTranslations({ locale, namespace: "pageHero" }),
    getTranslations({ locale, namespace: "nav" }),
    getTranslations({ locale, namespace: "servicesSection" }),
  ]);

  return (
    <>
      <PageHero
        eyebrow={pillar.title}
        title={moduleItem.title}
        crumbs={[
          { label: tNav("services"), href: PATHS.services },
          { label: pillar.title, href: `${PATHS.services}/${pillar.slug}` },
          { label: moduleItem.title },
        ]}
        background={moduleItem.featured_image || pillar.featured_image || "/images/slider-3.png"}
      />

      <section className="bg-white py-16 lg:py-24">
        <div className="container-page mx-auto max-w-3xl">
          <Link
            href={`${PATHS.services}/${pillar.slug}`}
            className="inline-flex items-center gap-2 text-sm font-semibold text-ink-500 transition hover:text-brand-600"
          >
            <ArrowLeft size={15} />
            {tSection("backToPillar")}
          </Link>

          {moduleItem.summary_text && (
            <p className="mt-6 text-lg leading-relaxed text-ink-700">
              {moduleItem.summary_text}
            </p>
          )}

          {moduleItem.benefit_text && (
            <RichText content={moduleItem.benefit_text} className="mt-10" />
          )}

          {moduleItem.cta_label && (
            <div className="mt-12 rounded-3xl bg-brand-500 p-8 text-white">
              <p className="text-base font-medium leading-relaxed">
                {moduleItem.cta_label}
              </p>
              <Link
                href={PATHS.contact}
                className="mt-6 inline-flex rounded-full bg-white px-6 py-3 text-sm font-semibold text-brand-700 transition hover:bg-brand-50"
              >
                {tSection("ctaContact")}
              </Link>
            </div>
          )}
        </div>
      </section>

      <CTA />
    </>
  );
}
