import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { getTranslations, setRequestLocale } from "next-intl/server";
import PageHero from "@/components/sections/PageHero";
import CTA from "@/components/sections/CTA";
import RichText from "@/components/RichText";
import { Link } from "@/i18n/navigation";
import { getServicePillar } from "@/lib/api";
import { stripHtml } from "@/lib/html";
import { PATHS } from "@/lib/paths";

type Props = { params: Promise<{ locale: string; pillarSlug: string }> };

/**
 * Métadonnées SEO d'un pilier de services.
 *
 * @param params Paramètres de route (locale + slug pilier)
 */
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale, pillarSlug } = await params;
  const pillar = await getServicePillar(pillarSlug, locale);
  if (!pillar) {
    return {};
  }
  return {
    title: `${pillar.title} — SkyITup SAS`,
    description:
      pillar.meta_description ||
      stripHtml(pillar.differentiator || pillar.offer_summary || "").slice(
        0,
        160
      ),
  };
}

/**
 * Page détail d'un pilier stratégique et liste de ses modules.
 *
 * @param params Paramètres de route (locale + slug pilier)
 */
export default async function ServicePillarPage({ params }: Props) {
  const { locale, pillarSlug } = await params;
  setRequestLocale(locale);
  const pillar = await getServicePillar(pillarSlug, locale);
  if (!pillar) {
    notFound();
  }

  const [tHero, tNav, tSection] = await Promise.all([
    getTranslations({ locale, namespace: "pageHero" }),
    getTranslations({ locale, namespace: "nav" }),
    getTranslations({ locale, namespace: "servicesSection" }),
  ]);

  const modules = pillar.modules ?? [];

  return (
    <>
      <PageHero
        eyebrow={tHero("servicesEyebrow")}
        title={pillar.title}
        crumbs={[
          { label: tNav("services"), href: PATHS.services },
          { label: pillar.title },
        ]}
        background={pillar.featured_image || "/images/slider-3.png"}
      />

      <section className="bg-white py-16 lg:py-24">
        <div className="container-page mx-auto max-w-4xl">
          <Link
            href={PATHS.services}
            className="inline-flex items-center gap-2 text-sm font-semibold text-ink-500 transition hover:text-brand-600"
          >
            <ArrowLeft size={15} />
            {tSection("back")}
          </Link>

          {pillar.tagline && (
            <p className="mt-6 text-lg italic leading-relaxed text-ink-700">
              « {pillar.tagline} »
            </p>
          )}

          <div className="mt-8 grid gap-4 sm:grid-cols-2">
            {pillar.client_challenge && (
              <div className="rounded-2xl border border-ink-100 bg-ink-50/60 p-5">
                <p className="text-xs font-semibold uppercase tracking-wider text-brand-600">
                  {tSection("clientChallenge")}
                </p>
                <p className="mt-2 text-sm text-ink-700">
                  {pillar.client_challenge}
                </p>
              </div>
            )}
            {pillar.offer_summary && (
              <div className="rounded-2xl border border-ink-100 bg-ink-50/60 p-5">
                <p className="text-xs font-semibold uppercase tracking-wider text-brand-600">
                  {tSection("ourOffer")}
                </p>
                <p className="mt-2 text-sm text-ink-700">
                  {pillar.offer_summary}
                </p>
              </div>
            )}
          </div>

          {pillar.differentiator && (
            <RichText
              content={pillar.differentiator}
              className="mt-10 rounded-3xl border border-brand-100 bg-brand-50/40 p-6"
            />
          )}

          {modules.length > 0 && (
            <div className="mt-14">
              <h2 className="font-display text-2xl font-bold text-ink-950">
                {tSection("modulesTitle")}
              </h2>
              <ul className="mt-6 space-y-4">
                {modules.map((module) => (
                  <li key={module.id}>
                    <Link
                      href={`${PATHS.services}/${pillar.slug}/${module.slug}`}
                      className="block rounded-2xl border border-ink-100 p-6 transition hover:border-brand-200 hover:bg-ink-50/50"
                    >
                      <h3 className="font-display text-xl font-semibold text-ink-950">
                        {module.title}
                      </h3>
                      <p className="mt-2 text-sm leading-relaxed text-ink-500">
                        {stripHtml(
                          module.summary_text || module.benefit_text || ""
                        ).slice(0, 220)}
                      </p>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </section>

      <CTA />
    </>
  );
}
