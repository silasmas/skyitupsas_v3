import type { Metadata } from "next";
import { getTranslations, setRequestLocale } from "next-intl/server";
import PageHero from "@/components/sections/PageHero";
import ServicesPillars from "@/components/sections/ServicesPillars";
import Process from "@/components/sections/Process";
import CTA from "@/components/sections/CTA";
import { getServicePillars } from "@/lib/api";
import { PATHS } from "@/lib/paths";

type Props = { params: Promise<{ locale: string }> };

/**
 * Métadonnées SEO de la page Services (traduites par locale).
 *
 * @param params Paramètres de route contenant la locale
 */
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: "meta" });
  return {
    title: t("servicesTitle"),
    description: t("servicesDescription"),
  };
}

/**
 * Page Services : cartographie en 5 piliers stratégiques et modules (API).
 *
 * @param params Paramètres de route contenant la locale
 */
export default async function ServicesPage({ params }: Props) {
  const { locale } = await params;
  setRequestLocale(locale);
  const [pillars, tHero, tNav] = await Promise.all([
    getServicePillars(locale),
    getTranslations({ locale, namespace: "pageHero" }),
    getTranslations({ locale, namespace: "nav" }),
  ]);

  return (
    <>
      <PageHero
        eyebrow={tHero("servicesEyebrow")}
        title={tHero("servicesTitle")}
        crumbs={[{ label: tNav("services"), href: PATHS.services }]}
      />
      <ServicesPillars pillars={pillars} />
      <Process />
      <CTA />
    </>
  );
}
