import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Inter, Sora } from "next/font/google";
import { NextIntlClientProvider, hasLocale } from "next-intl";
import { setRequestLocale } from "next-intl/server";
import { routing } from "@/i18n/routing";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Chatbot from "@/components/Chatbot";
import CookieConsent from "@/components/CookieConsent";
import { getContact } from "@/lib/api";
import "@/app/globals.css";

const sora = Sora({
  subsets: ["latin"],
  variable: "--font-sora",
  display: "swap",
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://skyitupsas.org"),
  title: {
    default: "SkyITup SAS",
    template: "%s",
  },
};

/** Pré-génère une variante statique par locale supportée. */
export function generateStaticParams() {
  return routing.locales.map((locale) => ({ locale }));
}

/**
 * Layout racine par locale : injecte les polices, le provider i18n et le
 * shell commun (header, footer, chatbot).
 *
 * @param children Contenu de la page
 * @param params Paramètres de route contenant la locale
 */
export default async function LocaleLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!hasLocale(routing.locales, locale)) {
    notFound();
  }
  setRequestLocale(locale);
  const contact = await getContact(locale);

  return (
    <html lang={locale} className={`${sora.variable} ${inter.variable}`}>
      <body className="min-h-screen">
        <NextIntlClientProvider>
          <Header />
          <main>{children}</main>
          <Footer contact={contact} />
          <Chatbot key={locale} />
          <CookieConsent />
        </NextIntlClientProvider>
      </body>
    </html>
  );
}
