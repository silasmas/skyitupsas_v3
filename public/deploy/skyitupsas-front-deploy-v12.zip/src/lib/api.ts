import type {
  ApiAbout,
  ApiBlog,
  ApiCollection,
  ApiContact,
  ApiJobOffer,
  ApiPartner,
  ApiRealisation,
  ApiService,
  ApiServiceModule,
  ApiServicePillar,
  ApiTeamMember,
  BlogType,
} from "./types";
import { resolveTranslatable } from "./translatable";

const API_BASE_URL = process.env.API_BASE_URL ?? "http://127.0.0.1:8000/api/v1";

/** Durée de revalidation ISR par défaut (secondes) — filet de sécurité. */
const REVALIDATE_SECONDS = 60;

/** Tag de cache partagé : invalidé par /api/revalidate après une édition CMS. */
const CMS_CACHE_TAG = "cms";

/**
 * Effectue un GET sur l'API Laravel en demandant le contenu dans la locale
 * fournie (en-tête `X-Locale`), avec revalidation ISR.
 *
 * @param path Chemin relatif de l'endpoint (ex. "/services")
 * @param locale Code langue (fr|en)
 * @returns La charge utile JSON typée
 */
async function apiGet<T>(path: string, locale: string): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    headers: {
      Accept: "application/json",
      "X-Locale": locale,
    },
    next: {
      revalidate: REVALIDATE_SECONDS,
      tags: [CMS_CACHE_TAG, `cms:${path.split("?")[0]}`],
    },
  });

  if (!response.ok) {
    throw new Error(`API ${path} a répondu ${response.status}`);
  }

  return response.json() as Promise<T>;
}

/**
 * Récupère une collection en absorbant les erreurs réseau (retourne []).
 * Évite de casser le rendu de la page si l'API est momentanément indisponible.
 *
 * @param path Chemin de la collection
 * @param locale Code langue (fr|en)
 * @returns Le tableau de données, ou [] en cas d'échec
 */
async function safeCollection<T>(path: string, locale: string): Promise<T[]> {
  try {
    const json = await apiGet<ApiCollection<T>>(path, locale);
    return json.data ?? [];
  } catch {
    return [];
  }
}

/**
 * Récupère une ressource unique en absorbant les erreurs réseau.
 *
 * @param path Chemin de la ressource (ex. "/job-offers/xxx")
 * @param locale Code langue (fr|en)
 * @returns La ressource, ou null en cas d'échec
 */
async function safeSingle<T>(path: string, locale: string): Promise<T | null> {
  try {
    const json = await apiGet<{ data: T }>(path, locale);
    return json.data ?? null;
  } catch {
    return null;
  }
}

/**
 * Liste les services actifs.
 *
 * @param locale Code langue (fr|en)
 */
export function getServices(locale: string): Promise<ApiService[]> {
  return safeCollection<ApiService>("/services", locale);
}

/**
 * Récupère un service par son slug.
 *
 * @param slug Identifiant du service
 * @param locale Code langue (fr|en)
 * @returns Le service, ou null si introuvable
 */
export function getService(
  slug: string,
  locale: string
): Promise<ApiService | null> {
  return safeSingle<ApiService>(`/services/${slug}`, locale);
}

/**
 * Normalise les champs traduisibles d'un module API.
 *
 * @param module Module brut
 * @returns Module avec chaînes normalisées
 */
function normalizeServiceModule(module: ApiServiceModule): ApiServiceModule {
  return {
    ...module,
    title: resolveTranslatable(module.title),
    benefit_text: resolveTranslatable(module.benefit_text) || null,
    summary_text: resolveTranslatable(module.summary_text) || null,
    cta_label: resolveTranslatable(module.cta_label) || null,
    meta_description: resolveTranslatable(module.meta_description) || null,
  };
}

/**
 * Normalise les champs traduisibles d'un pilier API.
 *
 * @param pillar Pilier brut
 * @returns Pilier avec chaînes normalisées
 */
function normalizeServicePillar(pillar: ApiServicePillar): ApiServicePillar {
  return {
    ...pillar,
    title: resolveTranslatable(pillar.title),
    tagline: resolveTranslatable(pillar.tagline) || null,
    client_challenge: resolveTranslatable(pillar.client_challenge) || null,
    offer_summary: resolveTranslatable(pillar.offer_summary) || null,
    differentiator: resolveTranslatable(pillar.differentiator) || null,
    meta_description: resolveTranslatable(pillar.meta_description) || null,
    modules: pillar.modules?.map(normalizeServiceModule),
  };
}

/**
 * Liste les piliers stratégiques avec leurs modules actifs.
 *
 * @param locale Code langue (fr|en)
 */
export async function getServicePillars(
  locale: string
): Promise<ApiServicePillar[]> {
  const items = await safeCollection<ApiServicePillar>(
    "/service-pillars",
    locale
  );
  return items.map(normalizeServicePillar);
}

/**
 * Récupère un pilier par slug (avec modules).
 *
 * @param slug Identifiant du pilier
 * @param locale Code langue (fr|en)
 */
export async function getServicePillar(
  slug: string,
  locale: string
): Promise<ApiServicePillar | null> {
  const pillar = await safeSingle<ApiServicePillar>(
    `/service-pillars/${slug}`,
    locale
  );
  return pillar ? normalizeServicePillar(pillar) : null;
}

/**
 * Récupère un module par slug global.
 *
 * @param slug Identifiant du module
 * @param locale Code langue (fr|en)
 */
export async function getServiceModule(
  slug: string,
  locale: string
): Promise<ApiServiceModule | null> {
  const moduleItem = await safeSingle<ApiServiceModule>(
    `/service-modules/${slug}`,
    locale
  );
  return moduleItem ? normalizeServiceModule(moduleItem) : null;
}

/**
 * Récupère le premier contenu « À propos » actif.
 *
 * @param locale Code langue (fr|en)
 * @returns Le contenu À propos, ou null
 */
export async function getAbout(locale: string): Promise<ApiAbout | null> {
  const items = await safeCollection<ApiAbout>("/abouts", locale);
  return items[0] ?? null;
}

/**
 * Récupère la première fiche de contact active.
 *
 * @param locale Code langue (fr|en)
 * @returns Les coordonnées de contact, ou null
 */
export async function getContact(locale: string): Promise<ApiContact | null> {
  const items = await safeCollection<ApiContact>("/contacts", locale);
  return items[0] ?? null;
}

/**
 * Liste les offres d'emploi publiées.
 *
 * @param locale Code langue (fr|en)
 */
export function getJobOffers(locale: string): Promise<ApiJobOffer[]> {
  return safeCollection<ApiJobOffer>("/job-offers", locale);
}

/**
 * Récupère une offre d'emploi par son slug.
 *
 * @param slug Identifiant de l'offre
 * @param locale Code langue (fr|en)
 * @returns L'offre, ou null si introuvable
 */
export function getJobOffer(
  slug: string,
  locale: string
): Promise<ApiJobOffer | null> {
  return safeSingle<ApiJobOffer>(`/job-offers/${slug}`, locale);
}

/**
 * Liste les partenaires actifs.
 *
 * @param locale Code langue (fr|en)
 */
export function getPartners(locale: string): Promise<ApiPartner[]> {
  return safeCollection<ApiPartner>("/partners", locale);
}

/**
 * Liste les membres de l'équipe actifs.
 *
 * @param locale Code langue (fr|en)
 */
export function getTeamMembers(locale: string): Promise<ApiTeamMember[]> {
  return safeCollection<ApiTeamMember>("/team-members", locale);
}

/**
 * Récupère un membre de l'équipe par son slug.
 *
 * @param slug Identifiant du membre
 * @param locale Code langue (fr|en)
 * @returns Le membre, ou null si introuvable
 */
export function getTeamMember(
  slug: string,
  locale: string
): Promise<ApiTeamMember | null> {
  return safeSingle<ApiTeamMember>(`/team-members/${slug}`, locale);
}

/**
 * Liste les réalisations actives.
 *
 * @param locale Code langue (fr|en)
 */
export function getRealisations(locale: string): Promise<ApiRealisation[]> {
  return safeCollection<ApiRealisation>("/realisations", locale);
}

/**
 * Récupère une réalisation par son slug.
 *
 * @param slug Identifiant de la réalisation
 * @param locale Code langue (fr|en)
 * @returns La réalisation, ou null si introuvable
 */
export function getRealisation(
  slug: string,
  locale: string
): Promise<ApiRealisation | null> {
  return safeSingle<ApiRealisation>(`/realisations/${slug}`, locale);
}

/**
 * Liste les articles publiés (les plus récents d'abord), filtrables par type.
 *
 * @param locale Code langue (fr|en)
 * @param type Type de contenu à filtrer ("blog" ou "news"), optionnel
 */
export function getBlogs(
  locale: string,
  type?: BlogType
): Promise<ApiBlog[]> {
  const path = type ? `/blogs?type=${type}` : "/blogs";
  return safeCollection<ApiBlog>(path, locale);
}

/**
 * Récupère un article de blog par son slug.
 *
 * @param slug Identifiant de l'article
 * @param locale Code langue (fr|en)
 * @returns L'article, ou null si introuvable
 */
export function getBlog(slug: string, locale: string): Promise<ApiBlog | null> {
  return safeSingle<ApiBlog>(`/blogs/${slug}`, locale);
}
