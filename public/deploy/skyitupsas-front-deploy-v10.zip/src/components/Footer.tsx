"use client";

import { useState, type FormEvent } from "react";
import { MapPin } from "lucide-react";
import { useLocale, useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import { PATHS } from "@/lib/paths";
import SocialLinks from "./SocialLinks";

const API_BASE_URL =
  process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://127.0.0.1:8000/api/v1";

/**
 * Pied de page : présentation, liens rapides, coordonnées et formulaire
 * d'inscription à la newsletter (POST vers l'API Laravel).
 */
export default function Footer() {
  const t = useTranslations();
  const locale = useLocale();
  const year = new Date().getFullYear();
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "ok" | "error">(
    "idle"
  );

  const quickLinks = [
    { label: t("nav.home"), href: PATHS.home },
    { label: t("nav.about"), href: PATHS.about },
    { label: t("nav.services"), href: PATHS.services },
    { label: t("nav.projects"), href: PATHS.projects },
    { label: t("nav.blog"), href: PATHS.blog },
    { label: t("nav.news"), href: PATHS.news },
    { label: t("nav.team"), href: PATHS.team },
    { label: t("nav.careers"), href: PATHS.careers },
  ];

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setStatus("loading");
    try {
      const response = await fetch(`${API_BASE_URL}/newsletter`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          "X-Locale": locale,
        },
        body: JSON.stringify({ email }),
      });
      if (!response.ok) {
        throw new Error("newsletter_failed");
      }
      setStatus("ok");
      setEmail("");
    } catch {
      setStatus("error");
    }
  };

  return (
    <footer className="bg-ink-950 text-ink-200">
      <div className="container-page py-20">
        <div className="grid grid-cols-1 gap-12 sm:grid-cols-2 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <Link href={PATHS.home} className="flex items-center gap-2.5">
              <img
                src="/images/logo-icon.png"
                alt="SkyITup"
                className="h-9 w-9"
              />
              <span className="font-display text-lg font-bold tracking-tight text-white">
                Sky<span className="text-brand-500">IT</span>up
              </span>
            </Link>
            <p className="mt-6 max-w-sm text-sm leading-relaxed text-ink-200/70">
              {t("footer.description")}
            </p>
            <div className="mt-6 flex items-start gap-3 text-sm text-ink-200/70">
              <MapPin size={16} className="mt-0.5 shrink-0 text-brand-500" />
              <span>
                {t("footer.addressLine1")}
                <br />
                {t("footer.addressLine2")}
              </span>
            </div>
            <div className="mt-6">
              <SocialLinks />
            </div>
          </div>

          <div className="lg:col-span-3">
            <h4 className="font-display text-sm font-semibold uppercase tracking-wider text-white">
              {t("common.quickLinks")}
            </h4>
            <ul className="mt-5 space-y-3 text-sm">
              {quickLinks.map((l) => (
                <li key={l.href}>
                  <Link
                    href={l.href}
                    className="text-ink-200/70 transition hover:text-brand-500"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="lg:col-span-4">
            <h4 className="font-display text-sm font-semibold uppercase tracking-wider text-white">
              {t("common.newsletter")}
            </h4>
            <p className="mt-5 text-sm text-ink-200/70">
              {t("common.newsletterDesc")}
            </p>
            <form onSubmit={handleSubmit} className="mt-4 flex flex-col gap-2">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={t("common.emailPlaceholder")}
                className="rounded-full border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-ink-400 focus:border-brand-500 focus:outline-none"
              />
              <button
                type="submit"
                disabled={status === "loading"}
                className="btn-primary disabled:opacity-60"
              >
                {t("common.subscribe")}
              </button>
              {status === "ok" && (
                <p className="text-xs text-brand-300">
                  {t("footer.newsletterSuccess")}
                </p>
              )}
              {status === "error" && (
                <p className="text-xs text-red-400">
                  {t("footer.newsletterError")}
                </p>
              )}
            </form>
          </div>
        </div>
      </div>

      <div className="border-t border-white/5">
        <div className="container-page flex flex-col items-center justify-between gap-3 py-6 text-xs text-ink-200/60 sm:flex-row">
          <span>
            © {year} SkyITup SAS — {t("common.rights")}.
          </span>
          <div className="flex flex-col items-center gap-3 sm:flex-row sm:gap-6">
            <div className="flex items-center gap-6">
              <a href="#" className="hover:text-brand-500">
                {t("common.legal")}
              </a>
              <Link href={PATHS.cookies} className="hover:text-brand-500">
                {t("common.privacy")}
              </Link>
            </div>
            <a
              href="https://silasmas.com"
              target="_blank"
              rel="noopener noreferrer"
              className="transition hover:text-brand-500"
            >
              {t("footer.designedByPrefix")}{" "}
              <span className="font-semibold text-white/80">Sdev</span>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
