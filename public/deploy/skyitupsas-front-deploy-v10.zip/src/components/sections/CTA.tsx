import { ArrowRight, Mail, Phone } from "lucide-react";
import { useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import { PATHS } from "@/lib/paths";

/** Bloc d'appel à l'action final (contact téléphone / e-mail). */
export default function CTA() {
  const t = useTranslations("finalCta");
  const tCta = useTranslations("cta");
  const tCommon = useTranslations("common");

  return (
    <section id="cta" className="bg-white py-24 lg:py-32">
      <div className="container-page">
        <div className="relative overflow-hidden rounded-[2rem] bg-ink-950 p-10 sm:p-16 lg:p-20">
          <div
            aria-hidden
            className="absolute inset-0 opacity-50"
            style={{
              backgroundImage:
                "radial-gradient(circle at 80% 20%, rgba(248,154,33,0.35), transparent 50%), radial-gradient(circle at 10% 90%, rgba(248,154,33,0.15), transparent 50%)",
            }}
          />
          <svg
            aria-hidden
            className="absolute inset-0 h-full w-full opacity-[0.06]"
            preserveAspectRatio="none"
            viewBox="0 0 800 400"
          >
            {Array.from({ length: 16 }).map((_, i) => (
              <line
                key={i}
                x1="0"
                y1={i * 25}
                x2="800"
                y2={i * 25}
                stroke="white"
                strokeWidth="0.5"
              />
            ))}
          </svg>

          <div className="relative grid grid-cols-1 items-center gap-12 lg:grid-cols-12">
            <div className="lg:col-span-7">
              <span className="eyebrow-dark">
                <span className="h-1.5 w-1.5 rounded-full bg-brand-500" />
                {t("eyebrow")}
              </span>
              <h2 className="mt-6 font-display text-4xl font-bold leading-tight tracking-tight text-white sm:text-5xl lg:text-6xl">
                {t("title1")}
                <br />
                <span className="text-brand-500">{t("title2")}</span> ?
              </h2>
              <p className="mt-6 max-w-xl text-base leading-relaxed text-ink-200/80">
                {t("subtitle")}
              </p>

              <div className="mt-10 flex flex-wrap gap-4">
                <Link href={PATHS.contact} className="btn-primary">
                  {tCta("start")}
                  <ArrowRight size={16} />
                </Link>
                <a
                  href="tel:+243821790718"
                  className="inline-flex items-center justify-center gap-2 rounded-full border border-white/20 bg-white/5 px-6 py-3 text-sm font-semibold text-white backdrop-blur transition hover:bg-white/10"
                >
                  {tCta("appointment")}
                </a>
              </div>
            </div>

            <div className="lg:col-span-5">
              <div className="grid gap-4">
                <a
                  href="tel:+243821790718"
                  className="group flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.04] p-5 transition hover:border-brand-500/40 hover:bg-white/[0.08]"
                >
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-500">
                    <Phone size={18} className="text-white" />
                  </div>
                  <div>
                    <div className="text-xs font-medium uppercase tracking-wider text-ink-400">
                      {tCommon("phone")}
                    </div>
                    <div className="font-display text-lg font-semibold text-white">
                      +243 821 790 718
                    </div>
                  </div>
                </a>
                <a
                  href="mailto:contact@skyitupsas.com"
                  className="group flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.04] p-5 transition hover:border-brand-500/40 hover:bg-white/[0.08]"
                >
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-500">
                    <Mail size={18} className="text-white" />
                  </div>
                  <div>
                    <div className="text-xs font-medium uppercase tracking-wider text-ink-400">
                      {tCommon("email")}
                    </div>
                    <div className="font-display text-lg font-semibold text-white">
                      contact@skyitupsas.com
                    </div>
                  </div>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
